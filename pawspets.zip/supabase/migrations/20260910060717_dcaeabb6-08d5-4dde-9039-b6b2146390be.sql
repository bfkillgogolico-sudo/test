ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS gems integer NOT NULL DEFAULT 0;

CREATE TABLE public.gem_topups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount integer NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  checks jsonb NOT NULL DEFAULT '{}'::jsonb,
  slip_ref text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  credited_at timestamp with time zone
);

CREATE UNIQUE INDEX gem_topups_slip_ref_key ON public.gem_topups (slip_ref) WHERE slip_ref IS NOT NULL;

GRANT SELECT, INSERT ON public.gem_topups TO authenticated;
GRANT ALL ON public.gem_topups TO service_role;

ALTER TABLE public.gem_topups ENABLE ROW LEVEL SECURITY;

CREATE POLICY gem_topups_select_own ON public.gem_topups FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY gem_topups_insert_own ON public.gem_topups FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);