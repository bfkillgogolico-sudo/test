DROP POLICY IF EXISTS farm_pets_select_own ON public.farm_pets;
CREATE POLICY farm_pets_select_all ON public.farm_pets FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS user_pets_select_own ON public.user_pets;
CREATE POLICY user_pets_select_own ON public.user_pets FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY user_pets_select_placed ON public.user_pets FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM public.farm_pets f WHERE f.pet_id = user_pets.id));