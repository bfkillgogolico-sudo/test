ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS credits numeric NOT NULL DEFAULT 0;

CREATE TABLE public.farm_pets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  pet_id uuid NOT NULL REFERENCES public.user_pets(id) ON DELETE CASCADE,
  x numeric NOT NULL DEFAULT 0,
  z numeric NOT NULL DEFAULT 0,
  active_seconds numeric NOT NULL DEFAULT 0,
  pending_credits numeric NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (pet_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.farm_pets TO authenticated;
GRANT ALL ON public.farm_pets TO service_role;

ALTER TABLE public.farm_pets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "farm_pets_select_own" ON public.farm_pets FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "farm_pets_insert_own" ON public.farm_pets FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "farm_pets_update_own" ON public.farm_pets FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "farm_pets_delete_own" ON public.farm_pets FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TRIGGER update_farm_pets_updated_at BEFORE UPDATE ON public.farm_pets
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();