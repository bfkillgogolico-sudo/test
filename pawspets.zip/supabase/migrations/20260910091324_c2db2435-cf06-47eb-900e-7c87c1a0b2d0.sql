GRANT EXECUTE ON FUNCTION public.public_profiles() TO authenticated;
GRANT EXECUTE ON FUNCTION public.farm_active_users() TO authenticated;
GRANT EXECUTE ON FUNCTION public.farm_pets_public(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.user_pets_public(uuid[]) TO authenticated;