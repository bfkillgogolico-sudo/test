DROP VIEW IF EXISTS public.public_profiles;
DROP VIEW IF EXISTS public.farm_pets_public;
DROP VIEW IF EXISTS public.farm_active_users;
DROP VIEW IF EXISTS public.user_pets_public;

CREATE OR REPLACE FUNCTION public.public_profiles()
RETURNS TABLE (id uuid, username text, credits numeric)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT p.id, p.username, p.credits FROM public.profiles p
  WHERE auth.uid() IS NOT NULL
$$;
REVOKE ALL ON FUNCTION public.public_profiles() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.public_profiles() TO authenticated;

CREATE OR REPLACE FUNCTION public.farm_active_users()
RETURNS TABLE (user_id uuid)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT DISTINCT f.user_id FROM public.farm_pets f WHERE auth.uid() IS NOT NULL
$$;
REVOKE ALL ON FUNCTION public.farm_active_users() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.farm_active_users() TO authenticated;

CREATE OR REPLACE FUNCTION public.farm_pets_public(owner uuid)
RETURNS TABLE (
  id uuid, pet_id uuid, x numeric, z numeric,
  food numeric, water numeric, sick boolean, guard_until timestamptz
)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT f.id, f.pet_id, f.x, f.z, f.food, f.water, f.sick, f.guard_until
  FROM public.farm_pets f
  WHERE f.user_id = owner AND auth.uid() IS NOT NULL
$$;
REVOKE ALL ON FUNCTION public.farm_pets_public(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.farm_pets_public(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.user_pets_public(ids uuid[])
RETURNS TABLE (
  id uuid, animal text, color text, pattern text,
  pattern_color text, stars integer, gender text, sick boolean
)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT p.id, p.animal, p.color, p.pattern, p.pattern_color, p.stars, p.gender, p.sick
  FROM public.user_pets p
  WHERE p.id = ANY(ids)
    AND auth.uid() IS NOT NULL
    AND EXISTS (SELECT 1 FROM public.farm_pets f WHERE f.pet_id = p.id)
$$;
REVOKE ALL ON FUNCTION public.user_pets_public(uuid[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.user_pets_public(uuid[]) TO authenticated;