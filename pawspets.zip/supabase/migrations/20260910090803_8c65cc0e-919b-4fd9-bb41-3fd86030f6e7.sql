-- profiles: own row only, public subset through a view
DROP POLICY IF EXISTS profiles_select ON public.profiles;
CREATE POLICY profiles_select_own ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = id);

CREATE OR REPLACE VIEW public.public_profiles WITH (security_invoker = false) AS
  SELECT id, username, credits FROM public.profiles;
GRANT SELECT ON public.public_profiles TO authenticated;

-- farm_pets: own rows only; visiting uses a limited view
DROP POLICY IF EXISTS farm_pets_select_all ON public.farm_pets;
CREATE POLICY farm_pets_select_own ON public.farm_pets FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE VIEW public.farm_pets_public WITH (security_invoker = false) AS
  SELECT id, user_id, pet_id, x, z, food, water, sick, guard_until FROM public.farm_pets;
GRANT SELECT ON public.farm_pets_public TO authenticated;

CREATE OR REPLACE VIEW public.farm_active_users WITH (security_invoker = false) AS
  SELECT DISTINCT user_id FROM public.farm_pets;
GRANT SELECT ON public.farm_active_users TO authenticated;

-- user_pets: drop the all-fields placed-pet policy, expose appearance only
DROP POLICY IF EXISTS user_pets_select_placed ON public.user_pets;

CREATE OR REPLACE VIEW public.user_pets_public WITH (security_invoker = false) AS
  SELECT p.id, p.user_id, p.animal, p.color, p.pattern, p.pattern_color, p.stars, p.gender, p.sick
  FROM public.user_pets p
  WHERE EXISTS (SELECT 1 FROM public.farm_pets f WHERE f.pet_id = p.id);
GRANT SELECT ON public.user_pets_public TO authenticated;

-- user_characters: owner only
DROP POLICY IF EXISTS user_characters_select ON public.user_characters;
CREATE POLICY user_characters_select_own ON public.user_characters FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- rooms: host only (clients coordinate through realtime channels)
DROP POLICY IF EXISTS rooms_select ON public.rooms;
CREATE POLICY rooms_select_host ON public.rooms FOR SELECT TO authenticated USING (auth.uid() = host_id);