ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS poison_items integer NOT NULL DEFAULT 0;
ALTER TABLE public.farm_pets ADD COLUMN IF NOT EXISTS poisoned boolean NOT NULL DEFAULT false;
ALTER TABLE public.user_pets ADD COLUMN IF NOT EXISTS poisoned boolean NOT NULL DEFAULT false;