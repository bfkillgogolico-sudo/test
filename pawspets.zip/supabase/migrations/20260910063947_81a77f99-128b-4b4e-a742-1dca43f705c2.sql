ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS catch_items integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS guard_items integer NOT NULL DEFAULT 0;

ALTER TABLE public.farm_pets
  ADD COLUMN IF NOT EXISTS guard_until timestamptz;