create or replace function public.active_users()
returns table(user_id uuid)
language sql
stable
security definer
set search_path = public
as $$
  select distinct up.user_id from public.user_pets up
  union
  select distinct fp.user_id from public.farm_pets fp
$$;

revoke all on function public.active_users() from public;
grant execute on function public.active_users() to authenticated;
grant execute on function public.active_users() to service_role;