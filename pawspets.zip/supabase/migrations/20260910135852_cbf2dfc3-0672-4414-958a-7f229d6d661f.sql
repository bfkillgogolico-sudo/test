ALTER TABLE public.user_pets ADD COLUMN IF NOT EXISTS stress numeric NOT NULL DEFAULT 100;
ALTER TABLE public.user_pets ADD COLUMN IF NOT EXISTS stress_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS farm_expansions integer NOT NULL DEFAULT 0;
ALTER TABLE public.profiles ALTER COLUMN coins SET DEFAULT 1000;
ALTER TABLE public.profiles ALTER COLUMN gems SET DEFAULT 1000;
ALTER TABLE public.profiles ALTER COLUMN food_items SET DEFAULT 10;
ALTER TABLE public.profiles ALTER COLUMN milk_items SET DEFAULT 10;
ALTER TABLE public.profiles ALTER COLUMN med_items SET DEFAULT 5;