CREATE TABLE public.user_pets (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  animal TEXT NOT NULL,
  color TEXT NOT NULL DEFAULT 'normal',
  pattern TEXT NOT NULL DEFAULT 'plain',
  pattern_color TEXT NOT NULL DEFAULT 'normal',
  stars INTEGER NOT NULL DEFAULT 1,
  skill INTEGER NOT NULL DEFAULT 1,
  credit_rate NUMERIC(6,2) NOT NULL DEFAULT 0.5,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.user_pets TO authenticated;
GRANT ALL ON public.user_pets TO service_role;
ALTER TABLE public.user_pets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "user_pets_select_own" ON public.user_pets FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "user_pets_insert_own" ON public.user_pets FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "user_pets_update_own" ON public.user_pets FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "user_pets_delete_own" ON public.user_pets FOR DELETE TO authenticated USING (auth.uid() = user_id);
ALTER TABLE public.profiles ALTER COLUMN coins SET DEFAULT 600;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS selected_pet_id UUID;