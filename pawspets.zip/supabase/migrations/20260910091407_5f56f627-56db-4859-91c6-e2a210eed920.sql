REVOKE EXECUTE ON FUNCTION public.public_profiles() FROM anon;
REVOKE EXECUTE ON FUNCTION public.farm_active_users() FROM anon;
REVOKE EXECUTE ON FUNCTION public.farm_pets_public(uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.user_pets_public(uuid[]) FROM anon;