GRANT EXECUTE ON FUNCTION public.public_profiles() TO anon;
GRANT EXECUTE ON FUNCTION public.farm_active_users() TO anon;
GRANT EXECUTE ON FUNCTION public.farm_pets_public(uuid) TO anon;
GRANT EXECUTE ON FUNCTION public.user_pets_public(uuid[]) TO anon;
GRANT EXECUTE ON FUNCTION public.public_profiles() TO service_role;
GRANT EXECUTE ON FUNCTION public.farm_active_users() TO service_role;
GRANT EXECUTE ON FUNCTION public.farm_pets_public(uuid) TO service_role;
GRANT EXECUTE ON FUNCTION public.user_pets_public(uuid[]) TO service_role;