ALTER TABLE public.farm_pets ADD COLUMN IF NOT EXISTS sick boolean NOT NULL DEFAULT false;
ALTER TABLE public.user_pets ADD COLUMN IF NOT EXISTS sick boolean NOT NULL DEFAULT false;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS med_items integer NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS public.farm_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  farm_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  actor_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  actor_name text NOT NULL DEFAULT '',
  pet_id uuid,
  animal text NOT NULL DEFAULT '',
  kind text NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT ON public.farm_events TO authenticated;
GRANT ALL ON public.farm_events TO service_role;

ALTER TABLE public.farm_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY farm_events_select_own ON public.farm_events
  FOR SELECT TO authenticated
  USING (auth.uid() = farm_user_id OR auth.uid() = actor_id);

CREATE INDEX IF NOT EXISTS farm_events_farm_user_created_idx
  ON public.farm_events (farm_user_id, created_at DESC);