CREATE OR REPLACE FUNCTION public.farm_field_public(owner uuid)
RETURNS TABLE(id uuid, animal text, color text, pattern text, pattern_color text, stars integer, gender text, sick boolean, poisoned boolean, food numeric, water numeric)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT p.id, p.animal, p.color, p.pattern, p.pattern_color, p.stars, p.gender, p.sick, p.poisoned, p.food, p.water
  FROM public.user_pets p
  WHERE p.user_id = owner AND auth.uid() IS NOT NULL
  ORDER BY p.created_at
  LIMIT (SELECT 3 + COALESCE(farm_expansions, 0) FROM public.profiles WHERE profiles.id = owner);
$$;
REVOKE ALL ON FUNCTION public.farm_field_public(uuid) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.farm_field_public(uuid) TO authenticated;