export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      farm_events: {
        Row: {
          actor_id: string | null
          actor_name: string
          animal: string
          created_at: string
          farm_user_id: string
          id: string
          kind: string
          pet_id: string | null
        }
        Insert: {
          actor_id?: string | null
          actor_name?: string
          animal?: string
          created_at?: string
          farm_user_id: string
          id?: string
          kind: string
          pet_id?: string | null
        }
        Update: {
          actor_id?: string | null
          actor_name?: string
          animal?: string
          created_at?: string
          farm_user_id?: string
          id?: string
          kind?: string
          pet_id?: string | null
        }
        Relationships: []
      }
      farm_pets: {
        Row: {
          active_seconds: number
          created_at: string
          food: number
          food_drain: number
          guard_until: string | null
          id: string
          pending_credits: number
          pet_id: string
          poisoned: boolean
          sick: boolean
          updated_at: string
          user_id: string
          water: number
          water_drain: number
          x: number
          z: number
        }
        Insert: {
          active_seconds?: number
          created_at?: string
          food?: number
          food_drain?: number
          guard_until?: string | null
          id?: string
          pending_credits?: number
          pet_id: string
          poisoned?: boolean
          sick?: boolean
          updated_at?: string
          user_id: string
          water?: number
          water_drain?: number
          x?: number
          z?: number
        }
        Update: {
          active_seconds?: number
          created_at?: string
          food?: number
          food_drain?: number
          guard_until?: string | null
          id?: string
          pending_credits?: number
          pet_id?: string
          poisoned?: boolean
          sick?: boolean
          updated_at?: string
          user_id?: string
          water?: number
          water_drain?: number
          x?: number
          z?: number
        }
        Relationships: [
          {
            foreignKeyName: "farm_pets_pet_id_fkey"
            columns: ["pet_id"]
            isOneToOne: true
            referencedRelation: "user_pets"
            referencedColumns: ["id"]
          },
        ]
      }
      friendships: {
        Row: {
          addressee_id: string
          created_at: string
          id: string
          requester_id: string
          status: string
          updated_at: string
        }
        Insert: {
          addressee_id: string
          created_at?: string
          id?: string
          requester_id: string
          status?: string
          updated_at?: string
        }
        Update: {
          addressee_id?: string
          created_at?: string
          id?: string
          requester_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      gem_topups: {
        Row: {
          amount: number
          checks: Json
          created_at: string
          credited_at: string | null
          id: string
          slip_ref: string | null
          status: string
          user_id: string
        }
        Insert: {
          amount: number
          checks?: Json
          created_at?: string
          credited_at?: string | null
          id?: string
          slip_ref?: string | null
          status?: string
          user_id: string
        }
        Update: {
          amount?: number
          checks?: Json
          created_at?: string
          credited_at?: string | null
          id?: string
          slip_ref?: string | null
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          catch_items: number
          coins: number
          created_at: string
          credits: number
          farm_expansions: number
          food_items: number
          gems: number
          guard_items: number
          id: string
          med_items: number
          milk_items: number
          poison_items: number
          selected_pet_id: string | null
          username: string
        }
        Insert: {
          catch_items?: number
          coins?: number
          created_at?: string
          credits?: number
          farm_expansions?: number
          food_items?: number
          gems?: number
          guard_items?: number
          id: string
          med_items?: number
          milk_items?: number
          poison_items?: number
          selected_pet_id?: string | null
          username: string
        }
        Update: {
          catch_items?: number
          coins?: number
          created_at?: string
          credits?: number
          farm_expansions?: number
          food_items?: number
          gems?: number
          guard_items?: number
          id?: string
          med_items?: number
          milk_items?: number
          poison_items?: number
          selected_pet_id?: string | null
          username?: string
        }
        Relationships: []
      }
      rooms: {
        Row: {
          code: string
          created_at: string
          host_id: string
          host_name: string
          id: string
          status: string
          updated_at: string
        }
        Insert: {
          code: string
          created_at?: string
          host_id: string
          host_name: string
          id?: string
          status?: string
          updated_at?: string
        }
        Update: {
          code?: string
          created_at?: string
          host_id?: string
          host_name?: string
          id?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      user_characters: {
        Row: {
          character_id: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          character_id: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          character_id?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      user_pets: {
        Row: {
          animal: string
          color: string
          created_at: string
          credit_rate: number
          food: number
          gender: string
          id: string
          pattern: string
          pattern_color: string
          pending_credits: number
          poisoned: boolean
          sick: boolean
          skill: number
          stars: number
          stress: number
          stress_at: string
          user_id: string
          water: number
        }
        Insert: {
          animal: string
          color?: string
          created_at?: string
          credit_rate?: number
          food?: number
          gender?: string
          id?: string
          pattern?: string
          pattern_color?: string
          pending_credits?: number
          poisoned?: boolean
          sick?: boolean
          skill?: number
          stars?: number
          stress?: number
          stress_at?: string
          user_id: string
          water?: number
        }
        Update: {
          animal?: string
          color?: string
          created_at?: string
          credit_rate?: number
          food?: number
          gender?: string
          id?: string
          pattern?: string
          pattern_color?: string
          pending_credits?: number
          poisoned?: boolean
          sick?: boolean
          skill?: number
          stars?: number
          stress?: number
          stress_at?: string
          user_id?: string
          water?: number
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      active_users: {
        Args: never
        Returns: {
          user_id: string
        }[]
      }
      farm_active_users: {
        Args: never
        Returns: {
          user_id: string
        }[]
      }
      farm_field_public: {
        Args: { owner: string }
        Returns: {
          animal: string
          color: string
          food: number
          gender: string
          id: string
          pattern: string
          pattern_color: string
          poisoned: boolean
          sick: boolean
          stars: number
          water: number
        }[]
      }
      farm_pets_public: {
        Args: { owner: string }
        Returns: {
          food: number
          guard_until: string
          id: string
          pet_id: string
          sick: boolean
          water: number
          x: number
          z: number
        }[]
      }
      public_profiles: {
        Args: never
        Returns: {
          credits: number
          id: string
          username: string
        }[]
      }
      user_pets_public: {
        Args: { ids: string[] }
        Returns: {
          animal: string
          color: string
          gender: string
          id: string
          pattern: string
          pattern_color: string
          sick: boolean
          stars: number
        }[]
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
