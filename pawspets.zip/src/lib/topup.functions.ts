import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const GEM_AMOUNTS = [10, 50, 100, 200, 500, 1000, 3000, 5000] as const;
export type GemAmount = (typeof GEM_AMOUNTS)[number];

export type SlipChecks = {
  /** พบคำว่า "ภูมิภาค" ในสลิป */
  region: boolean;
  /** พบรูป QR code ในสลิป */
  qr: boolean;
  /** ยอดเงินในสลิปตรงกับจำนวนที่เลือก */
  amount: boolean;
  /** ยอดที่อ่านได้จากสลิป */
  amountFound: number | null;
  note: string;
};

export type VerifyResult =
  | { ok: false; reason: "bad_input" | "ai_failed" | "duplicate" | "failed"; checks?: SlipChecks }
  | { ok: true; topupId: string; checks: SlipChecks; passed: boolean };

const SYSTEM = `คุณเป็นระบบตรวจสลิปโอนเงินของธนาคารไทย ตอบเป็น JSON เท่านั้น
โครงสร้าง: {"has_region_text": boolean, "has_qr_code": boolean, "amount": number|null, "ref": string|null, "note": string}
- has_region_text: true เฉพาะเมื่อมีข้อความคำว่า "ภูมิภาค" ปรากฏในภาพ
- has_qr_code: true เฉพาะเมื่อในภาพมีรูป QR code (ตารางสี่เหลี่ยมขาวดำ)
- amount: ยอดเงินที่โอน เป็นตัวเลข (ไม่มีคอมมา) ถ้าอ่านไม่ได้ให้ null
- ref: เลขที่รายการ/รหัสอ้างอิงของสลิป ถ้าไม่มีให้ null
- note: สรุปสั้น ๆ เป็นภาษาไทย`;

async function readSlip(dataUrl: string) {
  const key = process.env["LOVABLE_API_KEY"];
  if (!key) return null;
  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash",
      messages: [
        { role: "system", content: SYSTEM },
        {
          role: "user",
          content: [
            { type: "text", text: "ตรวจสลิปนี้และตอบ JSON ตามโครงสร้าง" },
            { type: "image_url", image_url: { url: dataUrl } },
          ],
        },
      ],
    }),
  });
  if (!res.ok) return null;
  const json = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  const text = json.choices?.[0]?.message?.content ?? "";
  const m = text.match(/\{[\s\S]*\}/);
  if (!m) return null;
  try {
    return JSON.parse(m[0]) as {
      has_region_text?: boolean;
      has_qr_code?: boolean;
      amount?: number | null;
      ref?: string | null;
      note?: string;
    };
  } catch {
    return null;
  }
}

/** ตรวจสลิป: ต้องมีคำว่า "ภูมิภาค", มี QR code และยอดตรง จึงจะยืนยันได้ */
export const verifySlip = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z
      .object({
        amount: z.number().int().refine((n) => (GEM_AMOUNTS as readonly number[]).includes(n)),
        image: z.string().min(64).max(9_000_000),
      })
      .parse(d),
  )
  .handler(async ({ context, data }): Promise<VerifyResult> => {
    const { supabase, userId } = context;
    if (!data.image.startsWith("data:image/")) return { ok: false, reason: "bad_input" };

    const read = await readSlip(data.image);
    if (!read) return { ok: false, reason: "ai_failed" };

    const amountFound = typeof read.amount === "number" && Number.isFinite(read.amount) ? read.amount : null;
    const checks: SlipChecks = {
      region: read.has_region_text === true,
      qr: read.has_qr_code === true,
      amount: amountFound !== null && Math.abs(amountFound - data.amount) < 0.005,
      amountFound,
      note: typeof read.note === "string" ? read.note.slice(0, 300) : "",
    };
    const passed = checks.region && checks.qr && checks.amount;
    const slipRef = passed && read.ref ? `${data.amount}:${String(read.ref).replace(/\s+/g, "")}` : null;

    const { data: row, error } = await supabase
      .from("gem_topups")
      .insert({
        user_id: userId,
        amount: data.amount,
        status: passed ? "verified" : "rejected",
        checks: JSON.parse(JSON.stringify(checks)),
        slip_ref: slipRef,
      })
      .select("id")
      .maybeSingle();

    if (error) {
      if (error.code === "23505" || error.code === "23p01" || /duplicate/i.test(error.message))
        return { ok: false, reason: "duplicate", checks };
      return { ok: false, reason: "failed", checks };
    }
    if (!row) return { ok: false, reason: "failed", checks };
    return { ok: true, topupId: row.id, checks, passed };
  });

export type ConfirmResult =
  | { ok: false; reason: "not_found" | "not_verified" | "failed" }
  | { ok: true; gems: number; amount: number };

/** ยืนยันการเติม: เพิ่มเพชรเข้าบัญชีเมื่อสลิปผ่านการตรวจแล้ว */
export const confirmTopup = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ topupId: z.string().uuid() }).parse(d))
  .handler(async ({ context, data }): Promise<ConfirmResult> => {
    const { supabase, userId } = context;
    const { data: row } = await supabase
      .from("gem_topups")
      .select("id, amount, status")
      .eq("id", data.topupId)
      .eq("user_id", userId)
      .maybeSingle();
    if (!row) return { ok: false, reason: "not_found" };
    if (row.status !== "verified") return { ok: false, reason: "not_verified" };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // ล็อกรายการก่อนจ่ายเพชร กันกดยืนยันซ้ำ
    const { data: claimed } = await supabaseAdmin
      .from("gem_topups")
      .update({ status: "credited", credited_at: new Date().toISOString() })
      .eq("id", row.id)
      .eq("status", "verified")
      .select("id, amount")
      .maybeSingle();
    if (!claimed) return { ok: false, reason: "not_verified" };

    const { data: profile } = await supabaseAdmin.from("profiles").select("gems").eq("id", userId).maybeSingle();
    const gems = Number(profile?.gems ?? 0) + claimed.amount;
    const { error } = await supabaseAdmin.from("profiles").update({ gems }).eq("id", userId);
    if (error) return { ok: false, reason: "failed" };
    return { ok: true, gems, amount: claimed.amount };
  });
