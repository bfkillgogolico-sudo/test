import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { COLORS, PATTERNS, SKILLS, animalStars, rollPetSpec, type Pet } from "@/lib/game/pets";

export const ROLL_COST = 100;
export const ROOM_STALE_MS = 45_000;

/** Coin payout by final standing: 1st=50, 2nd=30, 3rd=20, others=0 */
export const PLACEMENT_REWARDS = [50, 30, 20];

/** gacha: spend coins, get a fully random pet (animal / color / pattern / stars / skill / credit rate) */
export const rollPet = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data: profile } = await supabase.from("profiles").select("coins").eq("id", userId).maybeSingle();
    if (!profile) return { ok: false as const, reason: "no_profile" };
    if (profile.coins < ROLL_COST) return { ok: false as const, reason: "no_coins", coins: profile.coins };

    const spec = rollPetSpec();
    const coins = profile.coins - ROLL_COST;
    const { error: coinErr } = await supabase.from("profiles").update({ coins }).eq("id", userId);
    if (coinErr) return { ok: false as const, reason: "update_failed" };
    const { data: pet, error } = await supabase
      .from("user_pets")
      .insert({ user_id: userId, ...spec })
      .select("id, animal, color, pattern, pattern_color, stars, skill, credit_rate, gender")
      .maybeSingle();
    if (error || !pet) return { ok: false as const, reason: "insert_failed", coins };
    return { ok: true as const, pet, coins };
  });

export type AwardResult =
  | { ok: true; coins: number; reward: number; placement: number }
  | { ok: false; coins: number };

/** Award coins based on the player's final standing (1st/2nd/3rd). */
export const awardWin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ placement: z.number().int().min(1) }).parse(d))
  .handler(async ({ context, data }): Promise<AwardResult> => {
    const reward = PLACEMENT_REWARDS[data.placement - 1] ?? 0;
    const { supabase, userId } = context;
    const { data: profile } = await supabase.from("profiles").select("coins").eq("id", userId).maybeSingle();
    if (!profile) return { ok: false as const, coins: 0 };
    if (reward <= 0) return { ok: true as const, coins: profile.coins, reward: 0, placement: data.placement };
    const coins = profile.coins + reward;
    await supabase.from("profiles").update({ coins }).eq("id", userId);
    return { ok: true as const, coins, reward, placement: data.placement };
  });

/* ── breeding ──────────────────────────────────────────────────────────── */

export const BREED_COST = 1000;

export type BreedResult =
  | { ok: false; reason: "bad_input" | "no_profile" | "no_credits" | "failed"; credits?: number }
  | {
      ok: true;
      kind: "born" | "hybrid" | "fight";
      credits: number;
      pet?: Pet;
      dead: string[];
      /** both parents fought and both died */
      bothDied: boolean;
    };




const pickOne = <T,>(a: T[]): T => a[Math.floor(Math.random() * a.length)]!;

export const breedPets = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ aId: z.string().uuid(), bId: z.string().uuid() }).parse(d))
  .handler(async ({ context, data }): Promise<BreedResult> => {
    const { supabase, userId } = context;
    if (data.aId === data.bId) return { ok: false, reason: "bad_input" };

    const { data: profile } = await supabase.from("profiles").select("credits").eq("id", userId).maybeSingle();
    if (!profile) return { ok: false, reason: "no_profile" };
    const have = Number(profile.credits ?? 0);
    if (have < BREED_COST) return { ok: false, reason: "no_credits", credits: have };

    const { data: rows } = await supabase
      .from("user_pets")
      .select("id, animal, color, pattern, pattern_color, stars, skill, credit_rate, gender")
      .eq("user_id", userId)
      .in("id", [data.aId, data.bId]);
    const a = rows?.find((r) => r.id === data.aId);
    const b = rows?.find((r) => r.id === data.bId);
    if (!a || !b) return { ok: false, reason: "bad_input" };

    const credits = Math.round((have - BREED_COST) * 100) / 100;
    const { error: payErr } = await supabase.from("profiles").update({ credits }).eq("id", userId);
    if (payErr) return { ok: false, reason: "failed" };

    const kill = async (ids: string[]) => {
      if (!ids.length) return;
      await supabase.from("farm_pets").delete().in("pet_id", ids);
      await supabase.from("user_pets").delete().in("id", ids).eq("user_id", userId);
      const { data: prof } = await supabase.from("profiles").select("selected_pet_id").eq("id", userId).maybeSingle();
      if (prof?.selected_pet_id && ids.includes(prof.selected_pet_id)) {
        await supabase.from("profiles").update({ selected_pet_id: null }).eq("id", userId);
      }
    };

    const insertPet = async (spec: Omit<Pet, "id">) => {
      const { data: pet } = await supabase
        .from("user_pets")
        .insert({ user_id: userId, ...spec })
        .select("id, animal, color, pattern, pattern_color, stars, skill, credit_rate, gender")
        .maybeSingle();
      return pet ? ({ ...pet, credit_rate: Number(pet.credit_rate) } as Pet) : undefined;
    };

    const sameAnimal = a.animal === b.animal;
    const sameGender = a.gender === b.gender;

    // same species, different gender → healthy offspring, parents survive
    if (sameAnimal && !sameGender) {
      const spec = rollPetSpec();
      spec.animal = a.animal;
      spec.stars = animalStars(a.animal);
      spec.skill = Math.random() < 0.5 ? a.skill : b.skill;
      const pet = await insertPet(spec);
      if (!pet) return { ok: false, reason: "failed", credits };
      return { ok: true, kind: "born", credits, pet, dead: [], bothDied: false };
    }

    // different species, different gender → 1% rare hybrid (both parents die)
    if (!sameAnimal && !sameGender && Math.random() < 0.01) {
      const hybridAnimal = pickOne([a.animal, b.animal]);
      const spec: Omit<Pet, "id"> = {
        animal: hybridAnimal,
        color: COLORS[0]!.id,
        pattern: PATTERNS[0]!.id,
        pattern_color: COLORS[0]!.id,
        stars: animalStars(hybridAnimal),
        skill: pickOne(SKILLS).n,
        credit_rate: Math.min(100, Math.round((Number(a.credit_rate) + Number(b.credit_rate)) * 100) / 100),
        gender: Math.random() < 0.5 ? "male" : "female",
      };
      const pet = await insertPet(spec);
      await kill([a.id, b.id]);
      if (!pet) return { ok: false, reason: "failed", credits };
      return { ok: true, kind: "hybrid", credits, pet, dead: [a.id, b.id], bothDied: true };
    }

    // otherwise: a fight
    const both = sameAnimal && sameGender && Math.random() < 0.35;
    const dead = both ? [a.id, b.id] : [Math.random() < 0.5 ? a.id : b.id];
    await kill(dead);
    return { ok: true, kind: "fight", credits, dead, bothDied: both };
  });

/* ── upgrades ──────────────────────────────────────────────────────────── */

export const UPGRADE_SKILL_COST = 2000;
export const UPGRADE_RATE_COST = 1000;
export const UPGRADE_COLOR_COST = 1000;
export const UPGRADE_PATTERN_COST = 1000;

export const UPGRADE_COSTS = {
  skill: UPGRADE_SKILL_COST,
  rate: UPGRADE_RATE_COST,
  color: UPGRADE_COLOR_COST,
  pattern: UPGRADE_PATTERN_COST,
} as const;

export type UpgradeKind = keyof typeof UPGRADE_COSTS;

export type UpgradeResult =
  | { ok: false; reason: "bad_input" | "no_profile" | "no_credits" | "failed"; credits?: number }
  | {
      ok: true;
      kind: UpgradeKind;
      credits: number;
      before: Pet;
      /** สัตว์ตายจากการอัปเกรด — โอกาสขึ้นกับ credit_rate ตอนนั้น — ไม่มี pet หลังอัปเกรด */
      died: boolean;
      pet?: Pet;
    };

/**
 * โอกาสสัตว์ตายทุกครั้งที่อัปเกรด
 * - ค่าเริ่มต้น 2% เมื่อ credit_rate ≤ 99
 * - ยิ่งค่าการสร้างเครดิตสูงเกิน 99 โอกาสตายยิ่งเพิ่มขึ้น (เช่น 99→2%, 140→~10%, 200→~22%)
 * - ปิดที่สูงสุด 95%
 */
export const UPGRADE_DEATH_BASE = 0.02;
export const UPGRADE_DEATH_THRESHOLD = 99;
export const UPGRADE_DEATH_PER_POINT = 0.002;
export const UPGRADE_DEATH_CAP = 0.95;

export function deathChanceForRate(rate: number): number {
  if (rate <= UPGRADE_DEATH_THRESHOLD) return UPGRADE_DEATH_BASE;
  const excess = rate - UPGRADE_DEATH_THRESHOLD;
  return Math.min(UPGRADE_DEATH_CAP, UPGRADE_DEATH_BASE + excess * UPGRADE_DEATH_PER_POINT);
}

/** random credit-rate gain: 0.001–30 with a steep r¹⁰ power curve so tiny gains
 *  are common and big jumps are very rare. No upper cap on the total rate. */
function rollRateGain() {
  const gain = 0.001 + (30 - 0.001) * Math.pow(Math.random(), 10);
  return Math.round(gain * 1000) / 1000;
}

export const upgradePet = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ petId: z.string().uuid(), kind: z.enum(["skill", "rate", "color", "pattern"]) }).parse(d),
  )
  .handler(async ({ context, data }): Promise<UpgradeResult> => {
    const { supabase, userId } = context;
    const cost = UPGRADE_COSTS[data.kind];

    const { data: profile } = await supabase.from("profiles").select("credits").eq("id", userId).maybeSingle();
    if (!profile) return { ok: false, reason: "no_profile" };
    const have = Number(profile.credits ?? 0);
    if (have < cost) return { ok: false, reason: "no_credits", credits: have };

    const cols = "id, animal, color, pattern, pattern_color, stars, skill, credit_rate, gender";
    const { data: row } = await supabase
      .from("user_pets")
      .select(cols)
      .eq("user_id", userId)
      .eq("id", data.petId)
      .maybeSingle();
    if (!row) return { ok: false, reason: "bad_input" };
    const before = { ...row, credit_rate: Number(row.credit_rate) } as Pet;

    const credits = Math.round((have - cost) * 100) / 100;
    const { error: payErr } = await supabase.from("profiles").update({ credits }).eq("id", userId);
    if (payErr) return { ok: false, reason: "failed", credits: have };

    /* โอกาสตายเฉพาะตอนอัปเกรด "การสร้างเครดิต" เท่านั้น
       ขึ้นกับ credit_rate ปัจจุบัน: เริ่ม 2% ที่ ≤99 แล้วเพิ่มยิ่งค่าสูง */
    if (data.kind === "rate" && Math.random() < deathChanceForRate(before.credit_rate)) {
      await supabase.from("farm_pets").delete().eq("pet_id", data.petId);
      await supabase.from("user_pets").delete().eq("id", data.petId).eq("user_id", userId);
      const { data: prof } = await supabase.from("profiles").select("selected_pet_id").eq("id", userId).maybeSingle();
      if (prof?.selected_pet_id === data.petId) {
        await supabase.from("profiles").update({ selected_pet_id: null }).eq("id", userId);
      }
      return { ok: true, kind: data.kind, credits, before, died: true };
    }

    const patch: { skill?: number; credit_rate?: number; color?: string; pattern?: string; pattern_color?: string } = {};
    if (data.kind === "skill") {
      const others = SKILLS.filter((s) => s.n !== before.skill);
      patch.skill = pickOne(others.length ? others : SKILLS).n;
    } else if (data.kind === "rate") {
      patch.credit_rate = Math.round((before.credit_rate + rollRateGain()) * 1000) / 1000;
    } else if (data.kind === "color") {
      const others = COLORS.filter((c) => c.id !== before.color);
      patch.color = pickOne(others).id;
    } else {
      const others = PATTERNS.filter((p) => p.id !== before.pattern);
      patch.pattern = pickOne(others).id;
      patch.pattern_color = pickOne(COLORS).id;
    }

    const { data: updated } = await supabase
      .from("user_pets")
      .update(patch)
      .eq("id", data.petId)
      .eq("user_id", userId)
      .select(cols)
      .maybeSingle();
    if (!updated) return { ok: false, reason: "failed", credits };

    return { ok: true, kind: data.kind, credits, died: false, pet: { ...updated, credit_rate: Number(updated.credit_rate) } as Pet, before };
  });
