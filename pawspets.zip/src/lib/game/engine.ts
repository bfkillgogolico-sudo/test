import { getCharacter, skillSpec } from "./characters";

export const ARENA = { w: 1600, h: 900 };
export const PLAYER_R = 28;
export const WOLF_R = 40;
export const BALL_R = 16;
export const PLAYER_SPEED = 330;
const WOLF_BASE_SPEED = 292;
const BALL_SPEED = 660;
const BALL_MAX_SPEED = 1150;
const CHARGE_CAP = 10;
export const SKILL_COST = 3;
const SKILL_DURATION = 3;
const RAGE_STEP = 30;

// ---- shrinking arena walls ----
const SHRINK_START = 12; // seconds of play before walls begin closing
const SHRINK_DURATION = 95; // seconds to fully collapse to minimum size
const MIN_FRAC = 0.42; // final playable area as a fraction of the arena

export type Rect = { left: number; top: number; right: number; bottom: number };

export function currentBounds(t: number): Rect {
  const minW = ARENA.w * MIN_FRAC;
  const minH = ARENA.h * MIN_FRAC;
  const minL = (ARENA.w - minW) / 2;
  const minT = (ARENA.h - minH) / 2;
  if (t <= SHRINK_START) return { left: 0, top: 0, right: ARENA.w, bottom: ARENA.h };
  const k = Math.min(1, (t - SHRINK_START) / SHRINK_DURATION);
  // ease-in: starts slow, accelerates
  const e = k * k;
  return {
    left: minL * e,
    top: minT * e,
    right: ARENA.w - (ARENA.w - (minL + minW)) * e,
    bottom: ARENA.h - (ARENA.h - (minT + minH)) * e,
  };
}

export type PlayerState = {
  id: string;
  name: string;
  charId: string;
  isBot: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  alive: boolean;
  charges: number;
  holdSeconds: number;
  aim: number;
  sprintUntil: number;
  vanishUntil: number;
  shieldUntil: number;
  dashUntil: number;
  skillFlash: number;
  botTimer: number;
};

export type BallState = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  holder: string | null;
  bounces: number;
  grace: number;
  lastHolder: string | null;
};

export type WolfState = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  slowUntil: number;
  hasteUntil: number;
  target: string | null;
  rageTier: number;
  ballHits: number;
  dashUntil: number;
  dashVx: number;
  dashVy: number;
};

export const WOLF_DASH_HITS = 5;

/** fixed simulation rate: every device steps the exact same slices of time */
export const TICK_HZ = 60;
export const TICK_DT = 1 / TICK_HZ;
export const TICK_MS = 1000 / TICK_HZ;

export type Corpse = { id: string; name: string; charId: string; x: number; y: number; t: number };

export type GameState = {
  t: number;
  /** number of fixed simulation steps completed */
  tick: number;
  /** shared deterministic random seed, advanced in lockstep with the simulation */
  seed: number;
  phase: "countdown" | "playing" | "over";
  countdown: number;
  players: PlayerState[];
  ball: BallState;
  wolf: WolfState;
  corpses: Corpse[];
  winner: string | null;
  events: { kind: "pass" | "death" | "rage" | "bounce" | "skill"; text: string; t: number }[];
};

export type PlayerInput = { ax: number; ay: number; aim: number; shoot: boolean; skill: boolean };

export type PlayerMeta = {
  id: string;
  name: string;
  charId: string;
  isBot: boolean;
  pet?: import("./pets").Pet;
  /** measured connection quality in ms (lower = better); shown in the lobby only */
  net?: number;
};

const emptyInput = (): PlayerInput => ({ ax: 0, ay: 0, aim: 0, shoot: false, skill: false });

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

/** stable 32-bit hash, used to derive a match seed from the room code */
export function seedFrom(text: string): number {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/** cheap fingerprint of the simulation, used to spot drift between devices */
export function checksumOf(s: GameState): number {
  let h = s.tick & 0xffff;
  const add = (v: number) => {
    h = (Math.imul(h, 31) + (Math.round(v) | 0)) >>> 0;
  };
  add(s.ball.x);
  add(s.ball.y);
  add(s.wolf.x);
  add(s.wolf.y);
  for (const p of s.players) {
    add(p.x);
    add(p.y);
    add(p.alive ? 1 : 0);
  }
  return h >>> 0;
}

export class GameEngine {
  state: GameState;
  inputs: Record<string, PlayerInput> = {};

  constructor(metas: PlayerMeta[], seed = 1) {
    const spots = spawnSpots(metas.length);
    const players: PlayerState[] = metas.map((m, i) => ({
      id: m.id,
      name: m.name,
      charId: m.charId,
      isBot: m.isBot,
      x: spots[i]!.x,
      y: spots[i]!.y,
      vx: 0,
      vy: 0,
      alive: true,
      charges: 0,
      holdSeconds: 0,
      aim: 0,
      sprintUntil: 0,
      vanishUntil: 0,
      shieldUntil: 0,
      dashUntil: 0,
      skillFlash: 0,
      botTimer: 0,
    }));
    metas.forEach((m) => (this.inputs[m.id] = emptyInput()));
    const startSeed = seed >>> 0 || 1;
    const starter = players[startSeed % players.length]!;
    this.state = {
      t: 0,
      tick: 0,
      seed: startSeed,
      phase: "countdown",
      countdown: 3,
      players,
      ball: {
        x: starter.x,
        y: starter.y,
        vx: 0,
        vy: 0,
        holder: starter.id,
        bounces: 0,
        grace: 0,
        lastHolder: null,
      },
      wolf: {
        x: ARENA.w / 2,
        y: ARENA.h / 2,
        vx: 0,
        vy: 0,
        slowUntil: 0,
        hasteUntil: 0,
        target: starter.id,
        rageTier: 0,
        ballHits: 0,
        dashUntil: 0,
        dashVx: 0,
        dashVy: 0,
      },
      corpses: [],
      winner: null,
      events: [{ kind: "pass", text: `${starter.name} เริ่มถือลูกแก้ว 🔮`, t: 0 }],
    };
  }

  /** deterministic random: identical on every device because the seed lives in the state */
  private rand(): number {
    this.state.seed = (Math.imul(this.state.seed, 1664525) + 1013904223) >>> 0;
    return this.state.seed / 4294967296;
  }

  /** Adopt a snapshot (used when another device takes over the simulation). */
  loadState(s: GameState) {
    this.state = JSON.parse(JSON.stringify(s)) as GameState;
    for (const p of this.state.players) if (!this.inputs[p.id]) this.inputs[p.id] = emptyInput();
  }

  setInput(id: string, input: Partial<PlayerInput>) {
    const cur = this.inputs[id] ?? emptyInput();
    this.inputs[id] = { ...cur, ...input };
    if (input.shoot) this.inputs[id]!.shoot = true;
    if (input.skill) this.inputs[id]!.skill = true;
  }

  private player(id: string | null) {
    if (!id) return undefined;
    return this.state.players.find((p) => p.id === id);
  }

  private push(kind: GameState["events"][number]["kind"], text: string) {
    this.state.events.push({ kind, text, t: this.state.t });
    if (this.state.events.length > 8) this.state.events.shift();
  }

  /** advance exactly one fixed simulation step (all devices run these in the same order) */
  stepTick() {
    this.state.tick += 1;
    this.step(TICK_DT);
  }

  step(dt: number) {
    const s = this.state;
    if (s.phase === "over") return;
    if (s.phase === "countdown") {
      s.countdown -= dt;
      if (s.countdown <= 0) s.phase = "playing";
      return;
    }
    s.t += dt;

    const bnd = currentBounds(s.t);

    const tier = Math.floor(s.t / RAGE_STEP);
    if (tier > s.wolf.rageTier) {
      s.wolf.rageTier = tier;
      this.push("rage", "⚠️ WOLF IS GETTING FASTER!");
    }

    for (const p of s.players) {
      if (!p.alive) continue;

      const input = this.inputs[p.id] ?? emptyInput();
      const holding = s.ball.holder === p.id;

      // movement
      const len = Math.hypot(input.ax, input.ay);
      const nx = len > 0.05 ? input.ax / len : 0;
      const ny = len > 0.05 ? input.ay / len : 0;
      let speed = PLAYER_SPEED * (holding ? 1.04 : 1);
      if (p.sprintUntil > s.t) speed *= 1.8;
      if (p.dashUntil > s.t) speed *= 2.9;
      p.vx = nx * speed;
      p.vy = ny * speed;
      // clamp to shrinking walls; if a wall pushed past, pull inside
      p.x = clamp(p.x + p.vx * dt, bnd.left + PLAYER_R, bnd.right - PLAYER_R);
      p.y = clamp(p.y + p.vy * dt, bnd.top + PLAYER_R, bnd.bottom - PLAYER_R);
      // aim follows the pointer/aim stick
      if (Number.isFinite(input.aim) && input.aim !== 0) p.aim = input.aim;
      else if (len > 0.05) p.aim = Math.atan2(ny, nx);

      // charge while holding the orb
      if (holding) {
        p.holdSeconds += dt;
        while (p.holdSeconds >= 1 && p.charges < CHARGE_CAP) {
          p.holdSeconds -= 1;
          p.charges += 1;
        }
        if (p.charges >= CHARGE_CAP) p.holdSeconds = 0;
      }

      // skill
      if (input.skill) {
        this.inputs[p.id]!.skill = false;
        this.useSkill(p);
      }

      // shoot
      if (input.shoot) {
        this.inputs[p.id]!.shoot = false;
        if (holding) {
          const a = input.aim ?? p.aim;
          s.ball.holder = null;
          s.ball.lastHolder = p.id;
          s.ball.grace = 0.35;
          s.ball.bounces = 0;
          s.ball.x = p.x + Math.cos(a) * (PLAYER_R + BALL_R + 4);
          s.ball.y = p.y + Math.sin(a) * (PLAYER_R + BALL_R + 4);
          s.ball.vx = Math.cos(a) * BALL_SPEED;
          s.ball.vy = Math.sin(a) * BALL_SPEED;
          this.push("pass", `${p.name} ยิงลูกแก้วออกไป 💥`);
        }
      }
    }

    this.stepBall(dt, bnd);
    this.stepWolf(dt, bnd);

    const alive = s.players.filter((p) => p.alive);
    // solo practice ends when the single player dies; matches end at one survivor
    if (s.players.length > 1 ? alive.length <= 1 : alive.length === 0) {
      s.phase = "over";
      s.winner = alive[0]?.id ?? null;
    }
  }

  private useSkill(p: PlayerState) {
    const s = this.state;
    if (p.charges < SKILL_COST) return;
    const ch = getCharacter(p.charId);
    const spec = skillSpec(ch);
    const holding = s.ball.holder === p.id;
    if (spec.kind === "vanish" && holding) return;
    p.charges -= SKILL_COST;
    p.skillFlash = s.t;
    switch (spec.kind) {
      case "dash": {
        const bnd = currentBounds(s.t);
        p.x = clamp(p.x + Math.cos(p.aim) * spec.value, bnd.left + PLAYER_R, bnd.right - PLAYER_R);
        p.y = clamp(p.y + Math.sin(p.aim) * spec.value, bnd.top + PLAYER_R, bnd.bottom - PLAYER_R);
        break;
      }
      case "speed":
        p.sprintUntil = s.t + spec.value;
        break;
      case "vanish":
        p.vanishUntil = s.t + spec.value;
        break;
      case "slowWolf":
        s.wolf.slowUntil = s.t + spec.value;
        break;
      case "shield":
        p.shieldUntil = s.t + spec.value;
        break;
      case "hasteWolf":
        s.wolf.hasteUntil = s.t + spec.value;
        break;
    }
    this.push("skill", `${p.name} ใช้ ${ch.skillName}!`);
  }

  private stepBall(dt: number, bnd: Rect) {
    const s = this.state;
    const b = s.ball;
    b.grace = Math.max(0, b.grace - dt);
    const holder = this.player(b.holder);
    if (holder) {
      b.x = holder.x;
      b.y = holder.y + 4;
      b.vx = 0;
      b.vy = 0;
      return;
    }
    b.x += b.vx * dt;
    b.y += b.vy * dt;
    let bounced = false;
    if (b.x < bnd.left + BALL_R) {
      b.x = bnd.left + BALL_R;
      b.vx = Math.abs(b.vx);
      bounced = true;
    } else if (b.x > bnd.right - BALL_R) {
      b.x = bnd.right - BALL_R;
      b.vx = -Math.abs(b.vx);
      bounced = true;
    }
    if (b.y < bnd.top + BALL_R) {
      b.y = bnd.top + BALL_R;
      b.vy = Math.abs(b.vy);
      bounced = true;
    } else if (b.y > bnd.bottom - BALL_R) {
      b.y = bnd.bottom - BALL_R;
      b.vy = -Math.abs(b.vy);
      bounced = true;
    }
    if (bounced) {
      b.bounces += 1;
      const sp = Math.min(BALL_MAX_SPEED, Math.hypot(b.vx, b.vy) * 1.07);
      const a = Math.atan2(b.vy, b.vx);
      b.vx = Math.cos(a) * sp;
      b.vy = Math.sin(a) * sp;
      if (b.bounces === 1 || b.bounces % 3 === 0) this.push("bounce", `🧱 BOUNCE x${b.bounces}`);
    }

    // after a few bounces the orb starts hunting the nearest player
    if (b.bounces >= 3) {
      let best: PlayerState | undefined;
      let bd = Infinity;
      for (const p of s.players) {
        if (!p.alive || p.vanishUntil > s.t) continue;
        const d = Math.hypot(p.x - b.x, p.y - b.y);
        if (d < bd) {
          bd = d;
          best = p;
        }
      }
      if (best) {
        const want = Math.atan2(best.y - b.y, best.x - b.x);
        const cur = Math.atan2(b.vy, b.vx);
        let diff = want - cur;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        const steer = Math.min(Math.abs(diff), 1.6 * dt) * Math.sign(diff);
        const sp = Math.hypot(b.vx, b.vy);
        b.vx = Math.cos(cur + steer) * sp;
        b.vy = Math.sin(cur + steer) * sp;
      }
    }

    for (const p of s.players) {
      if (!p.alive) continue;
      if (p.vanishUntil > s.t) continue;
      if (b.grace > 0 && b.lastHolder === p.id) continue;
      const d = Math.hypot(p.x - b.x, p.y - b.y);
      if (d > PLAYER_R + BALL_R) continue;
      if (p.shieldUntil > s.t) {
        const a = Math.atan2(b.y - p.y, b.x - p.x);
        const sp = Math.hypot(b.vx, b.vy);
        b.vx = Math.cos(a) * sp;
        b.vy = Math.sin(a) * sp;
        b.x = p.x + Math.cos(a) * (PLAYER_R + BALL_R + 6);
        b.y = p.y + Math.sin(a) * (PLAYER_R + BALL_R + 6);
        continue;
      }
      b.holder = p.id;
      b.lastHolder = null;
      b.bounces = 0;
      s.wolf.target = p.id;
      this.push("pass", `🐺 TARGET CHANGED → ${p.name}`);
      break;
    }
  }

  private stepWolf(dt: number, bnd: Rect) {
    const s = this.state;
    const w = s.wolf;
    const rageMul =
      [1, 1.1, 1.25, 1.4, 1.6][Math.min(w.rageTier, 4)] ?? 1.6 + (w.rageTier - 4) * 0.15;
    let speed = WOLF_BASE_SPEED * rageMul;
    if (w.slowUntil > s.t) speed *= 0.45;
    if (w.hasteUntil > s.t) speed *= 1.55;

    const dashing = w.dashUntil > s.t;

    const holder = this.player(s.ball.holder);
    let tx: number;
    let ty: number;
    if (holder && holder.alive && holder.vanishUntil <= s.t) {
      w.target = holder.id;
      tx = holder.x;
      ty = holder.y;
    } else {
      w.target = null;
      tx = s.ball.x;
      ty = s.ball.y;
    }

    if (dashing) {
      // chaotic dash: ignore target, hold the stored dash velocity
      w.vx = w.dashVx;
      w.vy = w.dashVy;
    } else {
      const a = Math.atan2(ty - w.y, tx - w.x);
      const turn = 6.5 * dt;
      const cur = Math.atan2(w.vy, w.vx) || a;
      let diff = a - cur;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      const dir = cur + clamp(diff, -turn, turn);
      w.vx = Math.cos(dir) * speed;
      w.vy = Math.sin(dir) * speed;
    }
    w.x = clamp(w.x + w.vx * dt, bnd.left + WOLF_R, bnd.right - WOLF_R);
    w.y = clamp(w.y + w.vy * dt, bnd.top + WOLF_R, bnd.bottom - WOLF_R);

    // wolf smacks a free orb away
    if (!s.ball.holder) {
      const d = Math.hypot(s.ball.x - w.x, s.ball.y - w.y);
      if (d < WOLF_R + BALL_R) {
        const na = Math.atan2(s.ball.y - w.y, s.ball.x - w.x) + (this.rand() - 0.5) * 0.7;
        const sp = Math.min(
          BALL_MAX_SPEED,
          Math.max(BALL_SPEED, Math.hypot(s.ball.vx, s.ball.vy)) * 1.05,
        );
        s.ball.vx = Math.cos(na) * sp;
        s.ball.vy = Math.sin(na) * sp;
        s.ball.x = w.x + Math.cos(na) * (WOLF_R + BALL_R + 4);
        s.ball.y = w.y + Math.sin(na) * (WOLF_R + BALL_R + 4);
        s.ball.lastHolder = null;
        w.ballHits += 1;
        this.push("bounce", "🐺 หมาป่าปัดลูกแก้ว!");
        if (w.ballHits % WOLF_DASH_HITS === 0) {
          const da = this.rand() * Math.PI * 2;
          const dspeed = speed * 2.1;
          w.dashVx = Math.cos(da) * dspeed;
          w.dashVy = Math.sin(da) * dspeed;
          w.dashUntil = s.t + 0.7;
          this.push("rage", "🌀 หมาป่าพุ่งสุ่ม!");
        }
      }
    }

    // bite: only the orb holder dies
    if (holder && holder.alive && holder.vanishUntil <= s.t) {
      const d = Math.hypot(holder.x - w.x, holder.y - w.y);
      if (d < WOLF_R + PLAYER_R - 6) {
        holder.alive = false;
        s.corpses.push({
          id: holder.id,
          name: holder.name,
          charId: holder.charId,
          x: holder.x,
          y: holder.y,
          t: s.t,
        });
        this.push("death", `💀 ${holder.name} โดนหมาป่ากัด!`);
        // orb drops and flies off in a random direction
        s.ball.holder = null;
        s.ball.lastHolder = null;
        const na = this.rand() * Math.PI * 2;
        s.ball.vx = Math.cos(na) * BALL_SPEED * 0.9;
        s.ball.vy = Math.sin(na) * BALL_SPEED * 0.9;
        s.ball.bounces = 0;
      }
    }
  }
}

function spawnSpots(n: number) {
  const spots: { x: number; y: number }[] = [];
  const rx = ARENA.w * 0.36;
  const ry = ARENA.h * 0.34;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 - Math.PI / 2;
    spots.push({ x: ARENA.w / 2 + Math.cos(a) * rx, y: ARENA.h / 2 + Math.sin(a) * ry });
  }
  return spots;
}

/**
 * Final standing of a player once the match is over.
 * Winner (last alive) = 1st. Dead players are ranked by recency of death:
 * the last to die places 2nd, the first to die places last.
 */
export function placementOf(state: GameState, playerId: string): number {
  const n = state.players.length;
  if (state.winner === playerId) return 1;
  const idx = state.corpses.findIndex((c) => c.id === playerId);
  if (idx === -1) return n;
  return n - idx;
}
