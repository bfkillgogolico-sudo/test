export type SkillId = "dash" | "sprint" | "vanish" | "chill" | "bulwark" | "blink";

export type GameCharacter = {
  id: string;
  name: string;
  emoji: string;
  skill: SkillId;
  skillName: string;
  desc: string;
  color: string;
  /** low-poly 3D model used in the arena */
  model: string;
  sprite?: { url: string; frames: number; cellW: number; cellH: number };
  /** color to tint the 3D model with (gacha pets) */
  tint?: string | null;
  pattern?: string | null;
  patternTint?: string | null;
  /** skill parameters for gacha pets */
  spec?: { kind: import("./pets").SkillKind; value: number };
};

export const CHARACTERS: GameCharacter[] = [
  {
    id: "scout",
    name: "Fox",
    emoji: "🦊",
    skill: "dash",
    skillName: "Dash",
    desc: "พุ่งไปข้างหน้าอย่างรวดเร็ว หนีหมาป่าในจังหวะคับขัน",
    color: "#f0a13c",
    model: "/models/fox.glb",
  },
  {
    id: "bolt",
    name: "Bunny",
    emoji: "🐰",
    skill: "sprint",
    skillName: "Overdrive",
    desc: "เพิ่มความเร็วการเคลื่อนที่ 80% เป็นเวลา 3 วินาที",
    color: "#ffe066",
    model: "/models/bunny.glb",
  },
  {
    id: "wisp",
    name: "Crab",
    emoji: "🦀",
    skill: "vanish",
    skillName: "Vanish",
    desc: "หายตัว 3 วินาที ลูกแก้วและหมาป่าจะมองไม่เห็น (ใช้ได้เมื่อไม่ถือลูกแก้ว)",
    color: "#a5d8ff",
    model: "/models/crab.glb",
  },
  {
    id: "frost",
    name: "Polar",
    emoji: "🐻‍❄️",
    skill: "chill",
    skillName: "Deep Freeze",
    desc: "สโลว์หมาป่าลง 55% เป็นเวลา 3 วินาที",
    color: "#74c0fc",
    model: "/models/polar.glb",
  },
  {
    id: "bastion",
    name: "Panda",
    emoji: "🐼",
    skill: "bulwark",
    skillName: "Bulwark",
    desc: "สร้างกำแพงพลังรอบตัว 3 วินาที ลูกแก้วจะเด้งออกไม่ติดตัว",
    color: "#8ce99a",
    model: "/models/panda.glb",
  },
  {
    id: "trick",
    name: "Monkey",
    emoji: "🐵",
    skill: "blink",
    skillName: "Blink",
    desc: "วาร์ปไปข้างหน้าทันที ทะลุจังหวะไล่ของหมาป่า",
    color: "#d0bfff",
    model: "/models/monkey.glb",
  },
];

export const STARTER_CHARACTER = "scout";

export function getCharacter(id: string): GameCharacter {
  return petCharacter(id) ?? CHARACTERS.find((c) => c.id === id) ?? CHARACTERS[0]!;
}

/* ── pet-instance characters (gacha) ─────────────────────────────────────── */

import { getAnimal, getColor, getSkill, type Pet } from "./pets";
import type { SkillKind } from "./pets";

export type SkillSpec = { kind: SkillKind; value: number };

const registry = new Map<string, GameCharacter>();

/** turn a rolled pet row into a playable character (model + tint + skill) */
export function petToCharacter(pet: Pet): GameCharacter {
  const a = getAnimal(pet.animal);
  const c = getColor(pet.color);
  const sk = getSkill(pet.skill);
  return {
    id: pet.id,
    name: a.name,
    emoji: a.emoji,
    skill: "dash",
    skillName: sk.name,
    desc: sk.desc,
    color: c.hex ?? "#ffffff",
    model: a.model,
    tint: c.hex,
    pattern: pet.pattern,
    patternTint: getColor(pet.pattern_color).hex,
    spec: { kind: sk.kind, value: sk.value },
  };
}

export function registerPets(pets: Pet[]) {
  for (const p of pets) registry.set(p.id, petToCharacter(p));
}

const LEGACY_SPEC: Record<SkillId, SkillSpec> = {
  dash: { kind: "dash", value: 300 },
  sprint: { kind: "speed", value: 3 },
  vanish: { kind: "vanish", value: 3 },
  chill: { kind: "slowWolf", value: 3 },
  bulwark: { kind: "shield", value: 3 },
  blink: { kind: "dash", value: 380 },
};

export function skillSpec(ch: GameCharacter): SkillSpec {
  return ch.spec ?? LEGACY_SPEC[ch.skill];
}

export function petCharacter(id: string): GameCharacter | undefined {
  return registry.get(id);
}
