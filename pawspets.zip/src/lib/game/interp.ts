import type { GameState } from "./engine";

/**
 * Guests receive host snapshots ~20x/second. Rendering them raw makes movement
 * look choppy, so we keep the two latest snapshots and render a point in
 * between, slightly behind real time. The delay adapts to how jittery the
 * incoming snapshots actually are, and when a snapshot is late we extrapolate
 * with the last known velocity instead of freezing.
 */
const MIN_DELAY = 0.06;
const MAX_DELAY = 0.24;
const MAX_EXTRAPOLATE = 0.25;

const lerp = (a: number, b: number, k: number) => a + (b - a) * k;

export class StateInterpolator {
  private prev: GameState | null = null;
  private next: GameState | null = null;
  private prevAt = 0;
  private nextAt = 0;
  private avgGap = 0.05;
  private delay = 0.08;

  /** seconds since the newest snapshot arrived (Infinity before the first one) */
  staleFor(now: number) {
    return this.next ? now - this.nextAt : Infinity;
  }

  latest() {
    return this.next;
  }

  push(s: GameState, now: number) {
    if (this.next && s.t < this.next.t) return; // out-of-order packet
    if (this.next) {
      const gap = now - this.nextAt;
      if (gap > 0 && gap < 1) this.avgGap = this.avgGap * 0.8 + gap * 0.2;
      this.delay = Math.max(MIN_DELAY, Math.min(MAX_DELAY, this.avgGap * 1.6));
    }
    this.prev = this.next ?? s;
    this.prevAt = this.next ? this.nextAt : now;
    this.next = s;
    this.nextAt = now;
  }

  /** Interpolated snapshot, or null when nothing has arrived yet. */
  sample(now: number): GameState | null {
    const a = this.prev;
    const b = this.next;
    if (!b) return null;
    if (!a || this.nextAt <= this.prevAt) return b;

    const span = this.nextAt - this.prevAt;
    const target = now - this.delay;

    if (target > this.nextAt) {
      // snapshot is late: dead-reckon forward with the last known velocities
      const e = Math.min(MAX_EXTRAPOLATE, target - this.nextAt);
      return {
        ...b,
        players: b.players.map((p) => (p.alive ? { ...p, x: p.x + p.vx * e, y: p.y + p.vy * e } : p)),
        ball: { ...b.ball, x: b.ball.x + b.ball.vx * e, y: b.ball.y + b.ball.vy * e },
        wolf: { ...b.wolf, x: b.wolf.x + b.wolf.vx * e, y: b.wolf.y + b.wolf.vy * e },
        t: b.t + e,
      };
    }

    const k = Math.max(0, Math.min(1, (target - this.prevAt) / span));

    // discrete fields always come from the newest snapshot
    return {
      ...b,
      players: b.players.map((p) => {
        const q = a.players.find((r) => r.id === p.id);
        if (!q || !p.alive) return p;
        return { ...p, x: lerp(q.x, p.x, k), y: lerp(q.y, p.y, k) };
      }),
      ball: { ...b.ball, x: lerp(a.ball.x, b.ball.x, k), y: lerp(a.ball.y, b.ball.y, k) },
      wolf: { ...b.wolf, x: lerp(a.wolf.x, b.wolf.x, k), y: lerp(a.wolf.y, b.wolf.y, k) },
      t: lerp(a.t, b.t, k),
    };
  }
}

/**
 * Moves the local player immediately from their own input, then eases toward
 * the authoritative position, so your own character never feels laggy.
 */
export class LocalPredictor {
  private x = 0;
  private y = 0;
  private ready = false;

  apply(s: GameState, selfId: string, ax: number, ay: number, speed: number, dt: number): GameState {
    const idx = s.players.findIndex((p) => p.id === selfId);
    const me = s.players[idx];
    if (!me || !me.alive) {
      this.ready = false;
      return s;
    }
    if (!this.ready) {
      this.x = me.x;
      this.y = me.y;
      this.ready = true;
    }
    const len = Math.hypot(ax, ay);
    if (len > 0.05) {
      this.x += (ax / len) * speed * dt;
      this.y += (ay / len) * speed * dt;
    }
    // reconcile: pull toward the server truth, snap when far off
    const dx = me.x - this.x;
    const dy = me.y - this.y;
    const off = Math.hypot(dx, dy);
    const k = off > 140 ? 1 : Math.min(1, 9 * dt);
    this.x += dx * k;
    this.y += dy * k;

    const players = s.players.slice();
    players[idx] = { ...me, x: this.x, y: this.y };
    return { ...s, players };
  }
}
