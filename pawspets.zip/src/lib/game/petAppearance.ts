import * as THREE from "three";

type PetAppearance = {
  tint?: string | null | undefined;
  pattern?: string | null | undefined;
  patternTint?: string | null | undefined;
};

/** Only patterns that actually read well on the cube-pet models are shipped. */
const PATTERN_IDS: Record<string, number> = {
  plain: 0,
  stripes: 2,
  gradient: 4,
  sparkle: 5,
};

/** Recolours fur while retaining the model's dark facial details and texture. */
export function applyPetAppearance(material: THREE.Material, appearance: PetAppearance) {
  const source = material as THREE.MeshStandardMaterial;
  const mat = source.clone();

  const pattern = PATTERN_IDS[appearance.pattern ?? "plain"] ?? 0;
  const hasTint = Boolean(appearance.tint);
  const hasPattern = pattern !== 0;
  if (!hasTint && !hasPattern) return mat;

  const base = new THREE.Color(appearance.tint ?? "#c9884a");
  // No pattern colour rolled: use a darker shade of the body so the pattern still reads.
  const accent = appearance.patternTint
    ? new THREE.Color(appearance.patternTint)
    : base.clone().multiplyScalar(0.45);


  if (hasTint) mat.color.set(0xffffff);
  mat.vertexColors = false;
  mat.onBeforeCompile = (shader) => {
    shader.vertexShader = shader.vertexShader
      .replace("void main() {", "varying vec3 vPetPosition;\nvoid main() {")
      .replace("#include <begin_vertex>", "#include <begin_vertex>\nvPetPosition = transformed;");

    shader.fragmentShader = shader.fragmentShader
      .replace("void main() {", "varying vec3 vPetPosition;\nvoid main() {")
      .replace(
        "#include <map_fragment>",
        `#include <map_fragment>
        {
          vec3 originalPetColor = diffuseColor.rgb;
          float petMax = max(originalPetColor.r, max(originalPetColor.g, originalPetColor.b));
          float petMin = min(originalPetColor.r, min(originalPetColor.g, originalPetColor.b));
          float petSaturation = petMax - petMin;
          // Eyes, nose, mouth and other dark details stay exactly as authored.
          float furMask = smoothstep(0.16, 0.34, petMax) * smoothstep(0.035, 0.16, petSaturation);
          vec3 petBase = ${hasTint ? `mix(originalPetColor, vec3(${base.r}, ${base.g}, ${base.b}), 0.92)` : "originalPetColor"};
          float petPattern = 0.0;
          // Low-frequency mask so a pattern only shows on a few patches of the body.
          float petRegion = smoothstep(0.35, 0.95,
            sin(vPetPosition.x * 4.0 + 1.3) * 0.5 + sin(vPetPosition.y * 3.1) * 0.3 + sin(vPetPosition.z * 3.7) * 0.4 + 0.5);
          if (${pattern} == 2) {
            petPattern = smoothstep(0.72, 0.86, sin((vPetPosition.x + vPetPosition.y * 0.55) * 18.0) * 0.5 + 0.5) * petRegion;
          } else if (${pattern} == 4) {
            petPattern = smoothstep(0.18, 0.52, vPetPosition.y) * 0.5;
          } else if (${pattern} == 5) {
            vec2 cell = fract((vPetPosition.xz + vPetPosition.yy * 0.3) * 8.0) - 0.5;
            float diamond = abs(cell.x) + abs(cell.y);
            petPattern = (1.0 - smoothstep(0.07, 0.13, diamond)) * petRegion;
          }
          vec3 recolouredPet = mix(petBase, vec3(${accent.r}, ${accent.g}, ${accent.b}), petPattern * 0.9);

          diffuseColor.rgb = mix(originalPetColor, recolouredPet, furMask);
        }`,
      );
  };
  mat.customProgramCacheKey = () => `${appearance.tint}-${appearance.pattern}-${appearance.patternTint}`;
  mat.needsUpdate = true;
  return mat;
}
