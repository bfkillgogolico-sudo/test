/* ── ความเครียดของสัตว์ (หลอดสีเหลือง) ─────────────────────────────────────
 * อยู่ในคลังนาน ๆ ความเครียดจะค่อย ๆ ลด ต้องเอาออกมาเดินเล่นในฟาร์มให้คลายเครียด
 * ถ้าหลอดหมด อัตราการสร้างเครดิตของตัวนั้นจะร่วงเหลือ 0.01 ต้องไปอัปเกรดใหม่ */

export const STRESS_MAX = 100;

/** อยู่ในคลัง: เครียดขึ้นเรื่อย ๆ — หลอดหมดในราว 6 ชั่วโมง */
export const STRESS_DECAY_PER_SEC = STRESS_MAX / (6 * 3600);

/** เดินเล่นในฟาร์ม: คลายเครียดเต็มหลอดในราว 20 นาที */
export const STRESS_GAIN_PER_SEC = STRESS_MAX / (20 * 60);

/** อัตราเครดิตต่ำสุดเมื่อเครียดจนหลอดหมด */
export const MIN_CREDIT_RATE = 0.01;

export const clampStress = (v: number) => Math.max(0, Math.min(STRESS_MAX, v));

/** ความเครียดที่เหลือหลังอยู่ในคลังมาแล้ว elapsedSec วินาที */
export const decayedStress = (stress: number, elapsedSec: number) =>
  clampStress(stress - Math.max(0, elapsedSec) * STRESS_DECAY_PER_SEC);
