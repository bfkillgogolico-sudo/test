/** Tiny WebAudio sound-effect engine (synthesized, no asset downloads). */

type Ctx = AudioContext & { __unlocked?: boolean };

let ctx: Ctx | null = null;
let master: GainNode | null = null;
let muted = false;

const STORAGE_KEY = "wolforb.muted";

export function initSfx() {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC() as Ctx;
    master = ctx.createGain();
    master.gain.value = 0.5;
    master.connect(ctx.destination);
    try {
      muted = localStorage.getItem(STORAGE_KEY) === "1";
    } catch {
      muted = false;
    }
    if (master) master.gain.value = muted ? 0 : 0.5;
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

export function isMuted() {
  return muted;
}

export function toggleMute() {
  initSfx();
  muted = !muted;
  if (master) master.gain.value = muted ? 0 : 0.5;
  try {
    localStorage.setItem(STORAGE_KEY, muted ? "1" : "0");
  } catch {
    /* ignore */
  }
  return muted;
}

type ToneOpts = {
  freq: number;
  to?: number;
  dur?: number;
  type?: OscillatorType;
  gain?: number;
  delay?: number;
};

function tone({ freq, to, dur = 0.15, type = "sine", gain = 0.3, delay = 0 }: ToneOpts) {
  const c = initSfx();
  if (!c || !master || muted) return;
  const t0 = c.currentTime + delay;
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t0);
  if (to && to !== freq) osc.frequency.exponentialRampToValueAtTime(Math.max(20, to), t0 + dur);
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(gain, t0 + Math.min(0.02, dur / 3));
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  osc.connect(g).connect(master);
  osc.start(t0);
  osc.stop(t0 + dur + 0.02);
}

function noise(dur = 0.2, gain = 0.25, filterHz = 1200, delay = 0) {
  const c = initSfx();
  if (!c || !master || muted) return;
  const t0 = c.currentTime + delay;
  const frames = Math.floor(c.sampleRate * dur);
  const buf = c.createBuffer(1, frames, c.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < frames; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / frames);
  const src = c.createBufferSource();
  src.buffer = buf;
  const f = c.createBiquadFilter();
  f.type = "lowpass";
  f.frequency.value = filterHz;
  const g = c.createGain();
  g.gain.setValueAtTime(gain, t0);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  src.connect(f).connect(g).connect(master);
  src.start(t0);
}

export const sfx = {
  shoot() {
    tone({ freq: 880, to: 220, dur: 0.16, type: "triangle", gain: 0.25 });
    noise(0.08, 0.12, 2400);
  },
  bounce() {
    tone({ freq: 520, to: 380, dur: 0.09, type: "square", gain: 0.16 });
  },
  catch() {
    tone({ freq: 420, to: 760, dur: 0.14, type: "sine", gain: 0.26 });
    tone({ freq: 640, to: 1040, dur: 0.12, type: "sine", gain: 0.14, delay: 0.05 });
  },
  skill() {
    tone({ freq: 300, to: 1200, dur: 0.28, type: "sawtooth", gain: 0.18 });
    tone({ freq: 900, to: 1800, dur: 0.2, type: "sine", gain: 0.12, delay: 0.08 });
  },
  death() {
    tone({ freq: 260, to: 60, dur: 0.5, type: "sawtooth", gain: 0.3 });
    noise(0.4, 0.28, 700);
  },
  rage() {
    tone({ freq: 120, to: 55, dur: 0.7, type: "sawtooth", gain: 0.3 });
    noise(0.6, 0.2, 500, 0.05);
  },
  countdown() {
    tone({ freq: 660, dur: 0.12, type: "square", gain: 0.2 });
  },
  start() {
    tone({ freq: 520, to: 1040, dur: 0.3, type: "square", gain: 0.24 });
  },
  win() {
    [523, 659, 784, 1046].forEach((f, i) => tone({ freq: f, dur: 0.25, type: "triangle", gain: 0.22, delay: i * 0.13 }));
  },
  coin() {
    tone({ freq: 1245, dur: 0.1, type: "square", gain: 0.16 });
    tone({ freq: 1660, dur: 0.22, type: "square", gain: 0.18, delay: 0.07 });
    tone({ freq: 2093, dur: 0.3, type: "sine", gain: 0.12, delay: 0.12 });
  },
  lose() {
    [440, 349, 262].forEach((f, i) => tone({ freq: f, dur: 0.3, type: "triangle", gain: 0.2, delay: i * 0.15 }));
  },
};
