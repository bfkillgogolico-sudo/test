import { useEffect, useState } from "react";

export type Quality = "low" | "medium" | "high";

export const QUALITY_LABELS: Record<Quality, string> = {
  low: "ต่ำ (ลื่นสุด)",
  medium: "กลาง",
  high: "สูง (สวยสุด)",
};

export type QualityConfig = {
  dpr: [number, number];
  shadows: boolean;
  shadowMap: number;
  antialias: boolean;
  env: boolean;
  fog: [number, number];
  nameTags: boolean;
};

export const QUALITY: Record<Quality, QualityConfig> = {
  low: {
    dpr: [0.55, 0.85],
    shadows: false,
    shadowMap: 512,
    antialias: false,
    env: false,
    fog: [18, 34],
    nameTags: false,
  },
  medium: {
    dpr: [0.9, 1.15],
    shadows: true,
    shadowMap: 1024,
    antialias: false,
    env: true,
    fog: [24, 42],
    nameTags: true,
  },
  high: {
    dpr: [1, 1.5],
    shadows: true,
    shadowMap: 2048,
    antialias: true,
    env: true,
    fog: [26, 46],
    nameTags: true,
  },
};

const KEY = "pawpets.quality";
const listeners = new Set<(q: Quality) => void>();

function detectDefault(): Quality {
  if (typeof navigator === "undefined") return "medium";
  const touch = "ontouchstart" in window || navigator.maxTouchPoints > 0;
  const cores = navigator.hardwareConcurrency ?? 4;
  if (touch || cores <= 4) return "low";
  return cores >= 8 ? "high" : "medium";
}

export function getQuality(): Quality {
  if (typeof window === "undefined") return "medium";
  const v = window.localStorage.getItem(KEY);
  if (v === "low" || v === "medium" || v === "high") return v;
  return detectDefault();
}

export function setQuality(q: Quality) {
  if (typeof window !== "undefined") window.localStorage.setItem(KEY, q);
  for (const l of listeners) l(q);
}

export function useQuality(): [Quality, (q: Quality) => void] {
  const [q, setQ] = useState<Quality>("medium");
  useEffect(() => {
    setQ(getQuality());
    const l = (next: Quality) => setQ(next);
    listeners.add(l);
    return () => listeners.delete(l) as unknown as void;
  }, []);
  return [q, setQuality];
}
