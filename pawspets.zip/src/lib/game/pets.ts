/* ── Kenney Cube Pets gacha system ─────────────────────────────────────── */

export type PetAnimal = { id: string; name: string; emoji: string; model: string; stars: number };

const A = (id: string, name: string, emoji: string, stars: number): PetAnimal => ({
  id,
  name,
  emoji,
  model: `/models/pets/animal-${id}.glb`,
  stars,
});

/** every animal shipped in the Kenney Cube Pets pack — ดาวตายตัวต่อชนิด */
export const ANIMALS: PetAnimal[] = [
  /* 1★ */
  A("bee", "Bee", "🐝", 1),
  A("chick", "Chick", "🐤", 1),
  A("fish", "Fish", "🐟", 1),
  A("caterpillar", "Caterpillar", "🐛", 1),
  A("crab", "Crab", "🦀", 1),
  A("monkey", "Monkey", "🐵", 1),
  /* 2★ */
  A("bunny", "Bunny", "🐰", 2),
  A("cat", "Cat", "🐱", 2),
  A("dog", "Dog", "🐶", 2),
  A("pig", "Pig", "🐷", 2),
  A("hog", "Hog", "🐗", 2),
  /* 3★ */
  A("cow", "Cow", "🐮", 3),
  A("beaver", "Beaver", "🦫", 3),
  A("koala", "Koala", "🐨", 3),
  A("parrot", "Parrot", "🦜", 3),
  A("penguin", "Penguin", "🐧", 3),
  /* 4★ */
  A("fox", "Fox", "🦊", 4),
  A("deer", "Deer", "🦌", 4),
  A("panda", "Panda", "🐼", 4),
  /* 5★ */
  A("tiger", "Tiger", "🐯", 5),
  A("lion", "Lion", "🦁", 5),
  A("elephant", "Elephant", "🐘", 5),
  /* 6★ */
  A("giraffe", "Giraffe", "🦒", 6),
  A("polar", "Polar Bear", "🐻‍❄️", 6),
];

export function getAnimal(id: string): PetAnimal {
  return ANIMALS.find((a) => a.id === id) ?? ANIMALS[0]!;
}

/** ดาวประจำชนิดสัตว์ */
export function animalStars(id: string): number {
  return getAnimal(id).stars;
}

/** สัตว์แยกตามหมวดดาว (1★ → 6★) สำหรับแสดงในร้านค้า */
export const ANIMAL_STAR_GROUPS: { stars: number; animals: PetAnimal[] }[] = [1, 2, 3, 4, 5, 6]
  .map((s) => ({ stars: s, animals: ANIMALS.filter((a) => a.stars === s) }))
  .filter((g) => g.animals.length > 0);


/* ── colors ─────────────────────────────────────────────────────────────── */

export type PetColor = { id: string; name: string; hex: string | null; exclusive?: boolean };

export const COLORS: PetColor[] = [
  { id: "normal", name: "สีปกติ", hex: null },
  { id: "red", name: "แดง", hex: "#e64545" },
  { id: "orange", name: "ส้ม", hex: "#f28a2e" },
  { id: "yellow", name: "เหลือง", hex: "#f2d33c" },
  { id: "sky", name: "ฟ้า", hex: "#63c9f2" },
  { id: "blue", name: "น้ำเงิน", hex: "#3b62d6" },
  { id: "purple", name: "ม่วง", hex: "#9a5cd6" },
  { id: "pink", name: "ชมพู", hex: "#f277b6" },
  { id: "brown", name: "น้ำตาล", hex: "#8a5a34" },
  { id: "grey", name: "เทา", hex: "#8d939c" },

  /* ── upgrade-only colours (ไม่ออกจากร้านค้า สุ่มได้จากการอัปเกรดเท่านั้น) ── */
  { id: "crimson", name: "แดงเลือดหมู", hex: "#a11133", exclusive: true },
  { id: "wine", name: "ไวน์", hex: "#6d1030", exclusive: true },
  { id: "coral", name: "คอรัล", hex: "#ff7f6b", exclusive: true },
  { id: "peach", name: "พีช", hex: "#ffb59b", exclusive: true },
  { id: "amber", name: "อำพัน", hex: "#ffa63d", exclusive: true },
  { id: "gold", name: "ทอง", hex: "#ffd24a", exclusive: true },
  { id: "bronze", name: "บรอนซ์", hex: "#b0793a", exclusive: true },
  { id: "copper", name: "ทองแดง", hex: "#c96f3a", exclusive: true },
  { id: "cream", name: "ครีม", hex: "#f6e7c6", exclusive: true },
  { id: "sand", name: "ทราย", hex: "#dcc08a", exclusive: true },
  { id: "olive", name: "เขียวมะกอก", hex: "#7d8c3a", exclusive: true },
  { id: "lime", name: "เขียวมะนาว", hex: "#b6e33f", exclusive: true },
  { id: "neonGreen", name: "เขียวนีออน", hex: "#4dff8f", exclusive: true },
  { id: "emerald", name: "มรกต", hex: "#22a36b", exclusive: true },
  { id: "jade", name: "หยก", hex: "#4fb98a", exclusive: true },
  { id: "mint", name: "มินต์", hex: "#a9f0d3", exclusive: true },
  { id: "teal", name: "เขียวน้ำทะเล", hex: "#178a8a", exclusive: true },
  { id: "aqua", name: "อควา", hex: "#5ee8e0", exclusive: true },
  { id: "cyan", name: "ไซแอน", hex: "#31d3f2", exclusive: true },
  { id: "ice", name: "ฟ้าน้ำแข็ง", hex: "#cfeeff", exclusive: true },
  { id: "navy", name: "กรมท่า", hex: "#1c2a5e", exclusive: true },
  { id: "indigo", name: "อินดิโก", hex: "#4433b0", exclusive: true },
  { id: "lavender", name: "ลาเวนเดอร์", hex: "#c9b6f7", exclusive: true },
  { id: "plum", name: "พลัม", hex: "#7a3a72", exclusive: true },
  { id: "magenta", name: "บานเย็น", hex: "#e042a8", exclusive: true },
  { id: "neonPink", name: "ชมพูนีออน", hex: "#ff5fd2", exclusive: true },
  { id: "rose", name: "โรสโกลด์", hex: "#e79a94", exclusive: true },
  { id: "blush", name: "ชมพูอ่อน", hex: "#ffd6e2", exclusive: true },
  { id: "chocolate", name: "ช็อกโกแลต", hex: "#4e2f1c", exclusive: true },
  { id: "charcoal", name: "เทาถ่าน", hex: "#3a3f47", exclusive: true },
  { id: "silver", name: "เงิน", hex: "#cfd6de", exclusive: true },
  { id: "white", name: "ขาว", hex: "#f7f8fa", exclusive: true },
  { id: "black", name: "ดำ", hex: "#16181d", exclusive: true },
];

/** สีที่สุ่มได้จากร้านค้า/ไข่ (ไม่รวมสีพิเศษจากการอัปเกรด) */
export const SHOP_COLORS = COLORS.filter((c) => !c.exclusive);

export function getColor(id: string): PetColor {
  return COLORS.find((c) => c.id === id) ?? COLORS[0]!;
}

/* ── patterns ───────────────────────────────────────────────────────────── */

export type PetPattern = { id: string; name: string };

export const PATTERNS: PetPattern[] = [
  { id: "plain", name: "ไม่มีตำหนิ" },
  { id: "stripes", name: "ตำหนิทาง" },
  { id: "gradient", name: "ตำหนิไล่สี" },
  { id: "sparkle", name: "ตำหนิประกาย" },
];


export function getPattern(id: string): PetPattern {
  return PATTERNS.find((p) => p.id === id) ?? PATTERNS[0]!;
}

/* ── skills ─────────────────────────────────────────────────────────────── */

export type SkillKind = "dash" | "speed" | "vanish" | "shield" | "slowWolf" | "hasteWolf";

export type PetSkill = {
  /** stable number stored on the pet row — new skills append new numbers */
  n: number;
  kind: SkillKind;
  /** distance (px) for dash, seconds for everything else */
  value: number;
  name: string;
  desc: string;
};

export const SKILLS: PetSkill[] = [
  { n: 1, kind: "dash", value: 200, name: "Dash I", desc: "พุ่งไปข้างหน้าระยะสั้น" },
  { n: 2, kind: "dash", value: 330, name: "Dash II", desc: "พุ่งไปข้างหน้าระยะกลาง" },
  { n: 3, kind: "dash", value: 480, name: "Dash III", desc: "พุ่งไปข้างหน้าระยะไกล" },
  { n: 4, kind: "speed", value: 2, name: "Sprint I", desc: "วิ่งเร็วขึ้น 2 วินาที" },
  { n: 5, kind: "speed", value: 3, name: "Sprint II", desc: "วิ่งเร็วขึ้น 3 วินาที" },
  { n: 6, kind: "speed", value: 4, name: "Sprint III", desc: "วิ่งเร็วขึ้น 4 วินาที" },
  { n: 7, kind: "vanish", value: 3, name: "Vanish I", desc: "หายตัว 3 วินาที" },
  { n: 8, kind: "vanish", value: 4, name: "Vanish II", desc: "หายตัว 4 วินาที" },
  { n: 9, kind: "vanish", value: 5, name: "Vanish III", desc: "หายตัว 5 วินาที" },
  { n: 10, kind: "shield", value: 2, name: "Bulwark I", desc: "โล่กันบอล 2 วินาที (บอลเด้งออกทันที)" },
  { n: 11, kind: "shield", value: 3, name: "Bulwark II", desc: "โล่กันบอล 3 วินาที (บอลเด้งออกทันที)" },
  { n: 12, kind: "shield", value: 4, name: "Bulwark III", desc: "โล่กันบอล 4 วินาที (บอลเด้งออกทันที)" },
  { n: 13, kind: "slowWolf", value: 3, name: "Freeze I", desc: "สโลว์หมาป่า 3 วินาที" },
  { n: 14, kind: "slowWolf", value: 4, name: "Freeze II", desc: "สโลว์หมาป่า 4 วินาที" },
  { n: 15, kind: "slowWolf", value: 5, name: "Freeze III", desc: "สโลว์หมาป่า 5 วินาที" },
  { n: 16, kind: "hasteWolf", value: 5, name: "Frenzy I", desc: "เพิ่มความเร็วหมาป่า 5 วินาที (เสี่ยงสุด ๆ)" },
  { n: 17, kind: "hasteWolf", value: 6, name: "Frenzy II", desc: "เพิ่มความเร็วหมาป่า 6 วินาที (เสี่ยงสุด ๆ)" },
  { n: 18, kind: "hasteWolf", value: 7, name: "Frenzy III", desc: "เพิ่มความเร็วหมาป่า 7 วินาที (เสี่ยงสุด ๆ)" },
];

export function getSkill(n: number): PetSkill {
  return SKILLS.find((s) => s.n === n) ?? SKILLS[0]!;
}

/* ── pet instance ───────────────────────────────────────────────────────── */

export type Pet = {
  id: string;
  animal: string;
  color: string;
  pattern: string;
  pattern_color: string;
  stars: number;
  skill: number;
  credit_rate: number;
  gender: PetGender;
  /** farm hunger/thirst, kept on the pet so putting it away never refills it */
  food?: number;
  water?: number;
  /** สัตว์ป่วย — ติดไปกับตัวสัตว์แม้เก็บเข้าคลัง */
  sick?: boolean;
  /** ติดพิษจากยาพิษของผู้เล่นอื่น — กระหายน้ำเร็วมาก ใช้ยารักษาได้ */
  poisoned?: boolean;
  /** หลอดความเครียด 0-100 (ลดลงเมื่ออยู่ในคลัง) */
  stress?: number;
  /** เวลาที่คำนวณความเครียดครั้งล่าสุด */
  stress_at?: string;
};

export type PetGender = "male" | "female";

export function genderSymbol(g: PetGender) {
  return g === "female" ? "♀" : "♂";
}

export function genderName(g: PetGender) {
  return g === "female" ? "เพศเมีย ♀" : "เพศผู้ ♂";
}

export const STAR_WEIGHTS = [40, 26, 17, 10, 5, 2];

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]!;
}

/** สุ่มชนิดสัตว์โดยถ่วงน้ำหนักตามหมวดดาว (ดาวสูง = หาได้ยากกว่า) */
export function rollAnimal(): PetAnimal {
  const total = ANIMAL_STAR_GROUPS.reduce((a, g) => a + (STAR_WEIGHTS[g.stars - 1] ?? 1), 0);
  let r = Math.random() * total;
  for (const g of ANIMAL_STAR_GROUPS) {
    r -= STAR_WEIGHTS[g.stars - 1] ?? 1;
    if (r <= 0) return pick(g.animals);
  }
  return pick(ANIMALS);
}


/** ช่วงเรตเครดิตตามหมวดดาว — ดาวสูงเรตสูงกว่า (เริ่มต้นจากค่าต่ำสุดของช่วง) */
export const STAR_CREDIT_RANGES: Record<number, [number, number]> = {
  1: [0.001, 2],
  2: [2, 3],
  3: [3, 4],
  4: [4, 5],
  5: [5, 6],
  6: [6, 10],
};

/**
 * สุ่มเรตเครดิตตามหมวดดาวของสัตว์ ดาวสูง = ช่วงเรตสูงกว่า
 * ใช้โค้ง r⁵ ภายในช่วงนั้น ๆ เพื่อให้ค่าใกล้ขอบบนของช่วงหายาก
 * ค่าน้อยกว่า 1 ปัด 3 ตำแหน่ง (รองรับ 0.001) มากกว่านั้นปัด 2 ตำแหน่ง
 */
export function rollCreditRate(stars = 1) {
  const [min, max] = STAR_CREDIT_RANGES[stars] ?? STAR_CREDIT_RANGES[1]!;
  const v = min + (max - min) * Math.pow(Math.random(), 5);
  const decimals = v < 1 ? 3 : 2;
  const factor = 10 ** decimals;
  return Math.round(v * factor) / factor;
}

/** 50% ไม่มีตำหนิ, 50% มีตำหนิ (สัดส่วนลายยังเป็นแบบเดิม 3:3:2) */
const PATTERN_WEIGHTS: Record<string, number> = {
  plain: 50,
  stripes: 18.75,
  gradient: 18.75,
  sparkle: 12.5,
};

function rollPattern() {
  const total = PATTERNS.reduce((a, p) => a + (PATTERN_WEIGHTS[p.id] ?? 1), 0);
  let r = Math.random() * total;
  for (const p of PATTERNS) {
    r -= PATTERN_WEIGHTS[p.id] ?? 1;
    if (r <= 0) return p.id;
  }
  return "plain";
}

export function rollPetSpec(): Omit<Pet, "id"> {
  const animal = rollAnimal();
  return {
    animal: animal.id,
    color: pick(SHOP_COLORS).id,
    pattern: rollPattern(),
    pattern_color: pick(SHOP_COLORS).id,
    stars: animal.stars,
    skill: pick(SKILLS).n,
    credit_rate: rollCreditRate(animal.stars),
    gender: Math.random() < 0.5 ? "male" : "female",
  };
}



export function petLabel(pet: Pet) {
  const a = getAnimal(pet.animal);
  const c = getColor(pet.color);
  return c.hex ? `${a.name} (${c.name})` : a.name;
}

export function stars(n: number) {
  return "★".repeat(n) + "☆".repeat(Math.max(0, 6 - n));
}
