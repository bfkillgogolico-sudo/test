/**
 * Compact number formatting using k / m / b / t suffixes for large values.
 *
 *  - 1000   -> 1k
 *  - 3923.1 -> 3.9k
 *  - 5_000_000 -> 5m
 *  - 1_200_000_000 -> 1.2b
 *  - 50     -> 50  (no suffix for small numbers)
 *
 * Small values keep their natural precision; only large totals get abbreviated.
 */
export function formatCompact(n: number, decimals = 1): string {
  const abs = Math.abs(n);
  const trim = (v: number) => v.toFixed(decimals).replace(/\.0+$/, "");

  if (abs >= 1e12) return trim(n / 1e12) + "t";
  if (abs >= 1e9) return trim(n / 1e9) + "b";
  if (abs >= 1e6) return trim(n / 1e6) + "m";
  if (abs >= 1e3) return trim(n / 1e3) + "k";

  // small numbers: drop trailing .0 for integers, keep one decimal otherwise
  return Number.isInteger(n)
    ? String(n)
    : trim(n);
}
