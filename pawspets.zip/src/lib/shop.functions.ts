import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { ANIMALS, COLORS, PATTERNS, SKILLS, animalStars, rollCreditRate, type Pet } from "@/lib/game/pets";

/* ── gem prices ────────────────────────────────────────────────────────── */

export const GEM_PRICES = {
  egg: 500,
  expand: 500,
} as const;

/* ── credit prices (consumable items are paid for with 💠 credits) ─────── */

export const CREDIT_PRICES = {
  food: 500,
  milk: 500,
  med: 1000,
  poison: 5000,
  catch: 10000,
  guard: 5000,
} as const;

/** ขยายฟาร์มหนึ่งครั้ง = รองรับสัตว์เพิ่ม 2 ตัว */
export const SLOTS_PER_EXPANSION = 1;
export const MAX_EXPANSIONS = 10;

/** โอกาสได้ยาตอบแทนเมื่อไปให้อาหาร/นมสัตว์ของเพื่อน */
export const HELP_MED_CHANCE = 0.8;
/** โอกาสได้ coin ตอบแทนเมื่อไปให้อาหาร/นมสัตว์ของเพื่อน (สุ่ม 10-50) */
export const HELP_COIN_CHANCE = 0.4;
export const HELP_COIN_MIN = 10;
export const HELP_COIN_MAX = 50;

/**
 * ให้อาหาร/นมสัตว์ของคนอื่น → สัตว์รักเราจนย้ายเข้าคลังเรา
 * โอกาสสูงสุด 2% เมื่อสัตว์อิ่ม (ความหิวต่ำ)
 * ยิ่งค่าความหิวเยอะ (อิ่มน้ำ/อาหารน้อย) โอกาสยิ่งน้อยลง
 * ใช้ satisfaction = (food+water)/2 หลังให้อาหาร/นมแล้ว
 * adoptChance = ADOPT_CHANCE_MAX * (satisfaction/100)
 */
export const ADOPT_CHANCE_MAX = 0.02;

export const GUARD_HOURS = 24;
export const STEAL_BASE = 0.7;

/** สัตว์ติดพิษ: กระหายน้ำเร็วขึ้นมาก แต่หลอดน้ำจะไม่ต่ำกว่านี้ (ไม่ตายจากพิษ) */
export const POISON_WATER_MUL = 8;
export const POISON_WATER_FLOOR = 5;


const PET_COLS = "id, animal, color, pattern, pattern_color, stars, skill, credit_rate, gender";

const pickOne = <T,>(a: T[]): T => a[Math.floor(Math.random() * a.length)]!;

/* ── farm history log ─────────────────────────────────────────────────── */

export const FEED_FOOD = 25;
export const FEED_WATER = 25;

type AdminLike = {
  from: (table: "farm_events") => { insert: (values: Record<string, unknown>) => PromiseLike<unknown> };
};

async function logFarmEvent(
  admin: AdminLike,
  e: { farmUserId: string; actorId: string; actorName: string; petId: string; animal: string; kind: string },
) {
  await admin.from("farm_events").insert({
    farm_user_id: e.farmUserId,
    actor_id: e.actorId,
    actor_name: e.actorName,
    pet_id: e.petId,
    animal: e.animal,
    kind: e.kind,
  });
}

/* ── buy consumable items with credits ────────────────────────────────── */

export const buyItem = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z
      .object({
        kind: z.enum(["food", "milk", "med", "poison", "catch", "guard"]),
        qty: z.number().int().min(1).max(99).default(1),
      })
      .parse(d),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const { data: profile } = await supabase
      .from("profiles")
      .select("credits, food_items, milk_items, med_items, poison_items, catch_items, guard_items")
      .eq("id", userId)
      .maybeSingle();
    if (!profile) return { ok: false as const, reason: "no_profile" as const };

    const cost = CREDIT_PRICES[data.kind] * data.qty;
    const credits = Number(profile.credits ?? 0);
    if (credits < cost) return { ok: false as const, reason: "no_credits" as const, credits };

    const col = `${data.kind}_items`;
    const have = Number((profile as Record<string, number | null>)[col] ?? 0);
    const next = have + data.qty;
    const left = Math.round((credits - cost) * 100) / 100;
    const patch = { credits: left, [col]: next };
    const { error } = await supabase.from("profiles").update(patch as never).eq("id", userId);
    if (error) return { ok: false as const, reason: "failed" as const };
    return { ok: true as const, credits: left, count: next };
  });

/* ── expand the farm: bigger field + 2 more pet slots ─────────────────── */

export const buyFarmExpansion = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data: profile } = await supabase
      .from("profiles")
      .select("gems, farm_expansions")
      .eq("id", userId)
      .maybeSingle();
    if (!profile) return { ok: false as const, reason: "no_profile" as const };
    const have = Number((profile as { farm_expansions?: number }).farm_expansions ?? 0);
    if (have >= MAX_EXPANSIONS) return { ok: false as const, reason: "max" as const, expansions: have };
    const gems = Number(profile.gems ?? 0);
    if (gems < GEM_PRICES.expand) return { ok: false as const, reason: "no_gems" as const, gems };

    const left = gems - GEM_PRICES.expand;
    const { error } = await supabase
      .from("profiles")
      .update({ gems: left, farm_expansions: have + 1 } as never)
      .eq("id", userId);
    if (error) return { ok: false as const, reason: "failed" as const };
    return { ok: true as const, gems: left, expansions: have + 1 };
  });

/* ── buy an egg of a chosen animal (ดาวตายตัวตามชนิด) ─────────────────── */

export const buyEgg = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ animal: z.string().min(1) }).parse(d))
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    if (!ANIMALS.some((a) => a.id === data.animal)) return { ok: false as const, reason: "bad_input" as const };

    const { data: profile } = await supabase.from("profiles").select("gems").eq("id", userId).maybeSingle();
    if (!profile) return { ok: false as const, reason: "no_profile" as const };
    const gems = Number(profile.gems ?? 0);
    if (gems < GEM_PRICES.egg) return { ok: false as const, reason: "no_gems" as const, gems };

    const spec: Omit<Pet, "id"> = {
      animal: data.animal,
      color: COLORS[0]!.id,
      pattern: PATTERNS[0]!.id,
      pattern_color: COLORS[0]!.id,
      stars: animalStars(data.animal),
      skill: pickOne(SKILLS).n,
      credit_rate: rollCreditRate(animalStars(data.animal)),
      gender: Math.random() < 0.5 ? "male" : "female",
    };

    const left = gems - GEM_PRICES.egg;
    const { error: payErr } = await supabase.from("profiles").update({ gems: left }).eq("id", userId);
    if (payErr) return { ok: false as const, reason: "failed" as const };

    const { data: pet } = await supabase
      .from("user_pets")
      .insert({ user_id: userId, ...spec })
      .select(PET_COLS)
      .maybeSingle();
    if (!pet) return { ok: false as const, reason: "failed" as const, gems: left };
    return { ok: true as const, gems: left, pet: { ...pet, credit_rate: Number(pet.credit_rate) } as Pet };
  });

/* ── protect one of my farm pets for 24h ──────────────────────────────── */

export const guardFarmPet = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ rowId: z.string().uuid() }).parse(d))
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const { data: profile } = await supabase
      .from("profiles")
      .select("guard_items")
      .eq("id", userId)
      .maybeSingle();
    const have = Number(profile?.guard_items ?? 0);
    if (have <= 0) return { ok: false as const, reason: "no_item" as const };

    const until = new Date(Date.now() + GUARD_HOURS * 3600_000).toISOString();
    const { data: row, error } = await supabase
      .from("farm_pets")
      .update({ guard_until: until })
      .eq("id", data.rowId)
      .eq("user_id", userId)
      .select("id")
      .maybeSingle();
    if (error || !row) return { ok: false as const, reason: "bad_input" as const };
    await supabase.from("profiles").update({ guard_items: have - 1 }).eq("id", userId);
    return { ok: true as const, guardUntil: until, left: have - 1 };
  });

/* ── steal a pet from a friend's farm ─────────────────────────────────── */

export type StealResult =
  | { ok: false; reason: "no_item" | "bad_input" | "own_farm" | "failed" }
  | { ok: true; stolen: boolean; guarded: boolean; chance: number; left: number; pet?: Pet };

export const stealFarmPet = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ rowId: z.string().uuid() }).parse(d))
  .handler(async ({ context, data }): Promise<StealResult> => {
    const { supabase, userId } = context;
    const { data: profile } = await supabase.from("profiles").select("catch_items").eq("id", userId).maybeSingle();
    const have = Number(profile?.catch_items ?? 0);
    if (have <= 0) return { ok: false, reason: "no_item" };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: row } = await supabaseAdmin
      .from("farm_pets")
      .select("id, user_id, pet_id, food, water, guard_until")
      .eq("id", data.rowId)
      .maybeSingle();
    if (!row) return { ok: false, reason: "bad_input" };
    if (row.user_id === userId) return { ok: false, reason: "own_farm" };

    const { data: target } = await supabaseAdmin
      .from("user_pets")
      .select("animal")
      .eq("id", row.pet_id)
      .maybeSingle();
    const animal = target?.animal ?? "";
    const { data: me } = await supabase.from("profiles").select("username").eq("id", userId).maybeSingle();
    const actorName = me?.username ?? "ผู้เล่น";
    const log = (kind: string) =>
      logFarmEvent(supabaseAdmin, {
        farmUserId: row.user_id,
        actorId: userId,
        actorName,
        petId: row.pet_id,
        animal,
        kind,
      });

    // every attempt consumes the item
    const left = have - 1;
    await supabase.from("profiles").update({ catch_items: left }).eq("id", userId);

    const guarded = row.guard_until !== null && new Date(row.guard_until).getTime() > Date.now();
    if (guarded) {
      await log("steal_guarded");
      return { ok: true, stolen: false, guarded: true, chance: 0, left };
    }

    const { data: siblings } = await supabaseAdmin
      .from("farm_pets")
      .select("id, food")
      .eq("user_id", row.user_id);
    const foods = (siblings ?? []).map((s) => Number(s.food ?? 100));
    const minFood = foods.length ? Math.min(...foods) : Number(row.food ?? 100);
    const food = Math.max(0, Math.min(100, Number(row.food ?? 100)));

    let chance = STEAL_BASE + (1 - food / 100) * 0.25;
    if (food <= minFood + 0.001) chance += 0.05; // hungriest pet in that farm
    chance = Math.max(0, Math.min(0.98, Math.round(chance * 1000) / 1000));

    if (Math.random() >= chance) {
      await log("steal_fail");
      return { ok: true, stolen: false, guarded: false, chance, left };
    }

    const { data: pet } = await supabaseAdmin
      .from("user_pets")
      .update({ user_id: userId })
      .eq("id", row.pet_id)
      .select(PET_COLS)
      .maybeSingle();
    if (!pet) return { ok: false, reason: "failed" };
    await supabaseAdmin.from("farm_pets").delete().eq("id", row.id);
    const { data: victim } = await supabaseAdmin
      .from("profiles")
      .select("selected_pet_id")
      .eq("id", row.user_id)
      .maybeSingle();
    if (victim?.selected_pet_id === row.pet_id) {
      await supabaseAdmin.from("profiles").update({ selected_pet_id: null }).eq("id", row.user_id);
    }
    await log("steal");
    return {
      ok: true,
      stolen: true,
      guarded: false,
      chance,
      left,
      pet: { ...pet, credit_rate: Number(pet.credit_rate) } as Pet,
    };
  });

/* ── feed / water / cure a pet — mine or a friend's ───────────────────── */

export type CareResult =
  | { ok: false; reason: "no_item" | "bad_input" | "not_sick" | "failed" }
  | {
      ok: true;
      kind: "food" | "milk" | "med";
      food: number;
      water: number;
      sick: boolean;
      /** ติดพิษอยู่หรือไม่ (ยารักษาทั้งอาการป่วยและพิษ) */
      poisoned: boolean;
      left: number;
      /** ได้ยาตอบแทนจากการช่วยดูแลสัตว์ของเพื่อน */
      medReward?: boolean;
      medLeft?: number;
      /** ได้ coin ตอบแทนจากการช่วยดูแลสัตว์ของเพื่อน */
      coinReward?: number;
      coins?: number;
      /** สัตว์รักเรามากจนย้ายเข้าคลังเรา (เฉพาะตอนช่วยเลี้ยงสัตว์ของเพื่อน) */
      adopted?: boolean;
      adoptedPet?: Pet | undefined;
    };

export const careFarmPet = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ rowId: z.string().uuid(), kind: z.enum(["food", "milk", "med"]) }).parse(d),
  )
  .handler(async ({ context, data }): Promise<CareResult> => {
    const { supabase, userId } = context;
    const col = `${data.kind}_items`;
    const { data: profile } = await supabase
      .from("profiles")
      .select("username, food_items, milk_items, med_items, coins")
      .eq("id", userId)
      .maybeSingle();
    const have = Number((profile as Record<string, number | null> | null)?.[col] ?? 0);
    if (have <= 0) return { ok: false, reason: "no_item" };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row } = await supabaseAdmin
      .from("farm_pets")
      .select("id, user_id, pet_id, food, water, sick, poisoned")
      .eq("id", data.rowId)
      .maybeSingle();
    if (!row) return { ok: false, reason: "bad_input" };

    const sickNow = row.sick === true;
    const poisonNow = (row as { poisoned?: boolean | null }).poisoned === true;
    /* ยาใช้ได้ทั้งกับสัตว์ป่วยและสัตว์ที่ติดพิษ */
    if (data.kind === "med" && !sickNow && !poisonNow) return { ok: false, reason: "not_sick" };

    let food = Math.max(0, Math.min(100, Number(row.food ?? 100)));
    let water = Math.max(0, Math.min(100, Number(row.water ?? 100)));
    let sick = sickNow;
    let poisoned = poisonNow;
    if (data.kind === "food") food = Math.min(100, food + FEED_FOOD);
    else if (data.kind === "milk") water = Math.min(100, water + FEED_WATER);
    else {
      sick = false;
      poisoned = false;
    }

    const left = have - 1;
    await supabase.from("profiles").update({ [col]: left } as never).eq("id", userId);

    const { error } = await supabaseAdmin
      .from("farm_pets")
      .update({ food, water, sick, poisoned } as never)
      .eq("id", row.id);
    if (error) return { ok: false, reason: "failed" };
    await supabaseAdmin.from("user_pets").update({ food, water, sick, poisoned } as never).eq("id", row.pet_id);


    /* ช่วยให้อาหาร/นมสัตว์ของเพื่อน → โอกาส 80% ได้ยาตอบแทน */
    let medReward = false;
    let medLeft = Number((profile as Record<string, number | null> | null)?.["med_items"] ?? 0);
    if (row.user_id !== userId && data.kind !== "med" && Math.random() < HELP_MED_CHANCE) {
      medReward = true;
      medLeft += 1;
      await supabase.from("profiles").update({ med_items: medLeft } as never).eq("id", userId);
    }

    /* ช่วยให้อาหาร/นมสัตว์ของเพื่อน → โอกาส 40% ได้ coin ตอบแทน 10-50 */
    let coinReward = 0;
    let coins = Number((profile as Record<string, number | null> | null)?.["coins"] ?? 0);
    if (row.user_id !== userId && data.kind !== "med" && Math.random() < HELP_COIN_CHANCE) {
      coinReward = HELP_COIN_MIN + Math.floor(Math.random() * (HELP_COIN_MAX - HELP_COIN_MIN + 1));
      coins += coinReward;
      await supabase.from("profiles").update({ coins } as never).eq("id", userId);
    }

    const actorName = (profile as { username?: string } | null)?.username ?? "ผู้เล่น";
    let adoptedPet: Pet | undefined;

    if (row.user_id !== userId) {
      const { data: target } = await supabaseAdmin
        .from("user_pets")
        .select("animal")
        .eq("id", row.pet_id)
        .maybeSingle();
      await logFarmEvent(supabaseAdmin, {
        farmUserId: row.user_id,
        actorId: userId,
        actorName,
        petId: row.pet_id,
        animal: target?.animal ?? "",
        kind: data.kind,
      });

      /* ให้อาหาร/นมสัตว์ของคนอื่น → สัตว์รักเราจนย้ายเข้าคลังเรา
         ยิ่งค่าความหิวเยอะ (อิ่มน้อย) โอกาสยิ่งน้อย
         ใช้ satisfaction หลังให้อาหาร/นมแล้ว เทียบกับ 2/100 vs 50/100 */
      const satisfaction = (food + water) / 2; // 0..100
      const adoptChance = ADOPT_CHANCE_MAX * (satisfaction / 100);
      if (data.kind !== "med" && Math.random() < adoptChance) {
        const { data: pet } = await supabaseAdmin
          .from("user_pets")
          .update({ user_id: userId })
          .eq("id", row.pet_id)
          .select(PET_COLS)
          .maybeSingle();
        if (pet) {
          await supabaseAdmin.from("farm_pets").delete().eq("id", row.id);
          const { data: victim } = await supabaseAdmin
            .from("profiles")
            .select("selected_pet_id")
            .eq("id", row.user_id)
            .maybeSingle();
          if (victim?.selected_pet_id === row.pet_id) {
            await supabaseAdmin.from("profiles").update({ selected_pet_id: null }).eq("id", row.user_id);
          }
          await logFarmEvent(supabaseAdmin, {
            farmUserId: row.user_id,
            actorId: userId,
            actorName,
            petId: row.pet_id,
            animal: (pet as { animal?: string }).animal ?? "",
            kind: "adopt",
          });
          adoptedPet = { ...pet, credit_rate: Number(pet.credit_rate) } as Pet;
        }
      }
    }

    return {
      ok: true,
      kind: data.kind,
      food,
      water,
      sick,
      poisoned,
      left,
      medReward,
      medLeft,
      coinReward,
      coins,
      adopted: adoptedPet !== undefined,
      adoptedPet,
    };
  });

/* ── care for one of my own pets from the home field ──────────────────── */

export type HomeCareResult =
  | { ok: false; reason: "no_item" | "bad_input" | "not_sick" | "failed" }
  | {
      ok: true;
      kind: "food" | "milk" | "med";
      food: number;
      water: number;
      sick: boolean;
      poisoned: boolean;
      left: number;
      credits: number;
    };

/** ตัวคูณอัตราสร้างเครดิตตามสภาพสัตว์: ป่วย/ติดพิษ เหลือ 25% · หิวหรือกระหาย (<30%) เหลือ 50% */
export function creditRateMultiplier(state: { food: number; water: number; sick: boolean; poisoned: boolean }) {
  if (state.sick || state.poisoned) return 0.25;
  if (state.food < 30 || state.water < 30) return 0.5;
  return 1;
}

/** เครดิตที่สะสมได้จากช่วงเวลาที่ผ่านไป (วินาที) */
export function accrueCredits(creditRate: number, seconds: number, multiplier: number) {
  return Math.max(0, creditRate) * Math.max(0, seconds) * multiplier;
}

export const careMyPet = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ petId: z.string().uuid(), kind: z.enum(["food", "milk", "med"]) }).parse(d),
  )
  .handler(async ({ context, data }): Promise<HomeCareResult> => {
    const { supabase, userId } = context;
    const col = `${data.kind}_items`;
    const { data: profile } = await supabase
      .from("profiles")
      .select("food_items, milk_items, med_items, credits")
      .eq("id", userId)
      .maybeSingle();
    const have = Number((profile as Record<string, number | null> | null)?.[col] ?? 0);
    if (have <= 0) return { ok: false, reason: "no_item" };

    const { data: pet } = await supabase
      .from("user_pets")
      .select("id, food, water, sick, poisoned, credit_rate")
      .eq("id", data.petId)
      .eq("user_id", userId)
      .maybeSingle();
    if (!pet) return { ok: false, reason: "bad_input" };

    const sickNow = pet.sick === true;
    const poisonNow = pet.poisoned === true;
    if (data.kind === "med" && !sickNow && !poisonNow) return { ok: false, reason: "not_sick" };

    let food = Math.max(0, Math.min(100, Number(pet.food ?? 100)));
    let water = Math.max(0, Math.min(100, Number(pet.water ?? 100)));
    let sick = sickNow;
    let poisoned = poisonNow;
    if (data.kind === "food") food = Math.min(100, food + FEED_FOOD);
    else if (data.kind === "milk") water = Math.min(100, water + FEED_WATER);
    else {
      sick = false;
      poisoned = false;
    }

    const left = have - 1;
    const credits = Number(profile?.credits ?? 0);
    await supabase.from("profiles").update({ [col]: left } as never).eq("id", userId);
    const { error } = await supabase
      .from("user_pets")
      .update({ food, water, sick, poisoned, stress_at: new Date().toISOString() } as never)
      .eq("id", pet.id);
    if (error) return { ok: false, reason: "failed" };
    return { ok: true, kind: data.kind, food, water, sick, poisoned, left, credits };
  });

/* ── claim credits a pet has accumulated over time ────────────────────── */

export type ClaimResult =
  | { ok: false; reason: "bad_input" | "failed" }
  | { ok: true; claimed: number; credits: number; pending: number };

export const claimPetCredits = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ petId: z.string().uuid() }).parse(d))
  .handler(async ({ context, data }): Promise<ClaimResult> => {
    const { supabase, userId } = context;
    const { data: pet } = await supabase
      .from("user_pets")
      .select("id, food, water, sick, poisoned, credit_rate, pending_credits, stress_at")
      .eq("id", data.petId)
      .eq("user_id", userId)
      .maybeSingle();
    if (!pet) return { ok: false, reason: "bad_input" };

    const now = Date.now();
    const at = pet.stress_at ? new Date(pet.stress_at).getTime() : now;
    const elapsed = Math.max(0, (now - at) / 1000);
    const mult = creditRateMultiplier({
      food: Number(pet.food ?? 100),
      water: Number(pet.water ?? 100),
      sick: pet.sick === true,
      poisoned: pet.poisoned === true,
    });
    const gained = accrueCredits(Number(pet.credit_rate ?? 0), elapsed, mult);
    const claimed = Math.round((Number(pet.pending_credits ?? 0) + gained) * 100) / 100;

    const { data: profile } = await supabase.from("profiles").select("credits").eq("id", userId).maybeSingle();
    const credits = Math.round((Number(profile?.credits ?? 0) + claimed) * 100) / 100;
    await supabase.from("profiles").update({ credits } as never).eq("id", userId);
    const { error } = await supabase
      .from("user_pets")
      .update({ pending_credits: 0, stress_at: new Date(now).toISOString() } as never)
      .eq("id", pet.id);
    if (error) return { ok: false, reason: "failed" };
    return { ok: true, claimed, credits, pending: 0 };
  });

/* ── poison a pet in someone else's farm ──────────────────────────────── */

export type PoisonResult =
  | { ok: false; reason: "no_item" | "bad_input" | "own_farm" | "already" | "failed" }
  | { ok: true; left: number };

export const poisonFarmPet = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ rowId: z.string().uuid() }).parse(d))
  .handler(async ({ context, data }): Promise<PoisonResult> => {
    const { supabase, userId } = context;
    const { data: profile } = await supabase
      .from("profiles")
      .select("username, poison_items")
      .eq("id", userId)
      .maybeSingle();
    const have = Number((profile as Record<string, number | null> | null)?.["poison_items"] ?? 0);
    if (have <= 0) return { ok: false, reason: "no_item" };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row } = await supabaseAdmin
      .from("farm_pets")
      .select("id, user_id, pet_id, poisoned")
      .eq("id", data.rowId)
      .maybeSingle();
    if (!row) return { ok: false, reason: "bad_input" };
    if (row.user_id === userId) return { ok: false, reason: "own_farm" };
    if ((row as { poisoned?: boolean | null }).poisoned === true) return { ok: false, reason: "already" };

    const left = have - 1;
    await supabase.from("profiles").update({ poison_items: left } as never).eq("id", userId);

    const { error } = await supabaseAdmin.from("farm_pets").update({ poisoned: true } as never).eq("id", row.id);
    if (error) return { ok: false, reason: "failed" };
    await supabaseAdmin.from("user_pets").update({ poisoned: true } as never).eq("id", row.pet_id);

    const { data: target } = await supabaseAdmin
      .from("user_pets")
      .select("animal")
      .eq("id", row.pet_id)
      .maybeSingle();
    await logFarmEvent(supabaseAdmin, {
      farmUserId: row.user_id,
      actorId: userId,
      actorName: (profile as { username?: string } | null)?.username ?? "ผู้เล่น",
      petId: row.pet_id,
      animal: target?.animal ?? "",
      kind: "poison",
    });

    return { ok: true, left };
  });



/* ── gift a pet to another player (cost: credit_rate x100 gems) ────────── */

/** Flat gift fee: 100 gems per pet, regardless of its credit rate. */
export const giftCost = (_rate?: number) => 100;

export type GiftResult =
  | { ok: false; reason: "bad_input" | "no_user" | "self" | "no_gems" | "failed"; gems?: number; cost?: number }
  | { ok: true; gems: number; cost: number; to: string; animal: string };

export const giftPet = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ petId: z.string().uuid(), username: z.string().trim().min(1).max(40) }).parse(d),
  )
  .handler(async ({ context, data }): Promise<GiftResult> => {
    const { supabase, userId } = context;

    const { data: pet } = await supabase
      .from("user_pets")
      .select("id, animal, credit_rate")
      .eq("user_id", userId)
      .eq("id", data.petId)
      .maybeSingle();
    if (!pet) return { ok: false, reason: "bad_input" };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: target } = await supabaseAdmin
      .from("profiles")
      .select("id, username")
      .ilike("username", data.username)
      .maybeSingle();

    if (!target) return { ok: false, reason: "no_user" };
    if (target.id === userId) return { ok: false, reason: "self" };

    const cost = giftCost(Number(pet.credit_rate));
    const { data: me } = await supabase.from("profiles").select("gems").eq("id", userId).maybeSingle();
    const gems = Number(me?.gems ?? 0);
    if (gems < cost) return { ok: false, reason: "no_gems", gems, cost };

    const left = gems - cost;
    const { error: payErr } = await supabase.from("profiles").update({ gems: left }).eq("id", userId);
    if (payErr) return { ok: false, reason: "failed" };



    await supabaseAdmin.from("farm_pets").delete().eq("pet_id", pet.id);
    const { error: moveErr } = await supabaseAdmin
      .from("user_pets")
      .update({ user_id: target.id })
      .eq("id", pet.id);
    if (moveErr) {
      await supabase.from("profiles").update({ gems }).eq("id", userId);
      return { ok: false, reason: "failed", gems };
    }
    const { data: prof } = await supabase.from("profiles").select("selected_pet_id").eq("id", userId).maybeSingle();
    if (prof?.selected_pet_id === pet.id) {
      await supabase.from("profiles").update({ selected_pet_id: null }).eq("id", userId);
    }

    return { ok: true, gems: left, cost, to: target.username, animal: pet.animal };
  });
