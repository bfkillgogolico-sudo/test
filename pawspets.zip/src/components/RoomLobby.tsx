import { CharacterSprite } from "@/components/CharacterSprite";
import { Spinner } from "@/components/Spinner";
import { useEffect, useRef, useState } from "react";
import type { RealtimeChannel } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { getCharacter, registerPets } from "@/lib/game/characters";
import type { PlayerMeta } from "@/lib/game/engine";
import type { Pet } from "@/lib/game/pets";

type Member = {
  id: string;
  name: string;
  charId: string;
  pet?: Pet;
  net?: number;
  gameMetas?: PlayerMeta[];
  simHost?: string;
};

type Props = {
  code: string;
  self: Member;
  isHost: boolean;
  onStart: (metas: PlayerMeta[], channel: RealtimeChannel, isHost: boolean) => void;
  onLeave: () => void;
};

/** unknown connection quality sorts last */
const NET_UNKNOWN = 99999;

/** ranks players by connection quality, used only to label the lobby */

export function pickSimHost(list: { id: string; net?: number }[]): string | null {
  if (list.length === 0) return null;
  const sorted = [...list].sort((a, b) => {
    const d = (a.net ?? NET_UNKNOWN) - (b.net ?? NET_UNKNOWN);
    return d !== 0 ? d : a.id.localeCompare(b.id);
  });
  return sorted[0]!.id;
}

export function netLabel(net?: number) {
  if (net === undefined) return { text: "วัดเน็ต...", cls: "text-muted-foreground" };
  if (net < 120) return { text: `${Math.round(net)}ms เน็ตดีมาก`, cls: "text-emerald-400" };
  if (net < 250) return { text: `${Math.round(net)}ms เน็ตดี`, cls: "text-emerald-300" };
  if (net < 450) return { text: `${Math.round(net)}ms พอใช้`, cls: "text-amber-300" };
  return { text: `${Math.round(net)}ms เน็ตช้า`, cls: "text-red-400" };
}

export function RoomLobby({ code, self, isHost, onStart, onLeave }: Props) {
  const [members, setMembers] = useState<Member[]>([self]);
  const [myNet, setMyNet] = useState<number | undefined>(undefined);
  const channelRef = useRef<RealtimeChannel | null>(null);
  const startedRef = useRef(false);
  const selfRef = useRef<Member>(self);
  const netRef = useRef<number[]>([]);

  const enterGame = (metas: PlayerMeta[], channel: RealtimeChannel, host: boolean) => {
    if (startedRef.current || metas.length === 0) return;
    startedRef.current = true;
    registerPets(metas.flatMap((m) => (m.pet ? [m.pet] : [])));
    onStart(metas, channel, host);
  };

  useEffect(() => {
    const channel = supabase.channel(`wolf-room-${code}`, {
      config: { presence: { key: self.id }, broadcast: { self: false } },
    });
    channelRef.current = channel;

    channel.on("presence", { event: "sync" }, () => {
      const st = channel.presenceState<Member>();
      const list: Member[] = [];
      Object.values(st).forEach((entries) => {
        const e = entries[0] as unknown as Member | undefined;
        if (e?.id) {
          if (e.pet) registerPets([e.pet]);
          list.push({
            id: e.id,
            name: e.name,
            charId: e.charId,
            ...(e.pet ? { pet: e.pet } : {}),
            ...(typeof e.net === "number" ? { net: e.net } : {}),
          });
          if (!isHost && Array.isArray(e.gameMetas)) {
            enterGame(e.gameMetas, channel, false);
          }
        }
      });
      list.sort((a, b) => a.id.localeCompare(b.id));
      setMembers(list.length ? list : [self]);
    });

    channel.on("broadcast", { event: "start" }, ({ payload }) => {
      const p = payload as { metas: PlayerMeta[] };
      if (Array.isArray(p.metas)) enterGame(p.metas, channel, isHost);
    });

    void channel.subscribe(async (status) => {
      if (status === "SUBSCRIBED") {
        await channel.track(selfRef.current);
      }
    });

    /* measure this client's round-trip time to the realtime server and share it
       through presence, so the best connection can run the simulation */
    const measure = async () => {
      if (startedRef.current) return;
      const t0 = performance.now();
      try {
        await channel.send({ type: "broadcast", event: "netping", payload: { t: t0 } });
      } catch {
        return;
      }
      const rtt = performance.now() - t0;
      const samples = netRef.current;
      samples.push(rtt);
      if (samples.length > 6) samples.shift();
      const sorted = [...samples].sort((a, b) => a - b);
      const median = sorted[Math.floor(sorted.length / 2)]!;
      const jitter = Math.max(...sorted) - Math.min(...sorted);
      const score = Math.round(median + jitter * 0.5);
      setMyNet(score);
      selfRef.current = { ...selfRef.current, net: score };
      if (!startedRef.current) await channel.track(selfRef.current);
    };
    void measure();
    const netTimer = setInterval(() => void measure(), 3000);

    let beat: ReturnType<typeof setInterval> | null = null;
    if (isHost) {
      const ping = () => {
        void supabase
          .from("rooms")
          .update({ updated_at: new Date().toISOString() })
          .eq("code", code);
      };
      ping();
      beat = setInterval(ping, 5000);
    }

    return () => {
      clearInterval(netTimer);
      if (beat) clearInterval(beat);
      if (!startedRef.current) supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [code]);

  async function startGame() {
    const channel = channelRef.current;
    if (!channel) return;
    // real players only: every device simulates the match itself, so there is no host
    const metas: PlayerMeta[] = members.slice(0, 6).map((m) => ({ ...m, isBot: false }));
    await channel.track({ ...selfRef.current, gameMetas: metas });
    await channel.send({ type: "broadcast", event: "start", payload: { metas } });
    void supabase.from("rooms").update({ status: "playing" }).eq("code", code);
    enterGame(metas, channel, true);
  }

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-2xl flex-col justify-center px-4 py-8">
      <div className="panel p-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-3xl">ห้องรอผู้เล่น</h1>
            <p className="text-sm text-muted-foreground">แชร์รหัสนี้ให้เพื่อนเข้าห้อง</p>
          </div>
          <div className="panel px-4 py-2 font-display text-3xl tracking-[0.35em] text-primary">
            {code}
          </div>
        </div>

        <ul className="mt-5 grid gap-2 sm:grid-cols-2">
          {Array.from({ length: 6 }).map((_, i) => {
            const m = members[i];
            const net = m ? netLabel(m.id === self.id ? (m.net ?? myNet) : m.net) : null;
            return (
              <li
                key={i}
                className={`flex items-center gap-3 rounded-lg px-4 py-3 ${m ? "bg-secondary" : "border border-dashed border-border"}`}
              >
                {m && net ? (
                  <>
                    <CharacterSprite character={getCharacter(m.charId)} className="h-8 w-8" />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="truncate font-display text-xl">{m.name}</span>
                        {m.id === self.id && <span className="text-xs text-primary">(คุณ)</span>}
                      </div>
                      <div className={`text-xs ${net.cls}`}>{net.text}</div>
                    </div>
                  </>
                ) : (
                  <span className="text-sm text-muted-foreground">ว่าง — รอเพื่อนเข้าห้อง</span>
                )}
              </li>
            );
          })}
        </ul>

        <p className="mt-3 text-xs text-muted-foreground">
          เล่นเท่าจำนวนคนจริงในห้อง ทุกเครื่องคำนวณเกมเอง เน็ตของใครช้าก็ไม่ทำให้คนอื่นแล็ก
        </p>

        <div className="mt-6 flex gap-2">
          {isHost ? (
            <button onClick={() => void startGame()} className="btn-base btn-primary flex-1">
              เริ่มเกม 🐺
            </button>
          ) : (
            <div className="flex flex-1 items-center justify-center gap-2 font-display text-xl text-muted-foreground">
              <Spinner /> รอเจ้าของห้องเริ่มเกม...
            </div>
          )}
          <button onClick={onLeave} className="btn-base btn-ghost">
            ออก
          </button>
        </div>
      </div>
    </div>
  );
}
