import { useEffect, useRef, useState, type ReactNode } from "react";
import { sfx } from "@/lib/game/sfx";

const TAPS_TO_HATCH = 5;

type Tier = { shell: string; ring: string; glow: string; label: string };

function tier(starsN: number): Tier {
  const n = Math.max(1, Math.min(6, starsN));
  const map: Record<number, Tier> = {
    1: { shell: "#cfd8dc, #90a4ae", ring: "#90a4ae", glow: "rgba(144,164,174,.5)", label: "ไข่ธรรมดา" },
    2: { shell: "#c8e6c9, #66bb6a", ring: "#66bb6a", glow: "rgba(102,187,106,.5)", label: "ไข่เขียว" },
    3: { shell: "#bbdefb, #42a5f5", ring: "#42a5f5", glow: "rgba(66,165,245,.55)", label: "ไข่ฟ้า" },
    4: { shell: "#e1bee7, #ab47bc", ring: "#ab47bc", glow: "rgba(171,71,188,.55)", label: "ไข่ม่วง" },
    5: { shell: "#ffe082, #ffb300", ring: "#ffb300", glow: "rgba(255,179,0,.6)", label: "ไข่ทอง" },
    6: { shell: "#fff8e1, #ff5252", ring: "#ff5252", glow: "rgba(255,82,82,.65)", label: "ไข่ตำนาน" },
  };
  return map[n]!;
}

export function EggReveal({
  stars: starsN,
  children,
  onClaim,
}: {
  stars: number;
  children: ReactNode;
  onClaim?: () => void;
}) {
  const t = tier(starsN);
  const [taps, setTaps] = useState(0);
  const [phase, setPhase] = useState<"egg" | "cracking" | "open">("egg");
  const [shakeKey, setShakeKey] = useState(0);
  const lockRef = useRef(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  function tap() {
    if (phase !== "egg" || lockRef.current) return;
    lockRef.current = true;
    setTimeout(() => (lockRef.current = false), 340); // กันกดรัว
    const next = taps + 1;
    setTaps(next);
    setShakeKey((k) => k + 1);
    if (next < TAPS_TO_HATCH) {
      sfx.bounce();
      return;
    }
    setPhase("cracking");
    sfx.skill();
    timerRef.current = setTimeout(() => {
      setPhase("open");
      sfx.win();
    }, 950);
  }

  if (phase === "open") {
    return (
      <div className="relative flex flex-col items-center">
        <div className="egg-hatch-rise">{children}</div>
        <div className="pointer-events-none relative -mt-3 h-8 w-28">
          <div
            className="absolute inset-0"
            style={{
              background: `radial-gradient(120% 200% at 50% 0%, ${t.shell.split(", ")[0]}, ${t.shell.split(", ")[1]})`,
              borderRadius: "0 0 999px 999px",
              clipPath: "polygon(0 22%, 12% 0, 26% 24%, 40% 2%, 55% 26%, 70% 4%, 86% 24%, 100% 6%, 100% 100%, 0 100%)",
              boxShadow: `0 8px 22px ${t.glow}`,
            }}
          />
        </div>
        {onClaim && (
          <button onClick={onClaim} className="btn-base btn-primary mt-4">
            รับ
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center">
      <button
        onClick={tap}
        aria-label="กดที่ไข่"
        className="relative h-40 w-32 select-none outline-none"
        style={{ filter: `drop-shadow(0 10px 26px ${t.glow})` }}
      >
        <div
          key={shakeKey}
          className={phase === "cracking" ? "egg-shake-fast h-full w-full" : "egg-shake h-full w-full"}
        >
          <div
            className="h-full w-full"
            style={{
              background: `radial-gradient(110% 120% at 35% 22%, ${t.shell})`,
              borderRadius: "50% 50% 50% 50% / 62% 62% 38% 38%",
              border: `3px solid ${t.ring}`,
            }}
          />
        </div>
        {phase === "cracking" && (
          <span
            className="egg-burst pointer-events-none absolute inset-0 rounded-full"
            style={{ background: `radial-gradient(circle, #fff, ${t.glow} 60%, transparent 70%)` }}
          />
        )}
      </button>
      <p className="mt-2 font-display text-lg" style={{ color: t.ring }}>
        {t.label}
      </p>
    </div>
  );
}
