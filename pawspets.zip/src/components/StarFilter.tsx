import type { Pet } from "@/lib/game/pets";
import { cn } from "@/lib/utils";

/**
 * ปุ่มกรองดาวสำหรับรายการสัตว์ของผู้เล่น — เลือกดาวเดียวเท่านั้น
 * (ลดจำนวนโมเดล 3D ที่ต้องวาดพร้อมกัน)
 * ไม่มีปุ่ม "ทั้งหมด" เพราะการแสดงทุกหมวดพร้อมกันทำให้เบราว์เซอร์
 * เปิดโมเดลได้ไม่ครบ — ต้องเลือกหมวดดาวทีละหมวดเสมอ
 */
export function StarFilter({
  pets,
  value,
  onChange,
}: {
  pets: Pet[];
  value: number;
  onChange: (v: number) => void;
}) {
  const tiers = [1, 2, 3, 4, 5, 6]
    .map((s) => ({ stars: s, count: pets.filter((p) => p.stars === s).length }))
    .filter((t) => t.count > 0);

  const btn = (active: boolean) =>
    cn(
      "rounded-lg border px-2.5 py-1.5 font-display text-sm leading-none transition-colors",
      active
        ? "border-yellow-300 bg-yellow-300/15 text-yellow-300"
        : "border-border bg-secondary text-muted-foreground hover:text-foreground",
    );

  return (
    <div className="flex flex-wrap gap-1.5">
      {tiers.map((t) => (
        <button key={t.stars} type="button" onClick={() => onChange(t.stars)} className={btn(value === t.stars)}>
          {t.stars}★
          <span className="ml-1 text-[10px] opacity-70">{t.count}</span>
        </button>
      ))}
    </div>
  );
}

/**
 * ดาวที่ใช้แสดงผลจริง — ถ้าค่าปัจจุบันไม่มีสัตว์เลย ให้กลับไปที่หมวด
 * ดาวต่ำสุดที่มีอยู่ เพื่อให้มีหมวดที่เลือกอยู่เสมอ (ไม่มีสถานะ "ทั้งหมด")
 */
export function effectiveStar(pets: Pet[], value: number | null): number {
  const tiers = [1, 2, 3, 4, 5, 6].filter((s) => pets.some((p) => p.stars === s));
  if (value !== null && tiers.includes(value)) return value;
  return tiers[0] ?? 1;
}
