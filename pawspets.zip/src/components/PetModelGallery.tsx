import { useState } from "react";
import { CharacterModel3D } from "./CharacterModel3D";
import { ANIMAL_STAR_GROUPS, stars } from "@/lib/game/pets";
import { cn } from "@/lib/utils";

/**
 * Shop previews grouped by fixed star tier. Only ONE tier is mounted at a
 * time (เลือกด้วยปุ่มดาว) so the browser never has to render more than a
 * handful of 3D models at once — เลขสัตว์ในหมวดอื่นจะถูกถอดออกจากจอจริง ๆ
 * ไม่ใช่แค่ซ่อน ทำให้ทุกตัวในหมวดที่เลือกแสดงโมเดลได้ครบ
 */
export function PetModelGallery() {
  const [active, setActive] = useState<number>(ANIMAL_STAR_GROUPS[0]?.stars ?? 1);
  const group = ANIMAL_STAR_GROUPS.find((g) => g.stars === active) ?? ANIMAL_STAR_GROUPS[0]!;

  return (
    <div className="mt-3 space-y-3">
      <div className="flex flex-wrap gap-1.5">
        {ANIMAL_STAR_GROUPS.map((g) => (
          <button
            key={g.stars}
            type="button"
            onClick={() => setActive(g.stars)}
            className={cn(
              "rounded-lg border px-2.5 py-1.5 font-display text-sm leading-none transition-colors",
              g.stars === active
                ? "border-yellow-300 bg-yellow-300/15 text-yellow-300"
                : "border-border bg-secondary text-muted-foreground hover:text-foreground",
            )}
          >
            {g.stars}★
            <span className="ml-1 text-[10px] opacity-70">{g.animals.length}</span>
          </button>
        ))}
      </div>

      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h3 className="font-display text-xl leading-none text-yellow-300">{stars(group.stars)}</h3>
        <span className="text-xs text-muted-foreground">
          {group.stars} ดาว · {group.animals.length} ชนิด
        </span>
      </div>
      <div className="mt-2 grid grid-cols-3 gap-3 sm:grid-cols-4">
        {group.animals.map((animal) => (
          <div key={animal.id} className="rounded-lg bg-secondary p-2 text-center">
            <CharacterModel3D model={animal.model} className="mx-auto h-24 w-24" emoji={animal.emoji} />
            <div className="font-display text-base leading-none">
              {animal.emoji} {animal.name}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
