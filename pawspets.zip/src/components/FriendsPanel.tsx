import { useState } from "react";
import { Spinner } from "@/components/Spinner";
import type { FriendsState } from "@/hooks/useFriends";

export function FriendsPanel({ social }: { social: FriendsState }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function add() {
    setBusy(true);
    try {
      setMsg(await social.addFriend(name));
      setName("");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <button
        onClick={() => setOpen((v) => !v)}
        className="panel fixed top-1/2 right-0 z-30 -translate-y-1/2 px-2 py-4 font-display text-lg"
        style={{ right: open ? "18rem" : 0 }}
      >
        {open ? "›" : "👥"}
        {!open && social.incoming.length > 0 && (
          <span className="ml-1 rounded-full bg-primary px-1.5 text-sm text-primary-foreground">
            {social.incoming.length}
          </span>
        )}
      </button>

      <aside
        className="fixed top-0 right-0 z-20 h-full w-72 overflow-y-auto border-l border-border bg-card/95 p-3 transition-transform"
        style={{ transform: open ? "none" : "translateX(100%)" }}
      >
        <h2 className="font-display text-xl">👥 เพื่อน ({social.friends.length})</h2>

        <div className="mt-3 flex gap-2">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="ชื่อผู้เล่น"
            className="min-w-0 flex-1 rounded-lg bg-input px-3 py-2 text-sm outline-none ring-ring focus:ring-2"
          />
          <button
            onClick={() => void add()}
            disabled={busy}
            aria-label="เพิ่มเพื่อน"
            className="btn-base btn-primary px-3 py-2 text-base disabled:opacity-60"
          >
            {busy ? <Spinner /> : "+"}
          </button>
        </div>
        {msg && <p className="mt-2 text-xs text-primary">{msg}</p>}

        {social.incoming.length > 0 && (
          <div className="mt-4">
            <p className="font-display text-lg">📨 คำขอเป็นเพื่อน</p>
            <ul className="mt-2 space-y-2">
              {social.incoming.map((f) => (
                <li key={f.id} className="rounded-lg bg-secondary px-3 py-2">
                  <p className="font-display text-lg">{f.username}</p>
                  <div className="mt-1 flex gap-2">
                    <button
                      onClick={() => void social.accept(f.id)}
                      className="btn-base btn-primary px-3 py-1 text-sm"
                    >
                      ยืนยัน
                    </button>
                    <button
                      onClick={() => void social.reject(f.id)}
                      className="btn-base btn-ghost px-3 py-1 text-sm"
                    >
                      ไม่รับ
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="mt-4">
          <p className="font-display text-lg">รายชื่อเพื่อน</p>
          {social.loading && social.friends.length === 0 ? (
            <p className="mt-2 inline-flex items-center gap-2 text-sm text-muted-foreground">
              <Spinner /> กำลังโหลด...
            </p>
          ) : social.friends.length === 0 ? (
            <p className="mt-2 text-sm text-muted-foreground">ยังไม่มีเพื่อน — พิมพ์ชื่อแล้วกด + เพื่อแอด</p>
          ) : (
            <ul className="mt-2 space-y-2">
              {social.friends.map((f) => (
                <li key={f.id} className="rounded-lg bg-secondary px-3 py-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="min-w-0">
                      <span className="block truncate font-display text-lg">{f.username}</span>
                      <span className="text-xs text-emerald-300">💠 {f.credits.toFixed(1)}</span>
                    </span>
                    <button
                      onClick={() => void social.remove(f.id)}
                      aria-label={`ลบเพื่อน ${f.username}`}
                      className="btn-base btn-ghost px-2 py-0.5 text-base"
                    >
                      −
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {social.outgoing.length > 0 && (
          <div className="mt-4 text-xs text-muted-foreground">
            <p className="font-display text-base text-foreground">รอการยืนยัน</p>
            <ul className="mt-1 space-y-1">
              {social.outgoing.map((f) => (
                <li key={f.id} className="flex items-center justify-between">
                  <span>{f.username}</span>
                  <button onClick={() => void social.remove(f.id)} className="underline">
                    ยกเลิก
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </aside>
    </>
  );
}
