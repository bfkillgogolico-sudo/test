import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { CharacterModel3D } from "@/components/CharacterModel3D";
import { Spinner } from "@/components/Spinner";
import { StarFilter, effectiveStar } from "@/components/StarFilter";

import {
  UPGRADE_COSTS,
  upgradePet,
  type UpgradeKind,
  type UpgradeResult,
} from "@/lib/game.functions";
import { getAnimal, getColor, getPattern, getSkill, genderSymbol, stars, type Pet } from "@/lib/game/pets";

type Props = { pets: Pet[]; credits: number; onRefresh: () => void };

function Mini({ pet }: { pet: Pet }) {
  const a = getAnimal(pet.animal);
  const c = getColor(pet.color);
  const patC = getColor(pet.pattern_color);
  return (
    <div className="text-center">
      <CharacterModel3D
        model={a.model}
        tint={c.hex}
        pattern={pet.pattern}
        patternTint={patC.hex}
        className="mx-auto h-20 w-20"
        emoji={a.emoji}
      />
      <div className="font-display text-base leading-none">
        {a.name}{" "}
        <span className={pet.gender === "female" ? "text-pink-400" : "text-sky-400"}>{genderSymbol(pet.gender)}</span>
      </div>
      <div className="font-display text-sm text-yellow-300">{stars(pet.stars)}</div>
    </div>
  );
}

const ACTIONS: { kind: UpgradeKind; label: string; emoji: string }[] = [
  { kind: "skill", label: "สุ่มความสามารถใหม่", emoji: "✨" },
  { kind: "rate", label: "อัปเกรดการสร้างเครดิต", emoji: "💠" },
  { kind: "color", label: "สุ่มสีใหม่", emoji: "🎨" },
  { kind: "pattern", label: "สุ่มตำหนิใหม่", emoji: "🌀" },
];

export function UpgradePanel({ pets, credits, onRefresh }: Props) {
  const [slotId, setSlotId] = useState<string | null>(null);
  const [busy, setBusy] = useState<UpgradeKind | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [result, setResult] = useState<(UpgradeResult & { ok: true }) | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [starFilter, setStarFilter] = useState<number | null>(null);
  const run = useServerFn(upgradePet);

  const slot = pets.find((p) => p.id === slotId) ?? null;
  const available = pets.filter((p) => p.id !== slotId);
  const effStars = effectiveStar(available, starFilter);
  const list = available.filter((p) => p.stars === effStars);

  async function doUpgrade(kind: UpgradeKind) {
    if (!slot || busy) return;
    setBusy(kind);
    setMsg(null);
    setResult(null);
    try {
      const res = (await run({ data: { petId: slot.id, kind } })) as UpgradeResult;
      if (!res.ok) {
        setMsg(res.reason === "no_credits" ? `💠 เครดิตไม่พอ (ต้องมี ${UPGRADE_COSTS[kind]})` : "อัปเกรดไม่สำเร็จ ลองอีกครั้ง");
      } else {
        setResult(res);
        if (res.died) setSlotId(null);
        onRefresh();
      }
    } finally {
      setBusy(null);
    }
  }

  return (
    <section className="mt-5 space-y-4">
      <div className="panel p-5">
        <h2 className="text-2xl">⚒️ อัปเกรดสัตว์</h2>
        <p className="mt-1 text-sm text-muted-foreground">ลากสัตว์มาวางในช่อง แล้วเลือกการอัปเกรด</p>


        <div className="mt-4 flex justify-center">
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              const id = e.dataTransfer.getData("text/plain");
              if (pets.some((p) => p.id === id)) {
                setSlotId(id);
                setResult(null);
                setMsg(null);
              }
            }}
            onClick={() => {
              setSlotId(null);
              setResult(null);
            }}
            className={`flex h-40 w-36 items-center justify-center rounded-xl border-2 border-dashed bg-secondary p-2 ${
              dragOver ? "border-primary" : "border-muted"
            }`}
          >
            {slot ? (
              <div
                draggable
                onDragStart={(e) => {
                  e.dataTransfer.setData("text/plain", slot.id);
                  e.dataTransfer.effectAllowed = "move";
                }}
              >
                <Mini pet={slot} />
              </div>
            ) : (
              <span className="text-sm text-muted-foreground">ลากมาวางที่นี่</span>
            )}
          </div>
        </div>

        {slot && (
          <div className="mt-3 text-center text-sm">
            <span className="text-primary">{getSkill(slot.skill).name}</span>
            <span className="text-muted-foreground"> · สี {getColor(slot.color).name} · {getPattern(slot.pattern).name}</span>
            <span className="text-emerald-300"> · 💠 {slot.credit_rate}/วิ</span>
          </div>
        )}

        <div className="mt-4 grid gap-2 sm:grid-cols-2">
          {ACTIONS.map((a) => (
            <button
              key={a.kind}
              onClick={() => void doUpgrade(a.kind)}
              disabled={!slot || busy !== null || credits < UPGRADE_COSTS[a.kind]}
              className="btn-base btn-primary disabled:opacity-50"
            >
              {busy === a.kind ? (
                <span className="inline-flex items-center gap-2">
                  <Spinner /> กำลังอัปเกรด...
                </span>
              ) : (
                `${a.emoji} ${a.label} — 💠 ${UPGRADE_COSTS[a.kind]}`
              )}
            </button>
          ))}
        </div>
        {msg && <p className="mt-3 text-center font-display text-xl text-primary">{msg}</p>}
      </div>

      {result && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
          <div className="panel w-full max-w-sm p-5 text-center">
            {result.died ? (
              <>
                <div className="text-5xl">💀</div>
                <h3 className="mt-2 text-2xl text-red-400">สัตว์ทนการทรมานจากการอับเกรดไม่ไหวตาย</h3>
                <div className="mt-3 opacity-60 grayscale">
                  <Mini pet={result.before} />
                </div>
                <p className="mt-2 text-sm text-muted-foreground">
                  {getAnimal(result.before.animal).name} ของคุณจากไปแล้ว... เครดิตที่ใช้อัปเกรดไม่ได้คืน
                </p>
              </>
            ) : result.pet ? (
              <>
                <h3 className="text-2xl text-primary">อัปเกรดสำเร็จ!</h3>
                <div className="mt-3">
                  <Mini pet={result.pet} />
                </div>
                <div className="mt-3 space-y-1 text-sm">
                  {result.kind === "skill" && (
                    <p>
                      <span className="text-muted-foreground">{getSkill(result.before.skill).name}</span> →{" "}
                      <span className="text-primary">{getSkill(result.pet.skill).name}</span>
                    </p>
                  )}
                  {result.kind === "rate" && (
                    <p>
                      <span className="text-muted-foreground">💠 {result.before.credit_rate}/วิ</span> →{" "}
                      <span className="text-emerald-300">💠 {result.pet.credit_rate}/วิ</span>
                    </p>
                  )}
                  {result.kind === "color" && (
                    <p>
                      <span className="text-muted-foreground">{getColor(result.before.color).name}</span> →{" "}
                      <span className="text-primary">{getColor(result.pet.color).name}</span>
                    </p>
                  )}
                  {result.kind === "pattern" && (
                    <p>
                      <span className="text-muted-foreground">{getPattern(result.before.pattern).name}</span> →{" "}
                      <span className="text-primary">
                        {getPattern(result.pet.pattern).name} ({getColor(result.pet.pattern_color).name})
                      </span>
                    </p>
                  )}
                </div>
              </>
            ) : null}
            <button onClick={() => setResult(null)} className="btn-base btn-primary mt-4">
              ตกลง
            </button>
          </div>
        </div>
      )}

      <div
        className="panel p-5"
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          const id = e.dataTransfer.getData("text/plain");
          if (id && id === slotId) setSlotId(null);
        }}
      >
        <h3 className="text-xl">สัตว์ของคุณ ({list.length})</h3>
        <div className="mt-2">
          <StarFilter pets={available} value={effStars} onChange={setStarFilter} />
        </div>
        {list.length === 0 ? (
          <p className="mt-2 text-sm text-muted-foreground">ยังไม่มีสัตว์ให้อัปเกรด</p>
        ) : (
          <div className="mt-3 grid grid-cols-3 gap-3 sm:grid-cols-4">
            {list.map((p) => (
              <button
                key={p.id}
                draggable
                onDragStart={(e) => {
                  e.dataTransfer.setData("text/plain", p.id);
                  e.dataTransfer.effectAllowed = "move";
                }}
                onClick={() => {
                  setSlotId(p.id);
                  setResult(null);
                  setMsg(null);
                }}
                className="rounded-lg bg-secondary p-2"
              >
                <Mini pet={p} />
              </button>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
