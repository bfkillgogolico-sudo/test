import { Component, type ReactNode } from "react";
import { useGLTF } from "@react-three/drei";

/**
 * Keeps a failed model download (flaky network / dev-server reload) from
 * blanking the whole app. Clears the GLTF cache and retries a couple of times.
 */
export class ModelBoundary extends Component<
  { children: ReactNode; urls?: string[]; fallback?: ReactNode },
  { failed: boolean; tries: number }
> {
  override state = { failed: false, tries: 0 };
  private timer: ReturnType<typeof setTimeout> | undefined;

  static getDerivedStateFromError() {
    return { failed: true };
  }

  override componentDidCatch() {
    if (this.state.tries >= 3) return;
    for (const u of this.props.urls ?? []) {
      try {
        useGLTF.clear(u);
      } catch {
        /* ignore */
      }
    }
    this.timer = setTimeout(
      () => this.setState((s) => ({ failed: false, tries: s.tries + 1 })),
      600 * (this.state.tries + 1),
    );
  }

  override componentWillUnmount() {
    if (this.timer) clearTimeout(this.timer);
  }

  override render() {
    if (this.state.failed) return this.props.fallback ?? null;
    return this.props.children;
  }
}
