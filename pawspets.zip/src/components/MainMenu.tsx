import { useEffect, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { CharacterModel3D } from "@/components/CharacterModel3D";
import { PetModelGallery } from "@/components/PetModelGallery";
import { StarFilter, effectiveStar } from "@/components/StarFilter";
import { BreedPanel } from "@/components/BreedPanel";
import { UpgradePanel } from "@/components/UpgradePanel";
import { GiftPanel } from "@/components/GiftPanel";
import { Spinner } from "@/components/Spinner";
import { TopupPanel } from "@/components/TopupPanel";
import { EggReveal } from "@/components/EggReveal";
import { FriendsPanel } from "@/components/FriendsPanel";
import { Leaderboard } from "@/components/Leaderboard";
import { OnlinePanel } from "@/components/OnlinePanel";
import { HomeDashboard } from "@/components/HomeDashboard";
import { useFriends } from "@/hooks/useFriends";
import { formatCompact } from "@/lib/format";

import { supabase } from "@/integrations/supabase/client";
import { rollPet } from "@/lib/game.functions";
import { buyEgg, buyFarmExpansion, buyItem, CREDIT_PRICES, GEM_PRICES, SLOTS_PER_EXPANSION } from "@/lib/shop.functions";
import {
  ANIMALS,
  ANIMAL_STAR_GROUPS,
  SHOP_COLORS,
  SKILLS,
  getAnimal,
  getColor,
  getPattern,
  getSkill,
  genderSymbol,
  stars,
  type Pet,
} from "@/lib/game/pets";
import type { Profile } from "@/hooks/useAuth";

type Room = { id: string; code: string; host_name: string; status: string };

type Props = {
  profile: Profile;
  pets: Pet[];
  selectedPetId: string | null;
  onSelectPet: (id: string) => void;
  onCreateRoom: () => void | Promise<void>;
  onJoinRoom: (code: string) => void;
  onRefresh: () => void;
  onSignOut: () => void;
  initialTab?: "home" | "play" | "chars" | "shop" | "breed" | "gift";
};

function StarRow({ n }: { n: number }) {
  return <span className="font-display text-lg text-yellow-300">{stars(n)}</span>;
}

function PetCard({
  pet,
  selected,
  onClick,
  showPetColor = true,
}: {
  pet: Pet;
  selected: boolean;
  onClick: () => void;
  showPetColor?: boolean;
}) {
  const a = getAnimal(pet.animal);
  const c = getColor(pet.color);
  const pat = getPattern(pet.pattern);
  const patC = getColor(pet.pattern_color);
  const sk = getSkill(pet.skill);
  return (
    <button onClick={onClick} className={`panel p-4 text-left transition ${selected ? "ring-2 ring-primary" : ""}`}>
      <div className="flex items-center gap-3">
        <CharacterModel3D
          model={a.model}
          tint={showPetColor ? c.hex : null}
          pattern={showPetColor ? pet.pattern : null}
          patternTint={showPetColor ? patC.hex : null}
          className="h-28 w-28 shrink-0"
          emoji={a.emoji}
        />
        <div className="min-w-0">
          <div className="font-display text-2xl leading-none">
            {a.emoji} {a.name}{" "}
            <span className={pet.gender === "female" ? "text-pink-400" : "text-sky-400"}>
              {genderSymbol(pet.gender)}
            </span>
          </div>
          <StarRow n={pet.stars} />
          <div className="text-sm text-primary">{sk.name}</div>
          <p className="text-xs text-muted-foreground">{sk.desc}</p>
          <p className="mt-1 text-xs text-muted-foreground">
            สี {c.name} · {pat.name}
            {pat.id !== "plain" ? ` (${patC.name})` : ""}
          </p>
          <p className="text-xs text-emerald-300">💠 {pet.credit_rate} เครดิต/วิ</p>
        </div>
      </div>
      {selected && <p className="mt-2 font-display text-lg text-primary">✅ กำลังใช้ตัวนี้</p>}
    </button>
  );
}

export function MainMenu({
  profile,
  pets,
  selectedPetId,
  onSelectPet,
  onCreateRoom,
  onJoinRoom,
  onRefresh,
  onSignOut,
  initialTab = "play",
}: Props) {
  const [tab, setTab] = useState<"home" | "play" | "chars" | "shop" | "breed" | "gift">(initialTab);
  const [gameSel, setGameSel] = useState<"bounce" | "fight" | null>(null);
  const [breedTab, setBreedTab] = useState<"breed" | "upgrade">("breed");
  const [rooms, setRooms] = useState<Room[]>([]);
  const [code, setCode] = useState("");
  const [rolling, setRolling] = useState(false);
  const [creating, setCreating] = useState(false);
  const [rollMsg, setRollMsg] = useState<string | null>(null);
  const [rolled, setRolled] = useState<Pet | null>(null);
  const [showTips, setShowTips] = useState(false);
  const [pending, setPending] = useState<string | null>(null);
  const [topup, setTopup] = useState(false);
  const [lbOpen, setLbOpen] = useState(false);
  const [shopTab, setShopTab] = useState<"gacha" | "items">("gacha");
  const [buying, setBuying] = useState<string | null>(null);
  const [shopMsg, setShopMsg] = useState<string | null>(null);
  const [eggPet, setEggPet] = useState<Pet | null>(null);
  const [charStars, setCharStars] = useState<number | null>(null);
  const effCharStars = useMemo(() => effectiveStar(pets, charStars), [pets, charStars]);
  const roll = useServerFn(rollPet);
  const buy = useServerFn(buyItem);
  const hatch = useServerFn(buyEgg);
  const expand = useServerFn(buyFarmExpansion);
  const social = useFriends();

  const expansions = Number(profile.farm_expansions ?? 0);
  const farmSlots = 3 + expansions * SLOTS_PER_EXPANSION;

  async function doExpand() {
    setBuying("expand");
    setShopMsg(null);
    try {
      const res = await expand({});
      if (res.ok) {
        setShopMsg(`✅ ขยายฟาร์มแล้ว! พื้นที่ใหญ่ขึ้น รองรับสัตว์ ${3 + res.expansions * SLOTS_PER_EXPANSION} ตัว`);
        onRefresh();
      } else if (res.reason === "no_gems") setShopMsg(`💎 เพชรไม่พอ (ต้องมี ${GEM_PRICES.expand})`);
      else if (res.reason === "max") setShopMsg("ขยายฟาร์มถึงขนาดใหญ่สุดแล้ว");
      else setShopMsg("ซื้อไม่สำเร็จ ลองอีกครั้ง");
    } finally {
      setBuying(null);
    }
  }

  async function doBuy(kind: "food" | "milk" | "med" | "poison" | "catch" | "guard", label: string) {
    setBuying(kind);
    setShopMsg(null);
    try {
      const res = await buy({ data: { kind, qty: 1 } });
      if (res.ok) {
        setShopMsg(`✅ ซื้อ${label}แล้ว (มี ${res.count} ชิ้น)`);
        onRefresh();
      } else if (res.reason === "no_credits") setShopMsg(`💠 เครดิตไม่พอ (ต้องมี ${CREDIT_PRICES[kind]})`);
      else setShopMsg("ซื้อไม่สำเร็จ ลองอีกครั้ง");
    } finally {
      setBuying(null);
    }
  }

  async function doEgg(animal: string) {
    setBuying(`egg-${animal}`);
    setShopMsg(null);
    setEggPet(null);
    try {
      const res = await hatch({ data: { animal } });
      if (res.ok && res.pet) {
        setEggPet(res.pet as Pet);
        onRefresh();
      } else if (!res.ok && res.reason === "no_gems") setShopMsg("💎 เพชรไม่พอ (ต้องมี 500)");
      else if (!res.ok) setShopMsg("ซื้อไม่สำเร็จ ลองอีกครั้ง");
    } finally {
      setBuying(null);
    }
  }

  async function withPending(label: string, fn: () => void | Promise<void>) {
    setPending(label);
    const started = Date.now();
    try {
      await fn();
    } finally {
      const left = 420 - (Date.now() - started);
      if (left > 0) await new Promise((r) => setTimeout(r, left));
      setPending(null);
    }
  }


  const selected = useMemo(() => pets.find((p) => p.id === selectedPetId) ?? null, [pets, selectedPetId]);

  useEffect(() => {
    let stop = false;
    const load = async () => {
      const fresh = new Date(Date.now() - 25_000).toISOString();
      const { data } = await supabase
        .from("rooms")
        .select("id, code, host_name, status")
        .eq("status", "open")
        .gt("updated_at", fresh)
        .order("created_at", { ascending: false })
        .limit(12);
      if (!stop) setRooms((data ?? []) as Room[]);
    };
    void load();
    const t = setInterval(load, 4000);
    return () => {
      stop = true;
      clearInterval(t);
    };
  }, []);

  function requirePet(action: () => void) {
    if (!selected) {
      setTab(pets.length ? "chars" : "shop");
      setRollMsg(pets.length ? null : "ยังไม่มีสัตว์เลย — สุ่มจากร้านค้าก่อนนะ!");
      return;
    }
    action();
  }

  async function doRoll() {
    setRolling(true);
    setRollMsg(null);
    try {
      const res = await roll({ data: undefined });
      if (res.ok) {
        const pet = { ...res.pet, credit_rate: Number(res.pet.credit_rate) } as Pet;
        setRolled(pet);
        setRollMsg(null);
        onRefresh();
      } else if (res.reason === "no_coins") setRollMsg("🪙 coin ไม่พอ (ต้องมี 100)");
      else setRollMsg("สุ่มไม่สำเร็จ ลองอีกครั้ง");
    } finally {
      setRolling(false);
    }
  }

  if (tab === "home") {
    return (
      <>
        <HomeDashboard
          username={profile.username}
          credits={Number(profile.credits ?? 0)}
          coins={Number(profile.coins ?? 0)}
          gems={Number(profile.gems ?? 0)}
          pets={pets}
          selected={selected}
          capacity={farmSlots}
          onOpen={setTab}
          onTopup={() => setTopup(true)}
          onSignOut={() => void withPending("กำลังออกจากระบบ...", onSignOut)}
          onRefresh={onRefresh}
        />
        {topup && <TopupPanel gems={profile.gems ?? 0} onClose={() => setTopup(false)} onGems={onRefresh} />}
        {pending && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/70 backdrop-blur-sm">
            <div className="panel flex items-center gap-3 px-6 py-4 font-display text-xl"><Spinner className="h-6 w-6" /> {pending}</div>
          </div>
        )}
      </>
    );
  }

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-4xl flex-col px-4 py-6">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl leading-none sm:text-4xl">🐾 PawPets</h1>
          <p className="text-sm text-muted-foreground">
            สวัสดี {profile.username} ·{" "}
            {selected
              ? `กำลังใช้: ${getAnimal(selected.animal).emoji} ${getAnimal(selected.animal).name} ${stars(selected.stars)}`
              : "ยังไม่ได้เลือกสัตว์"}
          </p>
        </div>
        <div className="text-right">
          <div className="flex items-center justify-end gap-2">
            <div className="panel px-3 py-2 font-display text-xl text-cyan-300">💎 {formatCompact(Number(profile.gems ?? 0))}</div>
            <button
              onClick={() => setTopup(true)}
              aria-label="เติมเพชร"
              className="flex h-11 w-11 items-center justify-center rounded-xl border-2 border-cyan-200/70 bg-cyan-500 font-display text-3xl font-bold leading-none text-white shadow-lg shadow-cyan-500/40 transition hover:scale-105"
            >
              +
            </button>
          </div>
          <div className="panel mt-1 px-3 py-2 font-display text-xl">🪙 {formatCompact(Number(profile.coins ?? 0))}</div>
          <div className="panel mt-1 px-3 py-1 font-display text-base text-emerald-300">
            💠 {formatCompact(Number(profile.credits ?? 0))}
          </div>
          <button
            onClick={() => void withPending("กำลังออกจากระบบ...", onSignOut)}
            className="mt-1 text-xs text-muted-foreground underline"
          >
            ออกจากระบบ
          </button>
        </div>
      </header>

      <button onClick={() => setTab("home")} className="btn-base btn-ghost mt-4 self-start px-3 py-1.5 text-base">← หน้าหลัก</button>

      <nav className="mt-5 grid grid-cols-3 gap-2 rounded-xl bg-secondary p-1 sm:grid-cols-6">
        {(
          [
            ["play", "เล่นเกม"],
            ["chars", `ตัวละคร (${pets.length})`],
            ["shop", "ร้านค้า"],
            ["breed", "💞 ผสมพันธุ์/อัปเกรด"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            onClick={() => void withPending("กำลังเปิด...", () => setTab(id))}
            className={`rounded-lg py-2 font-display text-lg ${
              tab === id ? "bg-primary text-primary-foreground" : "text-muted-foreground"
            }`}
          >
            {label}
          </button>
        ))}
        <button
          onClick={() => void withPending("กำลังเปิด...", () => setTab("gift"))}
          className={`rounded-lg py-2 font-display text-lg ${
            tab === "gift" ? "bg-primary text-primary-foreground" : "text-muted-foreground"
          }`}
        >
          🎁 ส่งสัตว์
        </button>
      </nav>



      {tab === "play" && (
        <section className="mt-5 space-y-4">
          {!selected && (
            <div className="panel border border-primary/40 p-4 text-sm">
              ⚠️ ต้องเลือกสัตว์ที่จะใช้ก่อนเริ่มเล่น{" "}
              {pets.length ? "(ไปที่แท็บ ตัวละคร)" : "(ยังไม่มีสัตว์ — ไปสุ่มที่ร้านค้า)"}
            </div>
          )}
          {gameSel === null && (
            <div className="grid gap-3 sm:grid-cols-2">
              <button
                onClick={() => setGameSel("bounce")}
                className="panel flex flex-col items-start gap-1 p-6 text-left transition hover:border-primary/60"
              >
                <span className="font-display text-3xl text-primary">🏀 เกมเด้งบอล</span>
                <span className="text-sm text-muted-foreground">
                  ห้องรองรับ 6 คน เล่นเท่าจำนวนคนจริงที่อยู่ในห้อง
                </span>
              </button>
              <button
                onClick={() => setGameSel("fight")}
                className="panel flex flex-col items-start gap-1 p-6 text-left transition hover:border-primary/60"
              >
                <span className="font-display text-3xl text-primary">⚔️ เกมต่อสู้</span>
                <span className="text-sm text-muted-foreground">โหมดต่อสู้แนวเทรินเบด — กำลังจะมาเร็วๆ นี้</span>
              </button>
            </div>
          )}

          {gameSel === "fight" && (
            <section className="space-y-4">
              <div className="flex items-center gap-3">
                <button onClick={() => setGameSel(null)} className="btn-base btn-ghost px-3 py-1.5 text-base">
                  ← กลับ
                </button>
                <h2 className="font-display text-3xl text-primary">⚔️ เกมต่อสู้</h2>
              </div>
              <div className="panel p-8 text-center text-muted-foreground">
                โหมดนี้กำลังพัฒนา — รอติดตามเร็วๆ นี้!
              </div>
            </section>
          )}

          {gameSel === "bounce" && (
          <section className="space-y-4">
            <div className="flex items-center gap-3">
              <button onClick={() => setGameSel(null)} className="btn-base btn-ghost px-3 py-1.5 text-base">
                ← กลับ
              </button>
              <div>
                <h2 className="font-display text-3xl text-primary">🏀 เกมเด้งบอล</h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  ห้องรองรับ 6 คน เล่นเท่าจำนวนคนจริงที่อยู่ในห้อง
                </p>
              </div>
            </div>

            <div className="panel p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h3 className="text-xl">สร้างห้องใหม่</h3>
                <button
                  onClick={() =>
                    requirePet(async () => {
                      setCreating(true);
                      try {
                        await onCreateRoom();
                      } finally {
                        setCreating(false);
                      }
                    })
                  }
                  disabled={creating}
                  className="btn-base btn-primary disabled:opacity-60"
                >
                  {creating ? (
                    <span className="inline-flex items-center gap-2">
                      <Spinner /> กำลังสร้างห้อง...
                    </span>
                  ) : "➕ สร้างห้อง"}
                </button>
              </div>
            </div>

            <div className="panel p-5">
              <h3 className="text-xl">เข้าห้องด้วยรหัส</h3>
              <div className="mt-3 flex gap-2">
                <input
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  placeholder="เช่น K7QX"
                  maxLength={6}
                  className="flex-1 rounded-lg bg-input px-4 py-3 font-display text-xl tracking-[0.3em] outline-none ring-ring focus:ring-2"
                />
                <button
                  onClick={() =>
                    code.trim() &&
                    requirePet(() => void withPending("กำลังเข้าห้อง...", () => onJoinRoom(code.trim())))
                  }
                  className="btn-base btn-primary"
                >
                  เข้าห้อง
                </button>

              </div>
            </div>

            <div className="panel p-5">
              <h3 className="text-xl">ห้องที่เปิดอยู่</h3>
              {rooms.length === 0 ? (
                <p className="mt-2 text-sm text-muted-foreground">ยังไม่มีห้องเปิด — สร้างห้องแรกเลย!</p>
              ) : (
                <ul className="mt-3 space-y-2">
                  {rooms.map((r) => (
                    <li key={r.id} className="flex items-center justify-between rounded-lg bg-secondary px-4 py-3">
                      <span>
                        <span className="font-display text-xl tracking-widest">{r.code}</span>
                        <span className="ml-3 text-sm text-muted-foreground">โดย {r.host_name}</span>
                      </span>
                      <button
                        onClick={() =>
                          requirePet(() => void withPending("กำลังเข้าห้อง...", () => onJoinRoom(r.code)))
                        }
                        className="btn-base btn-primary px-4 py-1.5 text-base"
                      >
                        เข้าร่วม
                      </button>

                    </li>
                  ))}
                </ul>
              )}
            </div>
          </section>
          )}
        </section>
      )}

      {tab === "chars" && (
        <section className="mt-5">
          {pets.length === 0 ? (
            <div className="panel p-6 text-center">
              <div className="text-5xl">🎁</div>
              <p className="mt-2 text-sm text-muted-foreground">คุณยังไม่มีสัตว์เลย — สุ่มจากร้านค้าก่อน</p>
              <button
                onClick={() => void withPending("กำลังเปิดร้านค้า...", () => setTab("shop"))}
                className="btn-base btn-primary mt-4"
              >
                ไปที่ร้านค้า
              </button>

            </div>
          ) : (
            <>
              <p className="mb-3 text-sm text-muted-foreground">
                แสดงเฉพาะสัตว์ที่คุณสุ่มได้ · กดเพื่อเลือกตัวที่จะใช้ในสนาม
              </p>
              <div className="mb-3">
                <StarFilter pets={pets} value={effCharStars} onChange={setCharStars} />
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                {pets.filter((p) => p.stars === effCharStars).map((p) => (
                  <PetCard
                    key={p.id}
                    pet={p}
                    selected={p.id === selectedPetId}
                    onClick={() => void withPending("กำลังเลือกสัตว์...", () => onSelectPet(p.id))}
                  />
                ))}

              </div>
            </>
          )}
        </section>
      )}

      {tab === "shop" && (
        <section className="mt-5 space-y-4">
          <div className="grid grid-cols-2 gap-2 rounded-xl bg-secondary p-1">
            {(
              [
                ["gacha", "🎁 สุ่มสัตว์"],
                ["items", "🛍️ ไอเทม"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                onClick={() => void withPending("กำลังเปิด...", () => setShopTab(id))}
                className={`rounded-lg py-2 font-display text-lg ${
                  shopTab === id ? "bg-primary text-primary-foreground" : "text-muted-foreground"
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {shopTab === "gacha" && (
            <>
              <div className="panel p-6 text-center">
                <div className="text-5xl">🎁</div>
                <h2 className="mt-2 text-3xl">สุ่มสัตว์</h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  ครั้งละ 100 coin · สุ่ม ตัว / สี / ตำหนิ / สกิล / อัตราสร้างเครดิต · ดาวตายตัวตามชนิดสัตว์
                </p>
                <button onClick={doRoll} disabled={rolling} className="btn-base btn-primary mt-4 disabled:opacity-60">
                  {rolling ? (
                    <span className="inline-flex items-center gap-2">
                      <Spinner /> กำลังสุ่ม...
                    </span>
                  ) : "สุ่มเลย 100 🪙"}
                </button>
                {rollMsg && <p className="mt-3 font-display text-xl text-primary">{rollMsg}</p>}
                {rolled && (
                  <div className="mx-auto mt-4 max-w-md">
                    <EggReveal key={rolled.id} stars={rolled.stars} onClaim={() => setRolled(null)}>
                      <div>
                        <div className="mt-2">
                          <PetCard
                            pet={rolled}
                            selected={rolled.id === selectedPetId}
                            onClick={() => onSelectPet(rolled.id)}
                          />
                        </div>
                        <p className="mt-1 text-xs text-muted-foreground">กดที่การ์ดเพื่อใช้ตัวนี้เลย</p>
                      </div>
                    </EggReveal>
                  </div>
                )}
              </div>

              <div className="panel p-5">
                <h2 className="text-2xl">สัตว์ทั้งหมดที่สุ่มได้ ({ANIMALS.length})</h2>
                <PetModelGallery />
                <p className="mt-3 text-xs text-muted-foreground">
                  สีที่สุ่มได้: {SHOP_COLORS.map((c) => c.name).join(" · ")}
                </p>
              </div>
            </>
          )}

          {shopTab === "items" && (
            <>
              <div className="panel p-5">
                <h2 className="text-2xl">ไอเทม (จ่ายด้วย 💠 เครดิต)</h2>
                {shopMsg && <p className="mt-2 font-display text-lg text-primary">{shopMsg}</p>}
                <div className="mt-3 grid gap-2 sm:grid-cols-2">
                  {(
                    [
                      ["food", "🍖", "อาหาร", `เติมหลอดอาหาร · มี ${profile.food_items ?? 0} ชิ้น`, CREDIT_PRICES.food],
                      ["milk", "🥛", "นม", `เติมหลอดน้ำ · มี ${profile.milk_items ?? 0} ขวด`, CREDIT_PRICES.milk],
                      [
                        "med",
                        "💊",
                        "ยารักษาสัตว์ป่วย",
                        `ลากใส่สัตว์ที่ป่วย (ของเราหรือของเพื่อน) เพื่อรักษา · มี ${profile.med_items ?? 0} ชิ้น`,
                        CREDIT_PRICES.med,
                      ],
                      [
                        "poison",
                        "\u{1F92E}",
                        "ยาพิษ",
                        `ลากใส่สัตว์ในฟาร์มเพื่อนเพื่อวางยา · สัตว์ที่ติดพิษจะกระหายน้ำเร็วมากจนหลอดน้ำเหลือ 5/100 · แก้ได้ด้วยยา · มี ${profile.poison_items ?? 0} ชิ้น`,
                        CREDIT_PRICES.poison,
                      ],
                      [
                        "catch",
                        "🪤",
                        "ไอเทมจับสัตว์",
                        `ลากใส่สัตว์ในฟาร์มเพื่อนเพื่อขโมย · โอกาส 70% และสูงขึ้นเมื่อสัตว์ตัวนั้นหิว · มี ${profile.catch_items ?? 0} ชิ้น`,
                        CREDIT_PRICES.catch,
                      ],
                      [
                        "guard",
                        "🛡️",
                        "ไอเทมคุ้มกันการขโมย",
                        `ลากใส่สัตว์ของเราเพื่อกันการขโมย 100% เป็นเวลา 24 ชั่วโมง · มี ${profile.guard_items ?? 0} ชิ้น`,
                        CREDIT_PRICES.guard,
                      ],
                    ] as const
                  ).map(([kind, icon, name, desc, price]) => (
                    <div key={kind} className="flex items-start gap-3 rounded-lg bg-secondary p-3">
                      <span className="text-4xl">{icon}</span>
                      <div className="min-w-0 flex-1">
                        <div className="font-display text-xl leading-none">{name}</div>
                        <p className="mt-1 text-xs text-muted-foreground">{desc}</p>
                        <button
                          onClick={() => void doBuy(kind, name)}
                          disabled={buying !== null}
                          className="btn-base btn-primary mt-2 px-3 py-1.5 text-base disabled:opacity-60"
                        >
                          {buying === kind ? (
                            <span className="inline-flex items-center gap-2">
                              <Spinner /> กำลังซื้อ...
                            </span>
                          ) : (
                            `ซื้อ 💠 ${price}`
                          )}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="panel p-5">
                <h2 className="text-2xl">🌱 ขยายพื้นที่ฟาร์ม</h2>
                <div className="mt-3 flex items-start gap-3 rounded-lg bg-secondary p-3">
                  <span className="text-4xl">🚧</span>
                  <div className="min-w-0 flex-1">
                    <div className="font-display text-xl leading-none">ขยายฟาร์ม +{SLOTS_PER_EXPANSION} ตัว</div>
                    <p className="mt-1 text-xs text-muted-foreground">
                      พื้นที่ฟาร์มกว้างขึ้น และวางสัตว์ได้เพิ่มอีก {SLOTS_PER_EXPANSION} ตัว · ขยายแล้ว {expansions} ครั้ง ·
                      ตอนนี้รองรับ {farmSlots} ตัว
                    </p>
                    <button
                      onClick={() => void doExpand()}
                      disabled={buying !== null}
                      className="btn-base btn-primary mt-2 px-3 py-1.5 text-base disabled:opacity-60"
                    >
                      {buying === "expand" ? (
                        <span className="inline-flex items-center gap-2">
                          <Spinner /> กำลังซื้อ...
                        </span>
                      ) : (
                        `ซื้อ 💎 ${GEM_PRICES.expand}`
                      )}
                    </button>
                  </div>
                </div>
              </div>

              <div className="panel p-5">
                <h2 className="text-2xl">🥚 ไข่ตามชนิด (ฟองละ 💎 {GEM_PRICES.egg})</h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  เลือกชนิดไข่ได้เลย · ดาวตายตัวตามชนิดสัตว์ สีพื้นฐาน ไม่มีตำหนิ · สกิล / เครดิต / เพศ สุ่ม
                </p>
                {eggPet && (
                  <div className="mx-auto mt-4 max-w-md">
                    <EggReveal key={eggPet.id} stars={eggPet.stars} onClaim={() => setEggPet(null)}>
                      <div className="mt-2">
                        <PetCard
                          pet={eggPet}
                          selected={eggPet.id === selectedPetId}
                          onClick={() => onSelectPet(eggPet.id)}
                        />
                      </div>
                    </EggReveal>
                  </div>
                )}
                <div className="mt-4 space-y-4">
                  {ANIMAL_STAR_GROUPS.map((group) => (
                    <div key={group.stars}>
                      <div className="flex flex-wrap items-baseline justify-between gap-2">
                        <h3 className="font-display text-xl leading-none text-yellow-300">{stars(group.stars)}</h3>
                        <span className="text-xs text-muted-foreground">
                          {group.stars} ดาว · {group.animals.length} ชนิด
                        </span>
                      </div>
                      <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-3">
                        {group.animals.map((a) => (
                          <button
                            key={a.id}
                            onClick={() => void doEgg(a.id)}
                            disabled={buying !== null}
                            className="flex items-center gap-2 rounded-lg bg-secondary px-3 py-2 text-left disabled:opacity-60"
                          >
                            <span className="text-2xl">🥚</span>
                            <span className="min-w-0">
                              <span className="block font-display text-lg leading-none">
                                {a.emoji} ไข่{a.name}
                              </span>
                              <span className="text-xs text-cyan-300">
                                {buying === `egg-${a.id}` ? "กำลังเปิด..." : `💎 ${GEM_PRICES.egg}`}
                              </span>
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

              </div>
            </>
          )}
        </section>
      )}

      {tab === "breed" && (
        <>
          <nav className="mt-5 grid grid-cols-2 gap-2 rounded-xl bg-secondary p-1">
            {(
              [
                ["breed", "💞 ผสมพันธุ์"],
                ["upgrade", "⚒️ อัปเกรด"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                onClick={() => setBreedTab(id)}
                className={`rounded-lg py-2 font-display text-lg ${
                  breedTab === id ? "bg-primary text-primary-foreground" : "text-muted-foreground"
                }`}
              >
                {label}
              </button>
            ))}
          </nav>
          {breedTab === "breed" ? (
            <BreedPanel pets={pets} credits={Number(profile.credits ?? 0)} onRefresh={onRefresh} />
          ) : (
            <UpgradePanel pets={pets} credits={Number(profile.credits ?? 0)} onRefresh={onRefresh} />
          )}
        </>
      )}

      {tab === "gift" && (
        <section className="mt-5">
          <GiftPanel pets={pets} gems={Number(profile.gems ?? 0)} onRefresh={onRefresh} />
        </section>
      )}



      {/* skill tip button (bottom-left) — only on shop tab */}
      {tab === "shop" && (
        <div className="fixed bottom-4 left-4 z-40">
          {showTips && (
            <div className="panel mb-2 max-h-[60vh] w-[19rem] overflow-y-auto p-3 text-xs">
              <p className="font-display text-base">สกิลที่มีโอกาสสุ่มได้ ({SKILLS.length})</p>
              <ul className="mt-2 space-y-1">
                {SKILLS.map((s) => (
                  <li key={s.n}>
                    <span className="text-primary">{s.name}</span> — {s.desc}
                  </li>
                ))}
              </ul>
            </div>
          )}
          <button
            onMouseEnter={() => setShowTips(true)}
            onMouseLeave={() => setShowTips(false)}
            onClick={() => setShowTips((v) => !v)}
            aria-label="รายการสกิลที่สุ่มได้"
            className="h-10 w-10 rounded-full bg-secondary font-display text-xl text-primary shadow-lg"
          >
            ?
          </button>
        </div>
      )}

      <Leaderboard social={social} open={lbOpen} onOpenChange={setLbOpen} />
      <OnlinePanel
        social={social}
        leaderboardOpen={lbOpen}
      />
      <FriendsPanel social={social} />


      {topup && (
        <TopupPanel
          gems={profile.gems ?? 0}
          onClose={() => setTopup(false)}
          onGems={() => onRefresh()}
        />
      )}

      {pending && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/70 backdrop-blur-sm">
          <div className="panel flex items-center gap-3 px-6 py-4 font-display text-xl">
            <Spinner className="h-6 w-6" /> {pending}
          </div>
        </div>
      )}
    </div>

  );
}
