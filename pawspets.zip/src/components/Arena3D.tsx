import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame, type ThreeEvent } from "@react-three/fiber";
import { Environment, Html, Lightformer, useAnimations, useGLTF } from "@react-three/drei";
import * as THREE from "three";
import { clone as cloneSkeleton } from "three/examples/jsm/utils/SkeletonUtils.js";
import { ModelBoundary } from "./ModelBoundary";
import { applyPetAppearance } from "@/lib/game/petAppearance";

import { ARENA, PLAYER_R, WOLF_R, BALL_R, currentBounds, type GameState } from "@/lib/game/engine";

import { CHARACTERS, getCharacter } from "@/lib/game/characters";
import { QUALITY, type Quality } from "@/lib/game/graphics";

/** world units per arena pixel */
const U = 0.01;
const AW = ARENA.w * U; // 16
const AH = ARENA.h * U; // 9
const CX = AW / 2;
const CZ = AH / 2;

/** GLB forward axis correction (Kenney cube-pets face +Z) */


const WOLF_MODEL = "/models/wolf.glb";
const MODELS = [...new Set([...CHARACTERS.map((c) => c.model), WOLF_MODEL])];
MODELS.forEach((m) => useGLTF.preload(m));

type StateRef = { current: GameState | null };

type Props = {
  stateRef: StateRef;
  players: { id: string; charId: string; name: string }[];
  selfId: string;
  onAim: (angle: number) => void;
  onShoot: () => void;
  shootOnClick: boolean;
  quality?: Quality;
};

/* ------------------------------------------------------------------ */
/* animal model                                                        */
/* ------------------------------------------------------------------ */

function useAnimal(url: string, targetHeight: number) {
  const gltf = useGLTF(url);
  return useMemo(() => {
    // Measure the PRISTINE gltf.scene, not the clone: once any clone's mixer
    // ticks, three's skinned-bounds cache on the shared geometry is poisoned
    // and Box3 on later clones returns garbage (the wolf shrank to nothing).
    const box = new THREE.Box3().setFromObject(gltf.scene);
    const size = new THREE.Vector3();
    box.getSize(size);
    const scale = targetHeight / (size.y || 1);
    const scene = cloneSkeleton(gltf.scene) as THREE.Group;
    scene.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) {
        m.castShadow = true;
        m.receiveShadow = false;
      }
    });
    return { scene, scale, clips: gltf.animations };
  }, [gltf, targetHeight]);
}

type ActorProps = {
  url: string;
  height: number;
  tint?: string;
  pattern?: string | null;
  patternTint?: string | null;
};

/** Animated animal whose transform + clip are driven by the caller each frame. */
function Actor({
  url,
  height,
  tint,
  pattern,
  patternTint,
  tintAmount,
  children,
  drive,
}: ActorProps & {
  tintAmount?: number;
  children?: React.ReactNode;
  drive: (o: {
    group: THREE.Group;
    setClip: (name: string) => void;
    delta: number;
    time: number;
  }) => void;
}) {
  const { scene, scale, clips } = useAnimal(url, height);
  const group = useRef<THREE.Group>(null);
  const inner = useRef<THREE.Group>(null);
  const { actions } = useAnimations(clips, inner);
  const current = useRef<string>("");

  useEffect(() => {
    if (!tint && !pattern) return;
    scene.traverse((o) => {
      const m = o as THREE.Mesh;
      if (!m.isMesh) return;
      const amt = tintAmount ?? 0.8;
      if (amt >= 0.95 && tint) {
        // hard override: kill baked texture/vertex colors so the model
        // really takes the flat color (used for the black wolf)
        const src = m.material as THREE.MeshStandardMaterial;
        const mat = src.clone();
        mat.map = null;
        mat.vertexColors = false;
        mat.color.set(tint);
        mat.roughness = 0.85;
        mat.metalness = 0.05;
        mat.needsUpdate = true;
        m.material = mat;
      } else if (amt >= 0.5) {
        m.material = applyPetAppearance(m.material as THREE.Material, {
          ...(tint ? { tint } : {}),
          ...(pattern ? { pattern } : {}),
          ...(patternTint ? { patternTint } : {}),
        });
      } else if (tint) {
        const mat = (m.material as THREE.MeshStandardMaterial).clone();
        mat.color.lerp(new THREE.Color(tint), amt);
        m.material = mat;
      }
    });
  }, [pattern, patternTint, scene, tint, tintAmount]);


  const setClip = (name: string) => {
    if (current.current === name) return;
    const next =
      actions[name] ??
      actions["idle"] ??
      Object.entries(actions).find(([k, a]) => a && /idle/i.test(k))?.[1] ??
      Object.values(actions).find(Boolean);
    if (!next) return;
    const prev = current.current ? actions[current.current] : null;
    next.reset().fadeIn(0.14).play();
    prev?.fadeOut(0.14);
    current.current = name;
  };

  useFrame((st, delta) => {
    if (group.current) drive({ group: group.current, setClip, delta, time: st.clock.elapsedTime });
  });

  return (
    <group ref={group}>
      <group ref={inner} scale={scale}>
        <primitive object={scene} />
      </group>
      {children}
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* players                                                             */
/* ------------------------------------------------------------------ */

function PlayerActor({
  id,
  charId,
  name,
  stateRef,
  selfId,
}: {
  id: string;
  charId: string;
  name: string;
  stateRef: StateRef;
  selfId: string;
}) {
  const [label, setLabel] = useState({ show: true });
  const ring = useRef<THREE.Mesh>(null);
  const shield = useRef<THREE.Mesh>(null);
  const arrow = useRef<THREE.Mesh>(null);
  const yaw = useRef(Math.PI);
  const ch = getCharacter(charId);
  // small flat downward-pointing triangle marker
  const triGeo = useMemo(() => {
    const s = PLAYER_R * U * 0.55;
    const shape = new THREE.Shape();
    shape.moveTo(0, 0);
    shape.lineTo(-s, s * 1.4);
    shape.lineTo(s, s * 1.4);
    shape.closePath();
    return new THREE.ShapeGeometry(shape);
  }, []);

  return (
    <>
      <Actor
        url={ch.model}
        height={PLAYER_R * U * 2.4}
        tintAmount={0.8}
        {...(ch.tint ? { tint: ch.tint } : {})}
        {...(ch.pattern ? { pattern: ch.pattern } : {})}
        {...(ch.patternTint ? { patternTint: ch.patternTint } : {})}

        drive={({ group, setClip, delta, time }) => {
          const s = stateRef.current;
          const p = s?.players.find((q) => q.id === id);
          if (!s || !p || !p.alive) {
            group.visible = false;
            if (ring.current) ring.current.visible = false;
            if (shield.current) shield.current.visible = false;
            if (arrow.current) arrow.current.visible = false;
            setLabel((l) => (l.show ? { show: false } : l));
            return;
          }
          group.visible = true;
          const invis = p.vanishUntil > s.t;
          const speed = Math.hypot(p.vx, p.vy);
          group.position.set(p.x * U, 0, p.y * U);
          if (speed > 8) {
            const want = Math.atan2(p.vx, p.vy);
            let d = want - yaw.current;
            while (d > Math.PI) d -= Math.PI * 2;
            while (d < -Math.PI) d += Math.PI * 2;
            yaw.current += d * (1 - Math.exp(-14 * delta));
          }
          group.rotation.y = yaw.current;
          const sc = invis ? 0.55 : 1;
          group.scale.setScalar(sc);
          setClip(speed > 420 ? "run" : speed > 8 ? "walk" : "idle");

          const holding = s.ball.holder === p.id;
          if (ring.current) {
            ring.current.visible = holding || p.id === selfId;
            (ring.current.material as THREE.MeshBasicMaterial).color.set(holding ? "#ffcf5c" : "#7fe7ff");
            ring.current.position.set(p.x * U, 0.02, p.y * U);
          }
          if (shield.current) {
            shield.current.visible = p.shieldUntil > s.t;
            shield.current.position.set(p.x * U, PLAYER_R * U * 1.1, p.y * U);
          }
          if (arrow.current) {
            const mine = p.id === selfId && p.alive;
            arrow.current.visible = mine;
            if (mine) {
              arrow.current.position.set(p.x * U, PLAYER_R * U * 6.5 + Math.sin(time * 4) * 0.06, p.y * U);
            }
          }
          setLabel((l) => (l.show === !invis ? l : { show: !invis }));
        }}
      />
      <mesh ref={ring} rotation-x={-Math.PI / 2}>
        <ringGeometry args={[PLAYER_R * U * 1.1, PLAYER_R * U * 1.45, 28]} />
        <meshBasicMaterial color="#7fe7ff" transparent opacity={0.75} side={THREE.DoubleSide} />
      </mesh>
      <mesh ref={shield}>
        <sphereGeometry args={[PLAYER_R * U * 1.9, 14, 10]} />
        <meshBasicMaterial color="#8ce99a" wireframe transparent opacity={0.5} />
      </mesh>
      {/* small flat downward-pointing green triangle above the player YOU control */}
      <mesh ref={arrow} visible={false} geometry={triGeo}>
        <meshStandardMaterial color="#36e05f" emissive="#1aa83f" emissiveIntensity={1.6} toneMapped={false} side={THREE.DoubleSide} />
      </mesh>
      <NameTag stateRef={stateRef} id={id} text={name} mine={id === selfId} show={label.show} />
    </>
  );
}

function NameTag({
  stateRef,
  id,
  text,
  mine,
  show,
}: {
  stateRef: StateRef;
  id: string;
  text: string;
  mine: boolean;
  show: boolean;
}) {
  const g = useRef<THREE.Group>(null);
  useFrame(() => {
    const p = stateRef.current?.players.find((q) => q.id === id);
    if (!g.current) return;
    if (!p || !p.alive) {
      g.current.visible = false;
      return;
    }
    g.current.visible = show;
    g.current.position.set(p.x * U, PLAYER_R * U * 3.1, p.y * U);
  });
  return (
    <group ref={g}>
      <Html center distanceFactor={6} zIndexRange={[5, 0]}>
        <div
          className="pointer-events-none whitespace-nowrap font-display text-3xl font-bold"
          style={{ color: mine ? "#ffd8a8" : "#e6edf7", textShadow: "0 2px 8px rgba(0,0,0,0.95)" }}
        >
          {text}
        </div>
      </Html>
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* wolf, orb, corpses                                                  */
/* ------------------------------------------------------------------ */

const WOLF_H = WOLF_R * U * 2.8;

function Wolf({ stateRef }: { stateRef: StateRef }) {
  const yaw = useRef(Math.PI);
  const light = useRef<THREE.PointLight>(null);
  const eyeL = useRef<THREE.Mesh>(null);
  const eyeR = useRef<THREE.Mesh>(null);
  const aura = useRef<THREE.Mesh>(null);
  const embers = useRef<THREE.Group>(null);
  const bite = useRef(0);
  return (
    <>
      <Actor
        url={WOLF_MODEL}
        height={WOLF_H}
        tint="#0d0f12"
        tintAmount={0.95}
        drive={({ group, setClip, delta, time }) => {
          const s = stateRef.current;
          if (!s) return;
          const w = s.wolf;
          group.position.set(w.x * U, 0, w.y * U);
          const speed = Math.hypot(w.vx, w.vy);
          if (speed > 8) {
            const want = Math.atan2(w.vx, w.vy);
            let d = want - yaw.current;
            while (d > Math.PI) d -= Math.PI * 2;
            while (d < -Math.PI) d += Math.PI * 2;
            yaw.current += d * (1 - Math.exp(-12 * delta));
          }
          group.rotation.y = yaw.current;

          // how close is the wolf to its prey? drives the bite lunge
          const holder = s.players.find((p) => p.id === s.ball.holder && p.alive);
          const tx = holder ? holder.x : s.ball.x;
          const ty = holder ? holder.y : s.ball.y;
          const dist = Math.hypot(tx - w.x, ty - w.y);
          const lunging = dist < (WOLF_R + PLAYER_R) * 2.4;
          bite.current = lunging ? Math.min(1, bite.current + delta * 6) : Math.max(0, bite.current - delta * 4);

          setClip(
            lunging
              ? "AnimalArmature|Attack"
              : speed > 120
                ? "AnimalArmature|Gallop"
                : speed > 8
                  ? "AnimalArmature|Walk"
                  : "AnimalArmature|Idle",
          );
          // snarl: nose dips forward and the body pumps when about to bite
          group.rotation.x = -bite.current * 0.18 + Math.sin(time * 16) * 0.03 * bite.current;
          // gallop/walk clips animate the legs now — no manual bob needed
          group.position.y = 0;
          const pump = 1 + Math.sin(time * 18) * 0.04 * bite.current;
          group.scale.set(1.05 * pump, 1.05 * pump, 1.05 * pump);

          const glow = 2.6 + bite.current * 5 + Math.sin(time * 9) * 0.5;
          for (const e of [eyeL.current, eyeR.current]) {
            if (!e) continue;
            const mat = e.material as THREE.MeshStandardMaterial;
            mat.emissiveIntensity = glow;
            mat.emissive.set(w.slowUntil > s.t ? "#7cc4ff" : "#ff1f1f");
          }
          // pulsing red aura ring on the ground
          if (aura.current) {
            const pulse = 1 + Math.sin(time * 4) * 0.08 + bite.current * 0.25;
            aura.current.scale.set(pulse, pulse, 1);
            const m = aura.current.material as THREE.MeshBasicMaterial;
            m.opacity = (w.slowUntil > s.t ? 0.18 : 0.34) + bite.current * 0.2 + Math.sin(time * 4) * 0.06;
            m.color.set(w.slowUntil > s.t ? "#4aa8ff" : "#ff1f1f");
            aura.current.position.set(w.x * U, 0.02, w.y * U);
            aura.current.rotation.z = time * 0.6;
          }
          // orbiting embers
          if (embers.current) {
            embers.current.position.set(w.x * U, 0, w.y * U);
            embers.current.rotation.y = time * 2.2;
            embers.current.visible = w.slowUntil <= s.t;
            embers.current.children.forEach((c, i) => {
              c.position.y = WOLF_H * (0.25 + 0.45 * (0.5 + 0.5 * Math.sin(time * 3 + i * 2.1)));
            });
          }
          if (light.current) {
            light.current.position.set(w.x * U, 0.8, w.y * U);
            light.current.intensity = 3 + bite.current * 3;
            light.current.color.set(w.slowUntil > s.t ? "#74c0fc" : "#ff2b1f");
          }
        }}
      >
        {/* glowing red eyes */}
        {[-1, 1].map((sx) => (
          <mesh
            key={sx}
            ref={sx < 0 ? eyeL : eyeR}
            // head of this wolf model sits high at the front (+Z) of the body
            position={[sx * WOLF_H * 0.075, WOLF_H * 0.74, WOLF_H * 0.82]}
          >
            <sphereGeometry args={[WOLF_H * 0.045, 10, 8]} />
            <meshStandardMaterial color="#ff3b2f" emissive="#ff1f1f" emissiveIntensity={3} toneMapped={false} />
          </mesh>
        ))}
      </Actor>
      {/* red aura ring under the wolf */}
      <mesh ref={aura} rotation-x={-Math.PI / 2}>
        <ringGeometry args={[WOLF_H * 0.42, WOLF_H * 0.6, 40]} />
        <meshBasicMaterial color="#d40f0f" transparent opacity={0.42} depthWrite={false} />
      </mesh>
      {/* floating red embers around the wolf */}
      <group ref={embers}>
        {[0, 1, 2, 3, 4, 5].map((i) => {
          const a = (i / 6) * Math.PI * 2;
          return (
            <mesh key={i} position={[Math.cos(a) * WOLF_H * 0.55, WOLF_H * 0.4, Math.sin(a) * WOLF_H * 0.55]}>
              <sphereGeometry args={[WOLF_H * 0.035, 6, 5]} />
              <meshBasicMaterial color="#ff3b2f" transparent opacity={0.85} blending={THREE.AdditiveBlending} depthWrite={false} />
            </mesh>
          );
        })}
      </group>
      <pointLight ref={light} intensity={3} distance={4.5} color="#ff2b1f" />
    </>
  );
}

/** Claw slashes that burst where a player got mauled. */
function ClawFx({ stateRef }: { stateRef: StateRef }) {
  const [hits, setHits] = useState<{ key: string; x: number; y: number; a: number }[]>([]);
  const seen = useRef(0);
  useFrame(() => {
    const s = stateRef.current;
    if (!s) return;
    if (s.corpses.length > seen.current) {
      const fresh = s.corpses.slice(seen.current).map((c) => ({
        key: `${c.id}-${c.t}`,
        x: c.x,
        y: c.y,
        a: Math.random() * Math.PI,
      }));
      seen.current = s.corpses.length;
      setHits((h) => [...h, ...fresh].slice(-4));
    } else if (s.corpses.length < seen.current) {
      seen.current = s.corpses.length;
      setHits([]);
    }
  });
  return (
    <>
      {hits.map((h) => (
        <ClawSlash key={h.key} x={h.x} y={h.y} angle={h.a} onDone={() => setHits((l) => l.filter((q) => q.key !== h.key))} />
      ))}
    </>
  );
}

function ClawSlash({
  x,
  y,
  angle,
  onDone,
}: {
  x: number;
  y: number;
  angle: number;
  onDone: () => void;
}) {
  const g = useRef<THREE.Group>(null);
  const life = useRef(0);
  useFrame((_, delta) => {
    life.current += delta;
    const t = life.current / 0.55;
    if (!g.current) return;
    if (t >= 1) {
      onDone();
      return;
    }
    const s = 0.7 + t * 0.9;
    g.current.scale.set(s, s, s);
    g.current.position.y = 0.35 + t * 0.5;
    g.current.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) (m.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 1 - t) * 0.95;
    });
  });
  return (
    <group ref={g} position={[x * U, 0.35, y * U]} rotation={[-Math.PI / 2, 0, angle]}>
      {[-1, 0, 1].map((i) => (
        <mesh key={i} position={[i * 0.11, 0, i * 0.03]} rotation-z={0.22}>
          <planeGeometry args={[0.055, 0.85]} />
          <meshBasicMaterial color="#ff2f3d" transparent opacity={0.95} side={THREE.DoubleSide} toneMapped={false} />
        </mesh>
      ))}
      <mesh>
        <circleGeometry args={[0.42, 18]} />
        <meshBasicMaterial color="#ff6b4a" transparent opacity={0.3} side={THREE.DoubleSide} toneMapped={false} />
      </mesh>
    </group>
  );
}

function Orb({ stateRef }: { stateRef: StateRef }) {
  const g = useRef<THREE.Group>(null);
  const core = useRef<THREE.Mesh>(null);
  useFrame((st) => {
    const s = stateRef.current;
    if (!s || !g.current) return;
    const b = s.ball;
    const bob = b.holder ? 0.38 : 0.2 + Math.sin(st.clock.elapsedTime * 6) * 0.04;
    g.current.position.set(b.x * U, bob, b.y * U);
    g.current.rotation.y += 0.03;
    if (core.current) core.current.scale.setScalar(1 + Math.sin(st.clock.elapsedTime * 9) * 0.08);
  });
  return (
    <group ref={g}>
      <mesh ref={core}>
        <icosahedronGeometry args={[BALL_R * U, 1]} />
        <meshStandardMaterial color="#fff3c4" emissive="#ffb347" emissiveIntensity={2.2} roughness={0.3} />
      </mesh>
      <mesh scale={1.9}>
        <icosahedronGeometry args={[BALL_R * U, 1]} />
        <meshBasicMaterial color="#ffb347" transparent opacity={0.18} />
      </mesh>
      <pointLight intensity={2.6} distance={3.2} color="#ffc766" />
    </group>
  );
}

function Corpses({ stateRef }: { stateRef: StateRef }) {
  const [list, setList] = useState<{ id: string; x: number; y: number }[]>([]);
  useFrame(() => {
    const s = stateRef.current;
    if (!s) return;
    if (s.corpses.length !== list.length) {
      setList(s.corpses.map((c) => ({ id: c.id, x: c.x, y: c.y })));
    }
  });
  return (
    <>
      {list.map((c) => (
        <group key={c.id} position={[c.x * U, 0.02, c.y * U]}>
          <mesh rotation-x={-Math.PI / 2}>
            <circleGeometry args={[PLAYER_R * U * 1.3, 20]} />
            <meshBasicMaterial color="#2a1520" transparent opacity={0.75} />
          </mesh>
          <Html center distanceFactor={9} position={[0, 0.25, 0]} zIndexRange={[4, 0]}>
            <div className="pointer-events-none text-3xl opacity-80">💀</div>
          </Html>
        </group>
      ))}
    </>
  );
}

/* ------------------------------------------------------------------ */
/* arena floor + closing walls                                         */
/* ------------------------------------------------------------------ */

function floorTexture() {
  const c = document.createElement("canvas");
  c.width = c.height = 256;
  const x = c.getContext("2d")!;
  x.fillStyle = "#66b45c";
  x.fillRect(0, 0, 256, 256);
  x.fillStyle = "#5da755";
  x.fillRect(0, 0, 128, 128);
  x.fillRect(128, 128, 128, 128);
  for (let i = 0; i < 900; i++) {
    x.fillStyle = `rgba(255,255,255,${Math.random() * 0.07})`;
    x.fillRect(Math.random() * 256, Math.random() * 256, 3, 3);
  }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(16, 9);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function Arena({ stateRef }: { stateRef: StateRef }) {
  const tex = useMemo(floorTexture, []);
  const walls = useRef<(THREE.Mesh | null)[]>([]);
  const zones = useRef<(THREE.Mesh | null)[]>([]);

  useFrame(() => {
    const s = stateRef.current;
    if (!s) return;
    const b = currentBounds(s.phase === "countdown" ? 0 : s.t);
    const l = b.left * U;
    const r = b.right * U;
    const t = b.top * U;
    const bo = b.bottom * U;
    const w = r - l;
    const h = bo - t;
    const th = 0.22;
    const hh = 0.7;
    const set = (i: number, px: number, pz: number, sx: number, sz: number) => {
      const m = walls.current[i];
      if (!m) return;
      m.position.set(px, hh / 2, pz);
      m.scale.set(sx, hh, sz);
    };
    set(0, (l + r) / 2, t - th / 2, w + th * 2, th);
    set(1, (l + r) / 2, bo + th / 2, w + th * 2, th);
    set(2, l - th / 2, (t + bo) / 2, th, h);
    set(3, r + th / 2, (t + bo) / 2, th, h);

    const zone = (i: number, px: number, pz: number, sx: number, sz: number) => {
      const m = zones.current[i];
      if (!m) return;
      m.position.set(px, 0.015, pz);
      m.scale.set(Math.max(0.0001, sx), Math.max(0.0001, sz), 1);
    };
    zone(0, CX, t / 2, AW, t);
    zone(1, CX, (bo + AH) / 2, AW, AH - bo);
    zone(2, l / 2, (t + bo) / 2, l, h);
    zone(3, (r + AW) / 2, (t + bo) / 2, AW - r, h);
  });

  return (
    <group>
      <mesh rotation-x={-Math.PI / 2} position={[CX, 0, CZ]} receiveShadow>
        <planeGeometry args={[AW, AH]} />
        <meshStandardMaterial map={tex} roughness={0.85} />
      </mesh>
      {[0, 1, 2, 3].map((i) => (
        <mesh
          key={`z${i}`}
          ref={(m) => {
            zones.current[i] = m;
          }}
          rotation-x={-Math.PI / 2}
        >
          <planeGeometry args={[1, 1]} />
          <meshBasicMaterial color="#12101a" transparent opacity={0.62} />
        </mesh>
      ))}
      {[0, 1, 2, 3].map((i) => (
        <mesh
          key={`w${i}`}
          ref={(m) => {
            walls.current[i] = m;
          }}
          castShadow
        >
          <boxGeometry args={[1, 1, 1]} />
          <meshStandardMaterial color="#f0a13c" emissive="#e07a1f" emissiveIntensity={0.5} roughness={0.5} />
        </mesh>
      ))}
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* aim helper + camera                                                 */
/* ------------------------------------------------------------------ */

function AimPlane({
  stateRef,
  selfId,
  onAim,
  onShoot,
  shootOnClick,
}: {
  stateRef: StateRef;
  selfId: string;
  onAim: (a: number) => void;
  onShoot: () => void;
  shootOnClick: boolean;
}) {
  const aimTo = (e: ThreeEvent<PointerEvent>) => {
    const s = stateRef.current;
    const me = s?.players.find((p) => p.id === selfId);
    if (!me) return;
    onAim(Math.atan2(e.point.z / U - me.y, e.point.x / U - me.x));
  };
  return (
    <mesh
      rotation-x={-Math.PI / 2}
      position={[CX, 0, CZ]}
      visible={false}
      onPointerMove={aimTo}
      onPointerDown={(e) => {
        aimTo(e);
        if (shootOnClick) onShoot();
      }}
    >
      <planeGeometry args={[AW * 3, AH * 3]} />
      <meshBasicMaterial />
    </mesh>
  );
}

function AimLine({ stateRef, selfId }: { stateRef: StateRef; selfId: string }) {
  const g = useRef<THREE.Group>(null);
  useFrame(() => {
    const s = stateRef.current;
    const me = s?.players.find((p) => p.id === selfId);
    if (!g.current) return;
    if (!s || !me || !me.alive || s.ball.holder !== selfId) {
      g.current.visible = false;
      return;
    }
    g.current.visible = true;
    g.current.position.set(me.x * U, 0.06, me.y * U);
    g.current.rotation.y = -me.aim;
  });
  return (
    <group ref={g}>
      <mesh position={[1.6, 0, 0]} rotation-x={-Math.PI / 2}>
        <planeGeometry args={[3.2, 0.07]} />
        <meshBasicMaterial color="#ffd166" transparent opacity={0.45} />
      </mesh>
    </group>
  );
}

function CameraRig({ stateRef, selfId }: { stateRef: StateRef; selfId: string }) {
  const look = useRef(new THREE.Vector3(CX, 0, CZ));
  useFrame(({ camera, size }, delta) => {
    const s = stateRef.current;
    const me = s?.players.find((p) => p.id === selfId);
    const tx = me && me.alive ? CX + (me.x * U - CX) * 0.18 : CX;
    const tz = me && me.alive ? CZ + (me.y * U - CZ) * 0.18 : CZ;
    look.current.lerp(new THREE.Vector3(tx, 0, tz), 1 - Math.exp(-3 * delta));
    const aspect = size.width / Math.max(1, size.height);
    const dist = aspect < 1.1 ? 21 : 15.5;
    const target = new THREE.Vector3(look.current.x, dist * 0.86, look.current.z + dist * 0.52);
    camera.position.lerp(target, 1 - Math.exp(-3 * delta));
    camera.lookAt(look.current);
  });
  return null;
}

/* ------------------------------------------------------------------ */

export function Arena3D({ stateRef, players, selfId, onAim, onShoot, shootOnClick, quality = "high" }: Props) {
  const cfg = QUALITY[quality];
  return (
    <Canvas
      key={quality}
      shadows={cfg.shadows}
      dpr={cfg.dpr}
      camera={{ position: [CX, 13, CZ + 8], fov: 42 }}
      className="touch-none"
      gl={{ antialias: cfg.antialias, powerPreference: "high-performance" }}
    >
      <color attach="background" args={["#0d1320"]} />
      <fog attach="fog" args={["#0d1320", cfg.fog[0], cfg.fog[1]]} />
      <hemisphereLight args={["#bfe6ff", "#3d6b3a", cfg.env ? 0.85 : 1.15]} />
      <directionalLight
        position={[CX + 6, 14, CZ - 5]}
        intensity={cfg.env ? 2 : 2.4}
        castShadow={cfg.shadows}
        shadow-mapSize-width={cfg.shadowMap}
        shadow-mapSize-height={cfg.shadowMap}
        shadow-camera-left={-12}
        shadow-camera-right={12}
        shadow-camera-top={9}
        shadow-camera-bottom={-9}
      />
      {cfg.env && (
        <Environment>
          <Lightformer intensity={1.6} position={[0, 6, 0]} scale={[12, 12, 1]} />
          <Lightformer intensity={0.8} color="#9fd4ff" position={[-6, 2, -2]} rotation-y={Math.PI / 2} scale={[20, 2, 1]} />
        </Environment>
      )}
      <CameraRig stateRef={stateRef} selfId={selfId} />
      <Arena stateRef={stateRef} />
      <AimPlane stateRef={stateRef} selfId={selfId} onAim={onAim} onShoot={onShoot} shootOnClick={shootOnClick} />
      <AimLine stateRef={stateRef} selfId={selfId} />
      <Orb stateRef={stateRef} />
      <Corpses stateRef={stateRef} />
      <ClawFx stateRef={stateRef} />
      <Suspense fallback={null}>
        <ModelBoundary>
          <Wolf stateRef={stateRef} />
        </ModelBoundary>
        {players.map((p) => (
          <ModelBoundary key={p.id} urls={[getCharacter(p.charId).model]}>
            <PlayerActor id={p.id} charId={p.charId} name={p.name} stateRef={stateRef} selfId={selfId} />
          </ModelBoundary>
        ))}
      </Suspense>

    </Canvas>
  );
}
