import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Environment, Html, Lightformer, useAnimations, useGLTF } from "@react-three/drei";
import * as THREE from "three";
import { clone as cloneSkeleton } from "three/examples/jsm/utils/SkeletonUtils.js";
import { ModelBoundary } from "@/components/ModelBoundary";
import { applyPetAppearance } from "@/lib/game/petAppearance";
import { getAnimal, getColor, type Pet } from "@/lib/game/pets";

const FIELD_X = 2.5;
const FIELD_Z = 1.5;

export type PetMood = { speed: number; badge?: string | undefined; caredAt?: number | undefined; scale?: number | undefined };

function seededNumber(text: string, salt: number) {
  let value = 2166136261 ^ salt;
  for (let index = 0; index < text.length; index += 1) {
    value = Math.imul(value ^ text.charCodeAt(index), 16777619);
  }
  return ((value >>> 0) % 10_000) / 10_000;
}

function FieldCamera() {
  const { camera } = useThree();
  useEffect(() => {
    camera.lookAt(0, 0.2, 0);
  }, [camera]);
  return null;
}

function WalkingPet({
  pet,
  index,
  paused,
  onSelect,
  onPetPointerDown,
  onPetHover,
  mood,
}: {
  pet: Pet;
  index: number;
  paused: boolean;
  mood?: PetMood | undefined;
  onSelect?: ((pet: Pet) => void) | undefined;
  onPetPointerDown?: ((pet: Pet, point: { clientX: number; clientY: number }) => void) | undefined;
  onPetHover?: ((pet: Pet | null, point?: { clientX: number; clientY: number }) => void) | undefined;
}) {
  const SPEED = 0.4;
  const moodRef = useRef(mood);
  moodRef.current = mood;
  const animal = getAnimal(pet.animal);
  const gltf = useGLTF(animal.model);
  const group = useRef<THREE.Group>(null);
  const inner = useRef<THREE.Group>(null);
  const start = useMemo(
    () =>
      new THREE.Vector3(
        THREE.MathUtils.lerp(-FIELD_X, FIELD_X, seededNumber(pet.id, index + 11)),
        0,
        THREE.MathUtils.lerp(-FIELD_Z, FIELD_Z, seededNumber(pet.id, index + 29)),
      ),
    [index, pet.id],
  );
  const position = useRef(start.clone());
  const target = useRef(start.clone());
  const waiting = useRef(seededNumber(pet.id, index + 47) * 2);
  const moving = useRef(false);
  const step = useRef(0);

  const scene = useMemo(() => {
    const cloned = cloneSkeleton(gltf.scene) as THREE.Group;
    const tint = getColor(pet.color).hex;
    const patternTint = getColor(pet.pattern_color).hex;
    cloned.traverse((object) => {
      const mesh = object as THREE.Mesh;
      if (!mesh.isMesh) return;
      if (tint || pet.pattern !== "plain") {
        mesh.material = applyPetAppearance(mesh.material as THREE.Material, {
          tint,
          pattern: pet.pattern,
          patternTint,
        });
      }
      mesh.castShadow = true;
      mesh.receiveShadow = true;
    });
    return cloned;
  }, [gltf.scene, pet.color, pet.pattern, pet.pattern_color]);

  const { actions, names } = useAnimations(gltf.animations, inner);
  const idleName = names.find((name) => name.toLowerCase().includes("idle")) ?? names[0];
  const walkName = names.find((name) => name.toLowerCase().includes("walk")) ?? idleName;
  const activeClip = useRef<string | undefined>(undefined);

  useFrame((_state, rawDelta) => {
    const actor = group.current;
    if (!actor) return;
    const delta = Math.min(rawDelta, 0.05);

    if (!paused) {
      waiting.current -= delta;
      if (waiting.current <= 0) {
        step.current += 1;
        target.current.set(
          THREE.MathUtils.lerp(-FIELD_X, FIELD_X, seededNumber(pet.id, index * 41 + step.current * 13)),
          0,
          THREE.MathUtils.lerp(-FIELD_Z, FIELD_Z, seededNumber(pet.id, index * 67 + step.current * 17)),
        );
        waiting.current = 2.2 + seededNumber(pet.id, step.current * 23) * 3.2;
      }

      const direction = target.current.clone().sub(position.current);
      const distance = direction.length();
      moving.current = distance > 0.12;
      if (moving.current) {
        direction.normalize();
        position.current.addScaledVector(direction, Math.min(distance, delta * SPEED * (moodRef.current?.speed ?? 1)));
        const wantedYaw = Math.atan2(direction.x, direction.z);
        actor.rotation.y = THREE.MathUtils.lerp(actor.rotation.y, wantedYaw, 1 - Math.exp(-9 * delta));
      }
    } else {
      moving.current = false;
    }

    position.current.x = THREE.MathUtils.clamp(position.current.x, -FIELD_X, FIELD_X);
    position.current.z = THREE.MathUtils.clamp(position.current.z, -FIELD_Z, FIELD_Z);
    actor.position.copy(position.current);

    const targetScale = moodRef.current?.scale ?? 0.4;
    const currentScale = actor.scale.x || 0.4;
    const nextScale = THREE.MathUtils.lerp(currentScale, targetScale, 1 - Math.exp(-14 * delta));
    actor.scale.setScalar(nextScale);

    const wantedClip = moving.current ? walkName : idleName;
    if (wantedClip && activeClip.current !== wantedClip) {
      if (activeClip.current) actions[activeClip.current]?.fadeOut(0.2);
      const nextAction = actions[wantedClip];
      if (nextAction) {
        nextAction.reset().fadeIn(0.2).play();
        // ท่าเดินให้ขาขยับถี่ขึ้นเล็กน้อย จะได้เห็นลีล่าชัดเจน
        nextAction.timeScale = wantedClip === walkName ? 1.35 * Math.max(0.5, moodRef.current?.speed ?? 1) : 1;
      }
      activeClip.current = wantedClip;
    }
    // กันคลิปหยุดค้าง (เช่น โดนถดถอยน้ำหนักจนหมด) ให้เริ่มเล่นใหม่ทันที
    const activeAction = activeClip.current ? actions[activeClip.current] : undefined;
    if (activeAction && !activeAction.isRunning()) activeAction.reset().play();

    // โยกตัวเบาๆ ตามจังหวะเดิน
    const bob = moving.current && !paused ? Math.abs(Math.sin(performance.now() / 140)) * 0.06 : 0;
    // ได้รับการดูแลแล้วกระโดดดีใจ ~1.2 วินาที
    const since = moodRef.current?.caredAt ? (Date.now() - moodRef.current.caredAt) / 1000 : 99;
    const hop = since < 1.2 ? Math.abs(Math.sin(since * Math.PI * 2.5)) * 0.5 * (1 - since / 1.2) : 0;
    actor.position.y = bob + hop;
  });

  return (
    <group
      ref={group}
      scale={0.4}
      onPointerDown={(event) => {
        event.stopPropagation();
        if (onPetPointerDown) {
          onPetPointerDown(pet, { clientX: event.clientX, clientY: event.clientY });
          return;
        }
        onSelect?.(pet);
      }}
      onPointerOver={(event) => {
        document.body.style.cursor = "pointer";
        onPetHover?.(pet, { clientX: event.clientX, clientY: event.clientY });
      }}
      onPointerMove={(event) => {
        onPetHover?.(pet, { clientX: event.clientX, clientY: event.clientY });
      }}
      onPointerOut={() => {
        document.body.style.cursor = "";
        onPetHover?.(null);
      }}
    >
      <group ref={inner}>
        <primitive object={scene} />
      </group>
      {mood?.badge && (
        <Html position={[0, 2.6, 0]} center style={{ pointerEvents: "none", fontSize: 18 }}>
          {mood.badge}
        </Html>
      )}
    </group>
  );
}

function Field({
  pets,
  paused,
  onSelectPet,
  onPetHover,
  onPetPointerDown,
  moods,
}: {
  pets: Pet[];
  paused: boolean;
  moods?: Record<string, PetMood> | undefined;
  onSelectPet?: ((pet: Pet) => void) | undefined;
  onPetPointerDown?: ((pet: Pet, point: { clientX: number; clientY: number }) => void) | undefined;
  onPetHover?: ((pet: Pet | null, point?: { clientX: number; clientY: number }) => void) | undefined;
}) {
  return (
    <>
      <FieldCamera />
      <ambientLight intensity={0.8} />
      <hemisphereLight args={["#b9ecff", "#76b852", 1.1]} />
      <directionalLight
        position={[7, 12, 8]}
        intensity={1.45}
        castShadow
        shadow-mapSize={[1024, 1024]}
        shadow-camera-left={-10}
        shadow-camera-right={10}
        shadow-camera-top={8}
        shadow-camera-bottom={-8}
      />
      <Environment>
        <Lightformer intensity={1.5} position={[0, 8, 2]} scale={[14, 8, 1]} />
        <Lightformer intensity={0.7} color="#fff08a" position={[-7, 3, 1]} rotation-y={Math.PI / 2} scale={[10, 4, 1]} />
      </Environment>

      {/* พื้นกลางใช้รูป 2D เป็นฉากหลัง แผ่นนี้โปร่งใส รับเงาเท่านั้น */}
      <mesh rotation-x={-Math.PI / 2} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[18, 12]} />
        <shadowMaterial transparent opacity={0.2} />
      </mesh>

      {pets.map((pet, index) => (
        <Suspense key={pet.id} fallback={null}>
          <ModelBoundary urls={[getAnimal(pet.animal).model]}>
            <WalkingPet pet={pet} index={index} paused={paused} onSelect={onSelectPet} onPetPointerDown={onPetPointerDown} onPetHover={onPetHover} mood={moods?.[pet.id]} />
          </ModelBoundary>
        </Suspense>
      ))}
    </>
  );
}

export function HomePetField3D({
  pets,
  capacity,
  onSelectPet,
  onPetHover,
  onPetPointerDown,
  moods,
}: {
  pets: Pet[];
  moods?: Record<string, PetMood> | undefined;
  /** จำนวนสัตว์ที่ออกมาเดินได้สูงสุด (ขยายได้จากร้านค้า) */
  capacity?: number | undefined;
  onSelectPet?: ((pet: Pet) => void) | undefined;
  onPetPointerDown?: ((pet: Pet, point: { clientX: number; clientY: number }) => void) | undefined;
  onPetHover?: ((pet: Pet | null, point?: { clientX: number; clientY: number }) => void) | undefined;
}) {
  const [compact, setCompact] = useState(false);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    const compactQuery = window.matchMedia("(max-width: 1023px)");
    const motionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    const sync = () => {
      setCompact(compactQuery.matches);
      setPaused(motionQuery.matches);
    };
    sync();
    compactQuery.addEventListener("change", sync);
    motionQuery.addEventListener("change", sync);
    return () => {
      compactQuery.removeEventListener("change", sync);
      motionQuery.removeEventListener("change", sync);
    };
  }, []);

  const deviceCap = compact ? 5 : 12;
  const visiblePets = pets.slice(0, Math.min(deviceCap, capacity ?? deviceCap));

  return (
    <div className="home-pet-field absolute inset-0" aria-label="สัตว์เลี้ยงสามมิติเดินเล่นในลาน">
      <Canvas
        shadows
        dpr={compact ? 1 : [1, 1.5]}
        camera={{ position: [0, compact ? 11.5 : 10, compact ? 15.5 : 14], fov: compact ? 43 : 38 }}
        gl={{ antialias: true, alpha: true }}
      >
        <Field pets={visiblePets} paused={paused} onSelectPet={onSelectPet} onPetPointerDown={onPetPointerDown} onPetHover={onPetHover} moods={moods} />
      </Canvas>
    </div>
  );
}