import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { userToEmail } from "@/hooks/useAuth";
import { Spinner } from "@/components/Spinner";

export function AuthScreen({ onDone }: { onDone: () => void }) {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");

  
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const user = username.trim().toLowerCase();
    if (user.length < 3) return setError("ชื่อผู้ใช้ต้องยาว 3 ตัวอักษรขึ้นไป");
    if (!/^[a-z0-9_]+$/.test(user)) return setError("ใช้ได้เฉพาะ a-z, 0-9 และ _");
    if (password.length < 6) return setError("รหัสผ่านต้องยาว 6 ตัวขึ้นไป");
    if (mode === "signup" && password !== confirm) return setError("รหัสผ่านยืนยันไม่ตรงกัน");
    setBusy(true);
    try {
      if (mode === "signup") {
        const { data, error: err } = await supabase.auth.signUp({
          email: userToEmail(user),
          password,
        });
        if (err) throw err;
        if (data.user) {
          const { error: pErr } = await supabase
            .from("profiles")
            .insert({
              id: data.user.id,
              username: user,
              coins: 1000,
              gems: 1000,
              food_items: 10,
              milk_items: 10,
              med_items: 5,
            });
          if (pErr && !pErr.message.includes("duplicate")) throw pErr;
        }
      } else {
        const { error: err } = await supabase.auth.signInWithPassword({
          email: userToEmail(user),
          password,
        });
        if (err) throw err;
      }
      onDone();
    } catch (err) {
      const msg = err instanceof Error ? err.message : "เกิดข้อผิดพลาด";
      setError(
        msg.includes("Invalid login")
          ? "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง"
          : msg.includes("already registered")
            ? "ชื่อผู้ใช้นี้ถูกใช้แล้ว"
            : msg,
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-10">
      <div className="panel w-full max-w-md p-8">
        <div className="text-center">
          <div className="text-5xl">🐺🔮</div>
          <h1 className="mt-3 text-4xl">PawPets</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            ส่งลูกแก้วให้เพื่อน ก่อนหมาป่าจะเจอคุณ
          </p>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-2 rounded-lg bg-secondary p-1">
          {(["login", "signup"] as const).map((m) => (
            <button
              key={m}
              onClick={() => {
                setMode(m);
                setError(null);
              }}
              className={`rounded-md py-2 font-display text-lg tracking-wide ${
                mode === m ? "bg-primary text-primary-foreground" : "text-muted-foreground"
              }`}
            >
              {m === "login" ? "เข้าสู่ระบบ" : "สมัครสมาชิก"}
            </button>
          ))}
        </div>

        <form onSubmit={submit} className="mt-5 space-y-3">
          <input
            className="w-full rounded-lg bg-input px-4 py-3 outline-none ring-ring focus:ring-2"
            placeholder="ชื่อผู้ใช้"
            value={username}
            autoCapitalize="none"
            onChange={(e) => setUsername(e.target.value)}
          />
          <input
            className="w-full rounded-lg bg-input px-4 py-3 outline-none ring-ring focus:ring-2"
            placeholder="รหัสผ่าน"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          {mode === "signup" && (
            <input
              className="w-full rounded-lg bg-input px-4 py-3 outline-none ring-ring focus:ring-2"
              placeholder="ยืนยันรหัสผ่าน"
              type="password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
            />
          )}
          {error && <p className="text-sm text-destructive">{error}</p>}
          <button disabled={busy} className="btn-base btn-primary w-full disabled:opacity-60" type="submit">
            {busy ? (
              <span className="inline-flex items-center gap-2">
                <Spinner /> กำลังดำเนินการ...
              </span>
            ) : mode === "login" ? "เข้าเกม" : "สร้างบัญชี"}
          </button>
        </form>
      </div>
    </div>
  );
}
