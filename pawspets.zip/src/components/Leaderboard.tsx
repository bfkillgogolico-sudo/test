import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Spinner } from "@/components/Spinner";
import { formatCompact } from "@/lib/format";
import type { FriendsState } from "@/hooks/useFriends";

type Row = { id: string; username: string; credits: number };

export function Leaderboard({
  social,
  open,
  onOpenChange,
}: {
  social: FriendsState;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [friendsOnly, setFriendsOnly] = useState(false);
  const [tab, setTab] = useState<"credits" | "rage">("credits");

  useEffect(() => {
    let stop = false;
    const load = async () => {
      const { data } = await supabase.rpc("public_profiles");
      if (stop) return;
      setRows(
        ((data ?? []) as any[])
          .map((p: any) => ({
            id: p.id as string,
            username: p.username as string,
            credits: Number(p.credits ?? 0),
          }))
          .sort((a, b) => b.credits - a.credits)
          .slice(0, 200),
      );

      setLoading(false);
    };
    void load();
    const t = setInterval(load, 20000);
    return () => {
      stop = true;
      clearInterval(t);
    };
  }, []);

  const circle = useMemo(() => {
    const s = new Set(social.friends.map((f) => f.userId));
    if (social.meId) s.add(social.meId);
    return s;
  }, [social.friends, social.meId]);

  const top = useMemo(
    () => (friendsOnly ? rows.filter((r) => circle.has(r.id)) : rows).slice(0, 10),
    [rows, friendsOnly, circle],
  );

  const medal = (i: number) => (i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `${i + 1}.`);

  return (
    <>
      <button
        onClick={() => onOpenChange(!open)}
        className="panel fixed top-1/2 left-0 z-30 -translate-y-1/2 px-2 py-4 font-display text-lg"
        style={{ left: open ? "18rem" : 0 }}
      >
        {open ? "‹" : "🏆"}
      </button>

      <aside
        className="fixed top-0 left-0 z-20 h-full w-72 overflow-y-auto border-r border-border bg-card/95 p-3 transition-transform"
        style={{ transform: open ? "none" : "translateX(-100%)" }}
      >
        <h2 className="font-display text-xl">🏆 อันดับผู้เล่น</h2>

        <div className="mt-3 grid grid-cols-2 gap-1 rounded-lg bg-secondary p-1">
          {(
            [
              ["credits", "💠 เครดิต"],
              ["rage", "🔥 แร้ง"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`rounded-md py-1 font-display text-base ${
                tab === id ? "bg-primary text-primary-foreground" : "text-muted-foreground"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <button
          onClick={() => setFriendsOnly((v) => !v)}
          className="btn-base btn-ghost mt-2 w-full px-3 py-1 text-sm"
        >
          {friendsOnly ? "👥 เฉพาะเพื่อน (กดเพื่อดูทั้งเซิฟ)" : "🌍 ทั้งหมดในเซิฟ (กดเพื่อดูเฉพาะเพื่อน)"}
        </button>

        {tab === "credits" ? (
          loading ? (
            <p className="mt-4 inline-flex items-center gap-2 text-sm text-muted-foreground">
              <Spinner /> กำลังโหลด...
            </p>
          ) : top.length === 0 ? (
            <p className="mt-4 text-sm text-muted-foreground">ยังไม่มีข้อมูลอันดับ</p>
          ) : (
            <ol className="mt-3 space-y-2">
              {top.map((r, i) => (
                <li
                  key={r.id}
                  className={`flex items-center justify-between rounded-lg px-3 py-2 ${
                    r.id === social.meId ? "bg-primary/20 ring-1 ring-primary" : "bg-secondary"
                  }`}
                >
                  <span className="min-w-0 truncate font-display text-lg">
                    {medal(i)} {r.username}
                  </span>
                  <span className="shrink-0 text-sm text-emerald-300">💠 {formatCompact(r.credits)}</span>
                </li>
              ))}
            </ol>
          )
        ) : (
          <p className="mt-4 text-sm text-muted-foreground">
            🔥 อันดับแร้ง — ระบบแร้งกำลังจะมาในอนาคต ตอนนี้ยังไม่มีคะแนน
          </p>
        )}
      </aside>
    </>
  );
}
