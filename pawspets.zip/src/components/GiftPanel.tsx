import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { CharacterModel3D } from "@/components/CharacterModel3D";
import { Spinner } from "@/components/Spinner";
import { StarFilter, effectiveStar } from "@/components/StarFilter";
import { supabase } from "@/integrations/supabase/client";
import { giftCost, giftPet, type GiftResult } from "@/lib/shop.functions";
import { getAnimal, getColor, genderSymbol, stars, type Pet } from "@/lib/game/pets";

type Props = { pets: Pet[]; gems: number; onRefresh: () => void };

function Mini({ pet }: { pet: Pet }) {
  const a = getAnimal(pet.animal);
  const c = getColor(pet.color);
  const patC = getColor(pet.pattern_color);
  return (
    <div className="text-center">
      <CharacterModel3D
        model={a.model}
        tint={c.hex}
        pattern={pet.pattern}
        patternTint={patC.hex}
        className="mx-auto h-20 w-20"
        emoji={a.emoji}
      />
      <div className="font-display text-base leading-none">
        {a.name}{" "}
        <span className={pet.gender === "female" ? "text-pink-400" : "text-sky-400"}>{genderSymbol(pet.gender)}</span>
      </div>
      <div className="font-display text-sm text-yellow-300">{stars(pet.stars)}</div>
      <div className="text-xs text-emerald-300">💠 {pet.credit_rate}/วิ</div>
    </div>
  );
}

export function GiftPanel({ pets, gems, onRefresh }: Props) {
  const [petId, setPetId] = useState<string | null>(null);
  const [starFilter, setStarFilter] = useState<number | null>(null);
  const [name, setName] = useState("");
  const [names, setNames] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [done, setDone] = useState<(GiftResult & { ok: true }) | null>(null);
  const run = useServerFn(giftPet);

  useEffect(() => {
    let alive = true;
    void (async () => {
      const { data } = await supabase.rpc("public_profiles");
      if (alive)
        setNames(
          ((data ?? []) as any[])
            .map((r: any) => r.username as string)
            .sort((a, b) => a.localeCompare(b))
            .slice(0, 300),
        );

    })();
    return () => {
      alive = false;
    };
  }, []);

  const pet = pets.find((p) => p.id === petId) ?? null;
  const cost = pet ? giftCost(pet.credit_rate) : 0;
  const effStars = effectiveStar(pets, starFilter);
  const list = pets.filter((p) => p.stars === effStars);
  const q = name.trim().toLowerCase();
  const matches = q ? names.filter((n) => n.toLowerCase().includes(q)).slice(0, 8) : [];

  async function send() {
    if (!pet || !name.trim() || busy) return;
    setBusy(true);
    setMsg(null);
    try {
      const res = (await run({ data: { petId: pet.id, username: name.trim() } })) as GiftResult;
      if (!res.ok) {
        setMsg(
          res.reason === "no_user"
            ? "ไม่พบผู้เล่นชื่อนี้"
            : res.reason === "self"
              ? "ส่งให้ตัวเองไม่ได้"
              : res.reason === "no_gems"
                ? `💎 เพชรไม่พอ (ต้องมี ${res.cost ?? cost})`
                : "ส่งไม่สำเร็จ ลองอีกครั้ง",
        );
      } else {
        setDone(res);
        setPetId(null);
        setName("");
        onRefresh();
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="mt-5 space-y-4">
      <div className="panel p-5">
        <h2 className="text-2xl">🎁 ส่งสัตว์</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          พิมพ์ชื่อผู้เล่นและเลือกสัตว์ที่จะส่ง — ค่าใช้จ่าย 100 เพชรต่อตัว
        </p>

        <div className="mt-4">
          <input
            value={name}
            onChange={(e) => {
              setName(e.target.value);
              setMsg(null);
            }}
            placeholder="ชื่อผู้เล่นที่จะส่งให้"
            className="w-full rounded-lg bg-secondary px-3 py-2 outline-none"
          />
          {matches.length > 0 && matches[0]?.toLowerCase() !== q && (
            <div className="mt-2 flex flex-wrap gap-2">
              {matches.map((n) => (
                <button
                  key={n}
                  onClick={() => setName(n)}
                  className="rounded-full bg-secondary px-3 py-1 text-sm text-cyan-300"
                >
                  {n}
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="mt-4 flex items-center justify-between gap-3">
          <div className="text-sm">
            {pet ? (
              <>
                <span className="text-muted-foreground">สัตว์ที่เลือก: </span>
                <span className="text-primary">{getAnimal(pet.animal).name}</span>
                <span className="text-cyan-300"> · ค่าใช้จ่าย 💎 {cost}</span>
              </>
            ) : (
              <span className="text-muted-foreground">ยังไม่ได้เลือกสัตว์</span>
            )}
          </div>
          <button
            onClick={() => void send()}
            disabled={!pet || !name.trim() || busy || gems < cost}
            className="btn-base btn-primary disabled:opacity-50"
          >
            {busy ? (
              <span className="inline-flex items-center gap-2">
                <Spinner /> กำลังส่ง...
              </span>
            ) : (
              `🎁 ส่งสัตว์ — 💎 ${cost}`
            )}
          </button>
        </div>
        {msg && <p className="mt-3 text-center font-display text-xl text-primary">{msg}</p>}
      </div>

      <div className="panel p-5">
        <h3 className="text-xl">สัตว์ของคุณ ({list.length})</h3>
        <div className="mt-2">
          <StarFilter pets={pets} value={effStars} onChange={setStarFilter} />
        </div>
        {pets.length === 0 ? (
          <p className="mt-2 text-sm text-muted-foreground">ยังไม่มีสัตว์ให้ส่ง</p>
        ) : list.length === 0 ? (
          <p className="mt-2 text-sm text-muted-foreground">ไม่มีสัตว์ในหมวดดาวนี้</p>
        ) : (
          <div className="mt-3 grid grid-cols-3 gap-3 sm:grid-cols-4">
            {list.map((p) => (
              <button
                key={p.id}
                onClick={() => {
                  setPetId(p.id);
                  setMsg(null);
                }}
                className={`rounded-lg p-2 ${p.id === petId ? "bg-primary/20 ring-2 ring-primary" : "bg-secondary"}`}
              >
                <Mini pet={p} />
                <div className="mt-1 text-xs text-cyan-300">💎 {giftCost(p.credit_rate)}</div>
              </button>
            ))}
          </div>
        )}
      </div>

      {done && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
          <div className="panel w-full max-w-sm p-5 text-center">
            <h3 className="text-2xl text-primary">ส่งสำเร็จ!</h3>
            <p className="mt-2 text-sm">
              ส่ง{getAnimal(done.animal).name} ให้ <span className="text-cyan-300">{done.to}</span> · 💎 {done.cost}
            </p>
            <button onClick={() => setDone(null)} className="btn-base btn-primary mt-4">
              ตกลง
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
