import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { RealtimeChannel } from "@supabase/supabase-js";
import { CharacterModel3D } from "@/components/CharacterModel3D";
import { getCharacter } from "@/lib/game/characters";
import type { PlayerMeta } from "@/lib/game/engine";
import { genderSymbol, getAnimal, getColor, getPattern, getSkill } from "@/lib/game/pets";

const WAIT_MS = 20_000;
const LAUNCH_DELAY_MS = 3_000;

type Props = {
  selfId: string;
  metas: PlayerMeta[];
  isHost: boolean;
  channel: RealtimeChannel | null;
  /** receives the shared wall-clock start time so every device counts ticks together */
  onReady: (startAt: number) => void;
};

export function GameLoadingScreen({ selfId, metas, isHost, channel, onReady }: Props) {
  const [loadedIds, setLoadedIds] = useState<Set<string>>(new Set());
  const [readyIds, setReadyIds] = useState<Set<string>>(
    () => new Set(metas.filter((m) => m.isBot).map((m) => m.id)),
  );
  const [elapsed, setElapsed] = useState(0);
  const [now, setNow] = useState(Date.now());
  const [launchAt, setLaunchAt] = useState<number | null>(null);
  const mountedAt = useRef<number | null>(null);
  const announced = useRef(false);
  const launched = useRef(false);

  const markLoaded = useCallback(
    (id: string) =>
      setLoadedIds((old) => {
        if (old.has(id)) return old;
        const next = new Set(old);
        next.add(id);
        return next;
      }),
    [],
  );

  const localReady = loadedIds.size >= metas.length;

  useEffect(() => {
    mountedAt.current = performance.now();
    const timer = window.setInterval(() => {
      setNow(Date.now());
      if (mountedAt.current !== null) setElapsed(performance.now() - mountedAt.current);
    }, 200);
    const fallback = window.setTimeout(() => setLoadedIds(new Set(metas.map((m) => m.id))), 8_000);
    return () => {
      window.clearInterval(timer);
      window.clearTimeout(fallback);
    };
  }, [metas]);

  useEffect(() => {
    if (!channel || !localReady || announced.current) return;
    const self = metas.find((m) => m.id === selfId);
    if (!self) return;
    announced.current = true;
    void channel.track({ ...self, loadingReady: true, ...(isHost ? { gameMetas: metas } : {}) });
  }, [channel, isHost, localReady, metas, selfId]);

  useEffect(() => {
    if (!channel) {
      if (localReady) setReadyIds(new Set(metas.map((m) => m.id)));
      return;
    }
    // The channel is already subscribed here, so presence callbacks cannot be
    // attached anymore — poll the presence state instead.
    const sync = () => {
      const connected = new Set<string>();
      const ready = new Set(metas.filter((m) => m.isBot).map((m) => m.id));
      Object.values(channel.presenceState<Record<string, unknown>>()).forEach((entries) => {
        const member = entries[0] as { id?: string; loadingReady?: boolean } | undefined;
        if (!member?.id) return;
        connected.add(member.id);
        if (member.loadingReady) ready.add(member.id);
      });
      metas.filter((m) => !m.isBot && !connected.has(m.id)).forEach((m) => ready.add(m.id));
      setReadyIds(ready);
    };
    channel.on("broadcast", { event: "launch_game" }, ({ payload }) => {
      const time = (payload as { launchAt?: number }).launchAt;
      if (typeof time === "number") setLaunchAt(time);
    });
    sync();
    const poll = window.setInterval(sync, 500);
    return () => window.clearInterval(poll);
  }, [channel, localReady, metas]);

  useEffect(() => {
    if (!isHost || elapsed < WAIT_MS || launchAt !== null) return;
    const time = Date.now() + LAUNCH_DELAY_MS;
    setLaunchAt(time);
    if (channel)
      void channel.send({ type: "broadcast", event: "launch_game", payload: { launchAt: time } });
  }, [channel, elapsed, isHost, launchAt]);

  useEffect(() => {
    if (elapsed < WAIT_MS + LAUNCH_DELAY_MS + 3_000 || launchAt !== null) return;
    setLaunchAt(Date.now());
  }, [elapsed, launchAt]);

  useEffect(() => {
    if (launchAt === null || now < launchAt || launched.current) return;
    launched.current = true;
    onReady(launchAt);
  }, [launchAt, now, onReady]);

  const cards = useMemo(() => metas.slice(0, 6), [metas]);
  const progress = Math.round(Math.min(1, elapsed / WAIT_MS) * 100);

  const launchSeconds = launchAt === null ? null : Math.max(0, Math.ceil((launchAt - now) / 1000));

  return (
    <main className="relative min-h-[100svh] overflow-hidden bg-background px-2 py-3 sm:px-6 sm:py-6">
      <div className="loading-grid absolute inset-0 opacity-50" />
      <div className="relative mx-auto flex h-[calc(100svh-1.5rem)] max-w-6xl flex-col sm:h-[calc(100svh-3rem)]">
        <header className="mb-2 text-center sm:mb-4">
          <p className="font-display text-xs text-accent sm:text-base">PAWPETS</p>
          <h1 className="text-2xl text-foreground sm:text-5xl">เตรียมเข้าสนาม</h1>
        </header>
        <section
          className="grid min-h-0 flex-1 grid-cols-3 grid-rows-2 gap-1.5 sm:gap-4"
          aria-label="ผู้เล่นที่กำลังเตรียมเข้าสนาม"
        >
          {cards.map((meta) => {
            const pet = meta.pet;
            const ch = getCharacter(meta.charId);
            return (
              <article
                key={meta.id}
                className="panel flex min-h-0 flex-col overflow-hidden border-border/80 bg-card/90 p-1.5 sm:p-4"
              >
                <div className="flex min-w-0 items-center justify-between gap-1">
                  <h2 className="truncate text-sm text-foreground sm:text-2xl">{meta.name}</h2>
                  <span
                    className={`h-2 w-2 shrink-0 rounded-full ${readyIds.has(meta.id) ? "bg-accent" : "bg-muted-foreground"}`}
                  />
                </div>
                <CharacterModel3D
                  model={ch.model}
                  tint={ch.tint}
                  pattern={ch.pattern}
                  patternTint={ch.patternTint}
                  rotate={false}
                  onReady={() => markLoaded(meta.id)}
                  className="min-h-0 w-full flex-1"
                  emoji={pet ? getAnimal(pet.animal).emoji : "🐯"}
                />
                <div className="space-y-0.5 border-t border-border/70 pt-1 text-[8px] leading-tight text-muted-foreground sm:pt-2 sm:text-sm">
                  <p className="truncate font-display text-xs text-primary sm:text-xl">
                    {pet ? getAnimal(pet.animal).name : ch.name}
                  </p>
                  <p className="truncate text-primary">{"★".repeat(pet?.stars ?? 1)}</p>
                  <p className="truncate">
                    <span className="text-foreground">สกิล:</span>{" "}
                    {pet ? getSkill(pet.skill).name : ch.skillName}
                  </p>
                  <p className="truncate">
                    <span className="text-foreground">สี:</span>{" "}
                    {pet ? getColor(pet.color).name : "สีปกติ"}
                  </p>
                  <p className="truncate">
                    <span className="text-foreground">ตำหนิ:</span>{" "}
                    {pet ? getPattern(pet.pattern).name : "ไม่มีตำหนิ"}
                  </p>
                  <p>
                    <span className="text-foreground">เพศ:</span>{" "}
                    {pet ? genderSymbol(pet.gender) : "—"}
                  </p>
                </div>
              </article>
            );
          })}
        </section>
        <footer className="mx-auto mt-2 w-full max-w-3xl sm:mt-4">
          <div className="mb-1 flex justify-between text-[10px] text-muted-foreground sm:text-base">
            <span>
              พร้อม {readyIds.size}/{metas.length}
            </span>
            <span>{launchSeconds !== null ? `เริ่มเล่นใน ${launchSeconds}` : ""}</span>
          </div>
          <div className="h-2.5 overflow-hidden rounded-full border border-border bg-muted sm:h-4">
            <div
              className="h-full bg-primary transition-[width] duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </footer>
      </div>
    </main>
  );
}
