import { useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Spinner } from "@/components/Spinner";
import { formatCompact } from "@/lib/format";
import { GEM_AMOUNTS, confirmTopup, verifySlip, type SlipChecks } from "@/lib/topup.functions";
import qr10 from "@/assets/qr/10.png.asset.json";
import qr50 from "@/assets/qr/50.png.asset.json";
import qr100 from "@/assets/qr/100.png.asset.json";
import qr200 from "@/assets/qr/200.png.asset.json";
import qr500 from "@/assets/qr/500.png.asset.json";
import qr1000 from "@/assets/qr/1000.png.asset.json";
import qr3000 from "@/assets/qr/3000.png.asset.json";
import qr5000 from "@/assets/qr/5000.png.asset.json";

const QR: Record<number, string> = {
  10: qr10.url,
  50: qr50.url,
  100: qr100.url,
  200: qr200.url,
  500: qr500.url,
  1000: qr1000.url,
  3000: qr3000.url,
  5000: qr5000.url,
};


export function TopupPanel({ gems, onClose, onGems }: { gems: number; onClose: () => void; onGems: (g: number) => void }) {
  const doVerify = useServerFn(verifySlip);
  const doConfirm = useServerFn(confirmTopup);

  const [amount, setAmount] = useState<number | null>(null);
  const [slip, setSlip] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [checks, setChecks] = useState<SlipChecks | null>(null);
  const [topupId, setTopupId] = useState<string | null>(null);
  const [msg, setMsg] = useState("");
  const [done, setDone] = useState<number | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [qrLoading, setQrLoading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const passed = !!checks && checks.region && checks.qr && checks.amount && !!topupId;

  function reset() {
    setSlip(null);
    setChecks(null);
    setTopupId(null);
    setMsg("");
  }

  async function handleFile(file: File | null | undefined) {
    if (!file || !amount) return;
    if (!file.type.startsWith("image/")) {
      setMsg("ไฟล์ต้องเป็นรูปภาพ");
      return;
    }
    if (file.size > 6_000_000) {
      setMsg("รูปใหญ่เกินไป (สูงสุด 6MB)");
      return;
    }
    const dataUrl = await new Promise<string>((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(String(r.result));
      r.onerror = () => rej(new Error("read_failed"));
      r.readAsDataURL(file);
    });
    setSlip(dataUrl);
    setChecks(null);
    setTopupId(null);
    setMsg("");
    setChecking(true);
    try {
      const res = await doVerify({ data: { amount, image: dataUrl } });
      if (!res.ok) {
        if (res.checks) setChecks(res.checks);
        setMsg(
          res.reason === "duplicate"
            ? "สลิปนี้ถูกใช้ไปแล้ว"
            : res.reason === "ai_failed"
              ? "ตรวจสลิปไม่สำเร็จ ลองแนบใหม่อีกครั้ง"
              : "ตรวจสลิปไม่สำเร็จ",
        );
      } else {
        setChecks(res.checks);
        setTopupId(res.passed ? res.topupId : null);
        if (!res.passed) setMsg("สลิปไม่ผ่านการตรวจสอบ");
      }
    } catch {
      setMsg("ตรวจสลิปไม่สำเร็จ");
    } finally {
      setChecking(false);
    }
  }

  async function confirm() {
    if (!topupId) return;
    setConfirming(true);
    try {
      const res = await doConfirm({ data: { topupId } });
      if (res.ok) {
        onGems(res.gems);
        setDone(res.amount);
      } else setMsg("ยืนยันไม่สำเร็จ");
    } catch {
      setMsg("ยืนยันไม่สำเร็จ");
    } finally {
      setConfirming(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/70 p-4">
      <div className="panel my-6 w-full max-w-lg p-5">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-2xl">💎 เติมเพชร</h2>
          <button onClick={onClose} className="font-display text-xl text-muted-foreground">
            ✕
          </button>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">เพชรปัจจุบัน: {formatCompact(gems)}</p>

        {done !== null ? (
          <div className="mt-6 text-center">
            <div className="font-display text-4xl text-cyan-300">+{done} 💎</div>
            <p className="mt-2 text-sm text-muted-foreground">เติมเพชรเข้าบัญชีเรียบร้อย</p>
            <button onClick={onClose} className="mt-4 w-full rounded-xl bg-primary py-3 font-display text-xl text-primary-foreground">
              ปิด
            </button>
          </div>
        ) : (
          <>
            <div className="mt-4 grid grid-cols-4 gap-2">
              {GEM_AMOUNTS.map((a) => (
                <button
                  key={a}
                  onClick={() => {
                    setAmount(a);
                    setQrLoading(true);
                    reset();
                  }}
                  className={`rounded-xl py-3 font-display text-xl ${
                    amount === a ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"
                  }`}
                >
                  {a}
                </button>
              ))}
            </div>

            {amount && (
              <div className="mt-4 space-y-3">
                <div className="relative rounded-xl bg-white p-3">
                  {qrLoading && (
                    <div className="absolute inset-0 z-10 flex items-center justify-center rounded-xl bg-white">
<Spinner className="h-8 w-8 text-gray-700" />
                    </div>
                  )}
                  <img
                    key={amount}
                    src={QR[amount]}
                    alt={`QR พร้อมเพย์ ${amount} บาท`}
                    onLoad={() => setQrLoading(false)}
                    onError={() => setQrLoading(false)}
                    className={`mx-auto w-full max-w-[260px] ${qrLoading ? "invisible" : ""}`}
                  />
                </div>
                <a
                  href={QR[amount]}
                  download={`qr-${amount}.png`}
                  className="block rounded-xl bg-secondary py-3 text-center font-display text-lg"
                >
                  ⬇ ดาวน์โหลด QR code
                </a>

                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setDragOver(true);
                  }}
                  onDragLeave={() => setDragOver(false)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setDragOver(false);
                    void handleFile(e.dataTransfer.files?.[0]);
                  }}
                  onClick={() => fileRef.current?.click()}
                  className={`cursor-pointer rounded-xl border-2 border-dashed p-5 text-center ${
                    dragOver ? "border-primary bg-primary/10" : "border-border"
                  }`}
                >
                  {slip ? (
                    <img src={slip} alt="สลิปที่แนบ" className="mx-auto max-h-56 rounded-lg" />
                  ) : (
                    <p className="font-display text-lg">📎 แนบสลิป (ลากมาวาง หรือคลิกเพื่อเลือกไฟล์)</p>
                  )}
                  <input
                    ref={fileRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => void handleFile(e.target.files?.[0])}
                  />
                </div>

                {checking && (
                  <div className="flex items-center gap-2 font-display text-lg">
                    <Spinner /> กำลังตรวจสลิป...
                  </div>
                )}

                {checks && !checking && (
                  <div
                    className={`rounded-xl p-3 text-center font-display text-lg ${
                      passed ? "bg-emerald-500/15 text-emerald-400" : "bg-red-500/15 text-red-400"
                    }`}
                  >
                    {passed ? "✔ ตรวจผ่าน" : "✘ ตรวจไม่ผ่าน"}
                  </div>
                )}

                {msg && <p className="text-sm text-red-400">{msg}</p>}

                <p className="text-center text-xs text-muted-foreground">
                  กรุณาแนบสลิปจริง หากตรวจพบการโกง บัญชีอาจถูกแบนและดำเนินคดีตามกฎหมายอย่างร้ายแรง
                </p>

                <button
                  disabled={!passed || confirming}
                  onClick={() => void confirm()}
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 font-display text-xl text-primary-foreground disabled:opacity-40"
                >
                  {confirming && <Spinner />} ยืนยันเติม {amount} 💎
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
