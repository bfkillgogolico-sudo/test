import { Component, Suspense, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { useAnimations, useGLTF } from "@react-three/drei";
import * as THREE from "three";
import { clone as cloneSkeleton } from "three/examples/jsm/utils/SkeletonUtils.js";
import { ModelBoundary } from "./ModelBoundary";
import { applyPetAppearance } from "@/lib/game/petAppearance";

/** Slowly spinning 3D preview of the exact model used in the arena. */
export function CharacterModelScene({
  url,
  tint,
  pattern,
  patternTint,
  rotate = true,
  onReady,
}: {
  url: string;
  tint?: string | null | undefined;
  pattern?: string | null | undefined;
  patternTint?: string | null | undefined;
  rotate?: boolean;
  onReady?: () => void;
}) {
  const gltf = useGLTF(url);
  const group = useRef<THREE.Group>(null);
  const inner = useRef<THREE.Group>(null);

  const { scene, scale, offset } = useMemo(() => {
    const bounds = new THREE.Box3().setFromObject(gltf.scene);
    const size = new THREE.Vector3();
    const center = new THREE.Vector3();
    bounds.getSize(size);
    bounds.getCenter(center);
    const s = cloneSkeleton(gltf.scene) as THREE.Group;
    if (tint || pattern) {
      s.traverse((o) => {
        const m = o as THREE.Mesh;
        if (!m.isMesh) return;
        m.material = applyPetAppearance(m.material as THREE.Material, { tint, pattern, patternTint });
      });
    }

    const fitSize = Math.max(size.y, size.x * 0.8, size.z * 0.8, 1);
    return {
      scene: s,
      scale: 1.4 / fitSize,
      offset: center.multiplyScalar(-1),
    };
  }, [gltf, pattern, patternTint, tint]);

  const { actions } = useAnimations(gltf.animations, inner);

  useEffect(() => onReady?.(), [onReady]);

  useFrame((st, delta) => {
    if (!actions["idle"]?.isRunning()) actions["idle"]?.reset().play();
    if (group.current && rotate) group.current.rotation.y += delta * 0.6;
    void st;
  });

  return (
    <group ref={group}>
      <group ref={inner} scale={scale}>
        <primitive object={scene} position={offset} />
      </group>
    </group>
  );
}

/** Catches "Error creating WebGL context" (browser cap reached) so the card
 *  falls back to the emoji instead of showing a blank white canvas. */
class CanvasBoundary extends Component<{ children: ReactNode; onFail: () => void }, { failed: boolean }> {
  override state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  override componentDidCatch() {
    this.props.onFail();
  }
  override render() {
    return this.state.failed ? null : this.props.children;
  }
}

/** Up to MAX_LIVE canvases at once, prioritised by scroll direction: scrolling
 *  down the lower cards get the 3D models (upper ones drop to emoji), scrolling
 *  up the upper cards win. Hover-pinned cards always get a slot first. */
const MAX_LIVE = 30;

type Slot = {
  id: number;
  visible: boolean;
  pinned: boolean;
  granted: boolean;
  rank: number;
  top: () => number;
  notify: (granted: boolean) => void;
};
const slots: Slot[] = [];
let nextSlotId = 1;
let scrollDir: 1 | -1 = 1; // 1 = down (prefer bottom), -1 = up (prefer top)

/** When a card is hover-pinned, it must win a slot; if the pool is full we
 *  randomly evict other cards to emoji so the hovered one always shows. */
function shuffleRanks() {
  for (const s of slots) s.rank = Math.random();
}

function rebalance() {
  const candidates = slots.filter((s) => s.visible);
  candidates.sort((a, b) => {
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    if (a.rank !== b.rank) return a.rank - b.rank;
    return scrollDir === 1 ? b.top() - a.top() : a.top() - b.top();
  });
  const winners = new Set(candidates.slice(0, MAX_LIVE).map((s) => s.id));
  for (const s of slots) {
    const granted = winners.has(s.id);
    if (granted !== s.granted) {
      s.granted = granted;
      s.notify(granted);
    }
  }
}

if (typeof window !== "undefined") {
  let lastY = window.scrollY;
  let queued = false;
  const onScroll = () => {
    const y = window.scrollY;
    if (y !== lastY) {
      scrollDir = y > lastY ? 1 : -1;
      lastY = y;
    }
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => {
      queued = false;
      rebalance();
    });
  };
  window.addEventListener("scroll", onScroll, { passive: true, capture: true });
}

function useCanvasSlot(visible: boolean, pinned: boolean, top: () => number) {
  const [granted, setGranted] = useState(false);
  const slot = useRef<Slot | null>(null);
  useEffect(() => {
    const s: Slot = { id: nextSlotId++, visible, pinned, granted: false, rank: Math.random(), top, notify: setGranted };
    slot.current = s;
    slots.push(s);
    rebalance();
    return () => {
      const i = slots.indexOf(s);
      if (i >= 0) slots.splice(i, 1);
      slot.current = null;
      rebalance();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    if (!slot.current) return;
    const wasPinned = slot.current.pinned;
    slot.current.visible = visible;
    slot.current.pinned = pinned;
    if (pinned && !wasPinned) shuffleRanks(); // hovered: evict random others if pool full
    rebalance();
  }, [visible, pinned]);
  return granted;
}


export function CharacterModel3D({
  model,
  tint,
  pattern,
  patternTint,
  className = "h-24 w-24",
  rotate = true,
  onReady,
  emoji,
}: {
  model: string;
  tint?: string | null | undefined;
  pattern?: string | null | undefined;
  patternTint?: string | null | undefined;
  className?: string;
  rotate?: boolean;
  onReady?: () => void;
  emoji?: string | undefined;
}) {
  // Mount the Canvas only while the card is near the viewport.
  const host = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = host.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      setVisible(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => setVisible(entries.some((e) => e.isIntersecting)),
      { rootMargin: "300px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  const [pinned, setPinned] = useState(false);
  const granted = useCanvasSlot(visible, pinned, () => host.current?.getBoundingClientRect().top ?? 0);


  // Until the model is on screen and finished loading (or if it fails), show
  // the animal's emoji so no card ever looks empty.
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    setReady(false);
    setFailed(false);
  }, [model]);
  // Lost the slot (scrolled away / evicted): reset so the next chance retries.
  useEffect(() => {
    if (!granted) {
      setReady(false);
      setFailed(false);
    }
  }, [granted]);
  // If the model never becomes ready (context lost, stalled download), drop
  // the canvas so only the emoji remains — never a white square.
  useEffect(() => {
    if (!granted || ready || failed) return;
    const t = setTimeout(() => setFailed(true), 8000);
    return () => clearTimeout(t);
  }, [granted, ready, failed]);
  const ping = () => {
    setReady(true);
    onReady?.();
  };
  const placeholder = (
    <div className="pointer-events-none absolute inset-0 flex items-center justify-center text-[2.5rem] leading-none opacity-90">
      {emoji ?? "🐯"}
    </div>
  );

  const live = granted && !failed;

  // Watchdog: browsers silently evict WebGL contexts past their limit without
  // always firing webglcontextlost — the canvas just stays blank. Poll the
  // context and drop to the emoji the moment it dies.
  const glRef = useRef<{ isContextLost: () => boolean } | null>(null);
  useEffect(() => {
    if (!live) return;
    const t = setInterval(() => {
      const gl = glRef.current;
      if (gl && gl.isContextLost()) setFailed(true);
    }, 2000);
    return () => clearInterval(t);
  }, [live]);

  return (
    <div
      ref={host}
      className={`relative ${className}`}
      onPointerEnter={() => {
        setPinned(true);
        setFailed(false);
      }}
      onPointerLeave={() => setPinned(false)}
    >
      {live ? (
        <CanvasBoundary onFail={() => setFailed(true)}>
          <Canvas
            camera={{ position: [0, 0.9, 3], fov: 35 }}
            dpr={[1, 1.5]}
            gl={{ antialias: true, alpha: true }}
            onCreated={(st) => {
              // Browsers evict the OLDEST WebGL contexts once too many cards
              // mount; an evicted context keeps rendering a blank white
              // canvas. Detect it and fall back to the emoji.
              glRef.current = st.gl.getContext();
              st.gl.domElement.addEventListener("webglcontextlost", (e) => {
                e.preventDefault();
                setFailed(true);
              });
            }}
          >
            <ambientLight intensity={1.1} />
            <directionalLight position={[3, 5, 4]} intensity={1.6} />
            <Suspense fallback={null}>
              <ModelBoundary urls={[model]} fallback={null}>
                <CharacterModelScene
                  url={model}
                  tint={tint}
                  pattern={pattern}
                  patternTint={patternTint}
                  rotate={rotate}
                  onReady={ping}
                />
              </ModelBoundary>
            </Suspense>
          </Canvas>
        </CanvasBoundary>
      ) : null}
      {ready ? null : placeholder}
      <button
        type="button"
        title="แสดงโมเดล 3D (วางเมาส์)"
        onPointerEnter={() => {
          setPinned(true);
          setFailed(false);
        }}
        onFocus={() => {
          setPinned(true);
          setFailed(false);
        }}
        onClick={(e) => {
          e.stopPropagation();
          e.preventDefault();
          setPinned((p) => !p);
          setFailed(false);
        }}

        className={`absolute bottom-0 right-0 z-10 rounded px-1 text-[9px] font-bold leading-tight transition ${
          pinned
            ? "bg-primary text-primary-foreground"
            : "bg-background/70 text-muted-foreground hover:text-foreground"
        }`}
      >
        3D
      </button>
    </div>
  );
}

