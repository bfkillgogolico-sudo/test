import type { GameCharacter } from "@/lib/game/characters";

type Props = { character: GameCharacter; className?: string };

/** Animated (or emoji) avatar for a character, used in menus and lobby lists. */
export function CharacterSprite({ character, className = "h-10 w-10" }: Props) {
  const sprite = character.sprite;
  if (!sprite) {
    return <span className={`${className} inline-flex items-center justify-center text-3xl`}>{character.emoji}</span>;
  }
  return (
    <span
      role="img"
      aria-label={character.name}
      className={`${className} inline-block bg-no-repeat`}
      style={{
        backgroundImage: `url(${sprite.url})`,
        backgroundSize: `${sprite.frames * 100}% 100%`,
        backgroundPositionX: "0%",
      }}
    />
  );
}
