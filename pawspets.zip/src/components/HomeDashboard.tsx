import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { useFriends } from "@/hooks/useFriends";
import { formatCompact } from "@/lib/format";
import { getAnimal, stars, type Pet } from "@/lib/game/pets";
import { STRESS_GAIN_PER_SEC, clampStress } from "@/lib/game/stress";
import { careMyPet, claimPetCredits, creditRateMultiplier, accrueCredits } from "@/lib/shop.functions";
import { HomePetField3D, type PetMood } from "@/components/HomePetField3D";
import homeWorldBg from "@/assets/pawpets-home-bg.jpg";

type PlayerRow = { id: string; username: string; credits: number; online: boolean };

/** ค่าหิว/กระหายค่อย ๆ ลดตามเวลาจริง — อาหารหมดในราว 3.5 ชม. น้ำในราว 2.8 ชม. */
const FOOD_DRAIN_PER_SEC = 100 / (3.5 * 3600);
const WATER_DRAIN_PER_SEC = 100 / (2.8 * 3600);

type CareState = { food: number; water: number; sick: boolean; poisoned: boolean; stress: number };

export function HomeDashboard({
  username,
  credits,
  coins,
  gems,
  pets,
  selected,
  capacity,
  onOpen,
  onTopup,
  onSignOut,
  onRefresh,
}: {
  username: string;
  credits: number;
  coins: number;
  gems: number;
  pets: Pet[];
  selected: Pet | null;
  /** จำนวนสัตว์ที่ออกเดินในลานได้สูงสุด (ขยายจากร้านค้า) */
  capacity: number;
  onOpen: (tab: "play" | "chars" | "shop" | "breed" | "gift") => void;
  onTopup: () => void;
  onSignOut: () => void;
  onRefresh: () => void;
}) {
  const social = useFriends();
  const [players, setPlayers] = useState<PlayerRow[]>([]);
  const [showAllRanking, setShowAllRanking] = useState(false);
  const [friendFarm, setFriendFarm] = useState<{ name: string; pets: Pet[] | null } | null>(null);
  const openFriendFarm = async (userId: string, name: string) => {
    setFriendFarm({ name, pets: null });
    const { data } = await supabase.rpc("farm_field_public" as never, { owner: userId } as never);
    setFriendFarm({ name, pets: ((data as unknown as Pet[] | null) ?? []) });
  };
  const [hover, setHover] = useState<{ pet: Pet; x: number; y: number } | null>(null);
  const [armed, setArmed] = useState<"food" | "milk" | "med" | null>(null);
  const [pops, setPops] = useState<{ id: number; x: number; y: number; text: string }[]>([]);
  const hoverTimer = useRef<number | undefined>(undefined);
  const hoverRef = useRef<{ pet: Pet } | null>(null);
  hoverRef.current = hover;
  const careRef = useRef<(kind: "food" | "milk" | "med", pet: Pet) => void>(() => {});
  const [itemDrag, setItemDrag] = useState<{ kind: "food" | "milk" | "med"; x: number; y: number } | null>(null);
  const startItemDrag = (event: React.PointerEvent<HTMLElement>, kind: "food" | "milk" | "med") => {
    event.preventDefault();
    // ปล่อย pointer capture เพื่อให้สัตว์ 3D รับรู้ว่านิ้ว/เมาส์อยู่บนตัว
    try { (event.target as HTMLElement).releasePointerCapture(event.pointerId); } catch { /* noop */ }
    const ox = event.clientX, oy = event.clientY;
    let moved = false;
    const move = (e: PointerEvent) => {
      if (!moved && Math.hypot(e.clientX - ox, e.clientY - oy) < 6) return;
      moved = true;
      e.preventDefault();
      setItemDrag({ kind, x: e.clientX, y: e.clientY });
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
      setItemDrag(null);
      if (!moved) {
        setArmed((a) => (a === kind ? null : kind));
        return;
      }
      const target = hoverRef.current?.pet;
      if (target) careRef.current(kind, target);
      else flashRef.current?.("ลากไอเทมไปวางบนตัวสัตว์ในลานนะ");
    };
    window.addEventListener("pointermove", move, { passive: false });
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
  };
  const tapPet = (pet: Pet, point: { clientX: number; clientY: number }) => {
    if (armed) void care(armed, pet);
    else void claim(pet, point);
  };
  const [careState, setCareState] = useState<Record<string, CareState>>({});
  const [items, setItems] = useState({ food: 0, milk: 0, med: 0 });
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const doCare = useServerFn(careMyPet);
  const doClaim = useServerFn(claimPetCredits);
  /* เครดิตสะสมของแต่ละตัว: ยอด ณ เวลา pendingAt — ยอดปัจจุบัน = base + rate x วินาทีที่ผ่านไป x ตัวคูณสภาพ */
  const [pending, setPending] = useState<Record<string, { base: number; at: number }>>({});
  const [claimTick, setClaimTick] = useState(0);
  const decayedRef = useRef(false);
  const [caredAt, setCaredAt] = useState<Record<string, number>>({});
  const reloadPlayers = useRef<(() => void) | null>(null);
  const [fieldIds, setFieldIds] = useState<string[]>([]);
  const fieldReady = useRef(false);
  const [dragId, setDragId] = useState<string | null>(null);
  const storageKey = social.meId ? `pawpets-field-pets:${social.meId}` : null;

  /* สัตว์ตัวไหน "ปล่อยอยู่ในลาน" — จำไว้ในเครื่องผู้เล่น */
  useEffect(() => {
    if (!storageKey || fieldReady.current || pets.length === 0) return;
    fieldReady.current = true;
    let stored: string[] = [];
    try {
      const raw = window.localStorage.getItem(storageKey);
      if (raw) stored = (JSON.parse(raw) as string[]).filter((id) => pets.some((p) => p.id === id));
    } catch { stored = []; }
    setFieldIds(stored.length > 0 ? stored.slice(0, capacity) : pets.slice(0, capacity).map((p) => p.id));
  }, [storageKey, pets, capacity]);

  useEffect(() => {
    if (!storageKey || !fieldReady.current) return;
    try { window.localStorage.setItem(storageKey, JSON.stringify(fieldIds)); } catch { /* ไม่ต้องทำอะไร */ }
  }, [storageKey, fieldIds]);

  const fieldPets = useMemo(() => pets.filter((p) => fieldIds.includes(p.id)), [pets, fieldIds]);
  const storedPets = useMemo(() => pets.filter((p) => !fieldIds.includes(p.id)), [pets, fieldIds]);
  const flashRef = useRef<((text: string) => void) | null>(null);

  const releaseToField = useCallback(
    (id: string) => {
      setFieldIds((cur) => {
        if (cur.includes(id)) return cur;
        if (cur.length >= capacity) {
          flashRef.current?.(`ลานเต็มแล้ว (สูงสุด ${capacity} ตัว) — ขยายลานได้ที่ร้านค้า`);
          return cur;
        }
        return [...cur, id];
      });
    },
    [capacity],
  );
  const keepInPen = useCallback((id: string) => {
    setFieldIds((cur) => cur.filter((x) => x !== id));
  }, []);

  /* ลากด้วยนิ้ว/เมาส์ได้ทุกอุปกรณ์ (ไม่พึ่ง HTML5 drag ที่มือถือใช้ไม่ได้) */
  const penRef = useRef<HTMLElement | null>(null);
  const stageRef = useRef<HTMLElement | null>(null);
  const [dragPos, setDragPos] = useState<{ x: number; y: number } | null>(null);
  const dragInfo = useRef<{ id: string; from: "pen" | "field" } | null>(null);

  /** เริ่มลากจากจุดที่กด — ถ้าขยับน้อยกว่า 8px ถือว่าเป็นการ "แตะ" (เช่น เปิดหน้าดูแล) */
  const beginDrag = useCallback(
    (
      origin: { clientX: number; clientY: number },
      id: string,
      from: "pen" | "field",
      onTap?: () => void,
    ) => {
      dragInfo.current = { id, from };
      let moved = false;
      const ghost = () => setDragId(id);

      const inside = (el: HTMLElement | null, x: number, y: number) => {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        return x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;
      };
      const move = (e: PointerEvent) => {
        if (!moved) {
          if (Math.hypot(e.clientX - origin.clientX, e.clientY - origin.clientY) < 8) return;
          moved = true;
          ghost();
        }
        e.preventDefault();
        setDragPos({ x: e.clientX, y: e.clientY });
      };
      const up = (e: PointerEvent) => {
        window.removeEventListener("pointermove", move);
        window.removeEventListener("pointerup", up);
        window.removeEventListener("pointercancel", up);
        const info = dragInfo.current;
        dragInfo.current = null;
        setDragId(null);
        setDragPos(null);
        if (!info) return;
        if (!moved) {
          onTap?.();
          return;
        }
        if (inside(penRef.current, e.clientX, e.clientY)) keepInPen(info.id);
        else if (inside(stageRef.current, e.clientX, e.clientY)) releaseToField(info.id);
      };
      window.addEventListener("pointermove", move, { passive: false });
      window.addEventListener("pointerup", up);
      window.addEventListener("pointercancel", up);
    },
    [keepInPen, releaseToField],
  );

  const startDrag = useCallback(
    (event: React.PointerEvent, id: string, from: "pen" | "field") => {
      if ((event.target as HTMLElement).closest("button")) return;
      beginDrag({ clientX: event.clientX, clientY: event.clientY }, id, from);
    },
    [beginDrag],
  );


  const dragPet = useMemo(() => pets.find((p) => p.id === dragId) ?? null, [pets, dragId]);




  useEffect(() => {
    if (!social.meId) return;
    const meId = social.meId;
    let stopped = false;
    let channel: ReturnType<typeof supabase.channel> | null = null;
    let onlineIds = new Set<string>([meId]);
    let base: Array<Omit<PlayerRow, "online">> = [];

    const applyPresence = () => {
      setPlayers(base.map((player) => ({ ...player, online: onlineIds.has(player.id) })));
    };

    const load = async () => {
      const { data } = await supabase.rpc("public_profiles");
      if (stopped) return;
      base = ((data ?? []) as Array<{ id: string; username: string; credits: number }>).map((row) => ({
        id: row.id,
        username: row.username ?? "ผู้เล่น",
        credits: Number(row.credits ?? 0),
      }));
      applyPresence();
    };
    void load();
    reloadPlayers.current = () => void load();
    // อัปเดตอันดับเครดิตและสถานะออนไลน์ทุก 10 วินาที
    const timer = window.setInterval(() => {
      void load();
      void channel?.track({ userId: meId, at: Date.now() });
    }, 10_000);

    channel = supabase.channel("pawpets-home-presence", { config: { presence: { key: meId } } });
    channel
      .on("presence", { event: "sync" }, () => {
        const state = channel?.presenceState<{ userId: string }>() ?? {};
        onlineIds = new Set([meId]);
        for (const records of Object.values(state)) {
          for (const record of records) if (record.userId) onlineIds.add(record.userId);
        }
        applyPresence();
      })
      .subscribe((status) => {
        if (status === "SUBSCRIBED") void channel?.track({ userId: meId });
      });

    return () => {
      stopped = true;
      window.clearInterval(timer);
      if (channel) void supabase.removeChannel(channel);
    };
  }, [social.meId]);

  /* โหลดคลังไอเทมเลี้ยงสัตว์ของตัวเอง */
  useEffect(() => {
    if (!social.meId) return;
    void (async () => {
      const { data: prof } = await supabase
        .from("profiles")
        .select("food_items, milk_items, med_items")
        .eq("id", social.meId!)
        .maybeSingle();
      const p = prof as Record<string, number | null> | null;
      setItems({
        food: Number(p?.["food_items"] ?? 0),
        milk: Number(p?.["milk_items"] ?? 0),
        med: Number(p?.["med_items"] ?? 0),
      });
    })();
  }, [social.meId]);

  /* ค่าหิว/กระหายลดตามเวลาที่หายไป และเดินเล่นในลาน = คลายเครียด
     ถ้าอาหารหรือน้ำหมด สัตว์จะป่วย — ทำครั้งเดียวตอนเปิดหน้าหลัก */
  useEffect(() => {
    if (decayedRef.current || pets.length === 0) return;
    decayedRef.current = true;
    const now = Date.now();
    const next: Record<string, CareState> = {};
    const nextPending: Record<string, { base: number; at: number }> = {};
    void (async () => {
      for (const p of pets) {
        const at = p.stress_at ? new Date(p.stress_at).getTime() : now;
        const elapsed = Math.max(0, (now - at) / 1000);
        const food = Math.max(0, Number(p.food ?? 100) - elapsed * FOOD_DRAIN_PER_SEC);
        const water = Math.max(0, Number(p.water ?? 100) - elapsed * WATER_DRAIN_PER_SEC);
        const sick = p.sick === true || food <= 0 || water <= 0;
        const stress = clampStress(Number(p.stress ?? 100) + elapsed * STRESS_GAIN_PER_SEC);
        const state: CareState = { food, water, sick, poisoned: p.poisoned === true, stress };
        next[p.id] = state;
        // สะสมเครดิตจากเวลาที่หายไป — หิว/กระหายสร้างช้าลง ป่วยสร้างช้ามาก
        const mult = creditRateMultiplier(state);
        const saved = Number((p as { pending_credits?: number }).pending_credits ?? 0);
        const base = Math.round((saved + accrueCredits(Number(p.credit_rate ?? 0), elapsed, mult)) * 100) / 100;
        nextPending[p.id] = { base, at: now };
        await supabase
          .from("user_pets")
          .update({ food, water, sick, stress, stress_at: new Date(now).toISOString(), pending_credits: base } as never)
          .eq("id", p.id);
      }
      setCareState(next);
      setPending(nextPending);
    })();
  }, [pets]);

  const flash = useCallback((text: string) => {
    setNotice(text);
    window.setTimeout(() => setNotice(null), 4000);
  }, []);
  flashRef.current = flash;


  const care = useCallback(
    async (kind: "food" | "milk" | "med", carePet: Pet) => {
      const prevItems = items;
      const prev = careState[carePet.id] ?? {
        food: Number(carePet.food ?? 100),
        water: Number(carePet.water ?? 100),
        sick: carePet.sick === true,
        poisoned: carePet.poisoned === true,
        stress: Number(carePet.stress ?? 100),
      };
      if ((prevItems[kind] ?? 0) <= 0) {
        flash("ไม่มีไอเทมนี้แล้ว — ซื้อเพิ่มได้ที่ร้านค้า");
        return;
      }
      if (kind === "med" && !prev.sick && !prev.poisoned) {
        flash("ตัวนี้ไม่ได้ป่วย ยังไม่ต้องให้ยา");
        return;
      }
      // แสดงผลทันที แล้วค่อยยืนยันกับเซิร์ฟเวอร์
      const next =
        kind === "food"
          ? { ...prev, food: Math.min(100, prev.food + 25) }
          : kind === "milk"
            ? { ...prev, water: Math.min(100, prev.water + 25) }
            : { ...prev, sick: false, poisoned: false };
      setItems((cur) => ({ ...cur, [kind]: Math.max(0, (cur[kind] ?? 0) - 1) }));
      setCaredAt((cur) => ({ ...cur, [carePet.id]: Date.now() }));
      setCareState((cur) => ({ ...cur, [carePet.id]: next }));
      const animal = getAnimal(carePet.animal);
      flash(
        kind === "food"
          ? `🍎 ${animal.name} อิ่มขึ้นแล้ว (+25)`
          : kind === "milk"
            ? `🥛 ${animal.name} ดื่มนมจนหายกระหายแล้ว (+25)`
            : `💊 ${animal.name} หายป่วยแล้ว!`,
      );
      playCoin();
      try {
        const res = await doCare({ data: { petId: carePet.id, kind } });
        if (!res.ok) {
          setItems(prevItems);
          setCareState((cur) => ({ ...cur, [carePet.id]: prev }));
          flash(
            res.reason === "no_item"
              ? "ไม่มีไอเทมนี้แล้ว — ซื้อเพิ่มได้ที่ร้านค้า"
              : res.reason === "not_sick"
                ? "ตัวนี้ไม่ได้ป่วย ยังไม่ต้องให้ยา"
                : "ใช้ไอเทมไม่สำเร็จ ลองอีกครั้ง",
          );
          return;
        }
        setItems((cur) => ({ ...cur, [kind]: res.left }));
        setCareState((cur) => ({
          ...cur,
          [carePet.id]: { food: res.food, water: res.water, sick: res.sick, poisoned: res.poisoned, stress: cur[carePet.id]?.stress ?? 100 },
        }));
        onRefresh();
      } catch {
        setItems(prevItems);
        setCareState((cur) => ({ ...cur, [carePet.id]: prev }));
        flash("ใช้ไอเทมไม่สำเร็จ ลองอีกครั้ง");
      }
    },
    [items, careState, doCare, flash, onRefresh],
  );

  careRef.current = (kind, pet) => void care(kind, pet);

  /* ยอดเครดิตสะสมปัจจุบันของสัตว์ตัวหนึ่ง (คิดสดจากอัตรา x เวลา x สภาพ) */
  const pendingNow = useCallback(
    (pet: Pet) => {
      const rec = pending[pet.id];
      if (!rec) return 0;
      const st = careState[pet.id] ?? {
        food: Number(pet.food ?? 100),
        water: Number(pet.water ?? 100),
        sick: pet.sick === true,
        poisoned: pet.poisoned === true,
        stress: 100,
      };
      const elapsed = Math.max(0, (Date.now() - rec.at) / 1000);
      return rec.base + accrueCredits(Number(pet.credit_rate ?? 0), elapsed, creditRateMultiplier(st));
    },
    [pending, careState],
  );

  /* รับเครดิตสะสมจากสัตว์ที่กด */
  const claim = useCallback(async (carePet: Pet, point?: { clientX: number; clientY: number }) => {
    // แสดงผลทันที (ไม่รอเซิร์ฟเวอร์) แล้วค่อยยืนยันยอดจริงตามหลัง
    const local = pendingNow(carePet);
    const at = point ?? { clientX: window.innerWidth / 2, clientY: window.innerHeight / 2 };
    const popId = Date.now() + Math.random();
    const text = `+${local >= 100 ? formatCompact(local) : local.toFixed(1)}`;
    setPops((cur) => [...cur, { id: popId, x: at.clientX, y: at.clientY, text }]);
    window.setTimeout(() => setPops((cur) => cur.filter((p) => p.id !== popId)), 1000);
    if (local >= 0.05) playCoin();
    setPending((cur) => ({ ...cur, [carePet.id]: { base: 0, at: Date.now() } }));
    const meId = social.meId;
    if (meId) setPlayers((cur) => cur.map((p) => (p.id === meId ? { ...p, credits: p.credits + local } : p)));
    try {
      const res = await doClaim({ data: { petId: carePet.id } });
      if (!res.ok) {
        flash("รับเครดิตไม่สำเร็จ ลองอีกครั้ง");
        return;
      }
      if (meId) setPlayers((cur) => cur.map((p) => (p.id === meId ? { ...p, credits: res.credits } : p)));
      reloadPlayers.current?.();
      onRefresh();
    } catch {
      flash("รับเครดิตไม่สำเร็จ ลองอีกครั้ง");
    }
  }, [pendingNow, doClaim, flash, onRefresh, social.meId]);

  /* อัปเดตยอดสะสมและขนาดสัตว์ในลานทุกวินาที */
  useEffect(() => {
    if (fieldPets.length === 0) return;
    const timer = window.setInterval(() => setClaimTick((t) => t + 1), 1000);
    return () => window.clearInterval(timer);
  }, [fieldPets.length]);

  /* สภาพสัตว์ในลาน: ป่วย = เดินช้ามาก, หิว/กระหาย = เดินช้าลง พร้อมไอคอนบนหัว */
  const moods = useMemo(() => {
    const out: Record<string, PetMood> = {};
    for (const p of fieldPets) {
      const st = careState[p.id] ?? { food: Number(p.food ?? 100), water: Number(p.water ?? 100), sick: p.sick === true, poisoned: p.poisoned === true };
      const sick = st.sick || st.poisoned;
      const hungry = st.food < 30;
      const thirsty = st.water < 30;
      const accrued = pendingNow(p);
      out[p.id] = {
        speed: sick ? 0.3 : hungry || thirsty ? 0.6 : 1,
        badge: sick ? (st.poisoned ? "🤮" : "🤒") : hungry ? "🍎" : thirsty ? "🥛" : accrued >= 1 ? "💠" : undefined,
        caredAt: caredAt[p.id],
        scale: Math.min(5, 0.4 + Math.log10(1 + accrued) * 0.12),
      };
    }
    return out;
  }, [fieldPets, careState, caredAt, pendingNow, claimTick]);

  const ranking = useMemo(
    () => [...players].sort((a, b) => b.credits - a.credits).slice(0, showAllRanking ? 10 : 5),
    [players, showAllRanking],
  );
  const statusPlayers = useMemo(
    () => [...players].sort((a, b) => Number(b.online) - Number(a.online) || b.credits - a.credits),
    [players],
  );

  const carePet = hover?.pet ?? null;
  const careAnimal = carePet ? getAnimal(carePet.animal) : null;
  const careInfo = carePet ? (careState[carePet.id] ?? {
    food: Number(carePet.food ?? 100),
    water: Number(carePet.water ?? 100),
    sick: carePet.sick === true,
    poisoned: carePet.poisoned === true,
    stress: Number(carePet.stress ?? 100),
  }) : null;

  return (
    <div className="home-dashboard relative min-h-screen overflow-x-hidden bg-background text-foreground">
      <header className="home-dashboard-header sticky top-0 z-30 flex min-h-20 items-center justify-between gap-3 border-b px-4 py-3 md:px-6">
        <div className="flex min-w-0 items-center gap-3">
          <span className="text-4xl" aria-hidden="true">🐾</span>
          <div className="min-w-0">
            <h1 className="truncate font-display text-2xl font-bold sm:text-3xl">PAWPETS</h1>
            <p className="truncate text-xs text-muted-foreground sm:text-sm">
              สวัสดี {username} · {selected ? `กำลังใช้ ${getAnimal(selected.animal).emoji} ${getAnimal(selected.animal).name} ${stars(selected.stars)}` : "ยังไม่ได้เลือกสัตว์"}
            </p>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-1.5 sm:gap-2">
          <span className="home-dashboard-pill">💎 {formatCompact(gems)}</span>
          <button onClick={onTopup} className="home-dashboard-icon" aria-label="เติมเพชร" title="เติมเพชร">+</button>
          <span className="home-dashboard-pill hidden sm:inline-flex">🪙 {formatCompact(coins)}</span>
          <span className="home-dashboard-pill hidden md:inline-flex">💠 {formatCompact(credits)}</span>
          <button onClick={onSignOut} className="home-dashboard-icon" aria-label="ออกจากระบบ" title="ออกจากระบบ">↪</button>
        </div>
      </header>

      <main className="home-world-layout relative z-10 grid min-h-[calc(100vh-5rem)] grid-cols-1 gap-3 p-3 pb-24 sm:p-4 sm:pb-28 lg:block lg:h-[calc(100vh-5rem)] lg:min-h-0 lg:p-0">
        <aside className="home-overlay-rail order-2 grid min-h-0 gap-3 lg:absolute lg:inset-y-4 lg:left-4 lg:z-20 lg:w-[17rem] lg:grid-rows-2">
          <section
            ref={penRef as React.RefObject<HTMLElement>}
            className="home-dashboard-panel flex min-h-0 flex-col overflow-hidden"
            onDragOver={(event) => { event.preventDefault(); }}
            onDrop={(event) => {
              event.preventDefault();
              const id = event.dataTransfer.getData("text/plain");
              if (id) keepInPen(id);
              setDragId(null);
            }}
          >
            <div className="border-b p-3">
              <h2 className="font-display text-xl">🐾 คอกสัตว์ของฉัน</h2>
              <p className="text-xs text-muted-foreground">
                ลากสัตว์ไปกลางจอเพื่อปล่อยลงลาน · ลากกลับมาที่นี่เพื่อเก็บ ({fieldPets.length}/{capacity} ในลาน)
              </p>
            </div>
            <div className="grid grid-cols-3 gap-2 border-b p-2.5 text-center text-xs">
              <button type="button" onPointerDown={(e) => startItemDrag(e, "food")} style={{ touchAction: "none" }} className={`home-ranking-row px-2 py-1.5 ${armed === "food" ? "ring-2 ring-primary" : ""}`} title="ลากไปวางบนตัวสัตว์">🍎 อาหาร <strong>{items.food}</strong></button>
              <button type="button" onPointerDown={(e) => startItemDrag(e, "milk")} style={{ touchAction: "none" }} className={`home-ranking-row px-2 py-1.5 ${armed === "milk" ? "ring-2 ring-primary" : ""}`} title="ลากไปวางบนตัวสัตว์">🥛 นม <strong>{items.milk}</strong></button>
              <button type="button" onPointerDown={(e) => startItemDrag(e, "med")} style={{ touchAction: "none" }} className={`home-ranking-row px-2 py-1.5 ${armed === "med" ? "ring-2 ring-primary" : ""}`} title="ลากไปวางบนตัวสัตว์">💊 ยา <strong>{items.med}</strong></button>
            </div>
            <ul className="farm-scroll min-h-0 flex-1 space-y-1.5 overflow-y-auto p-2.5">
              {storedPets.map((pet) => {
                const animal = getAnimal(pet.animal);
                return (
                  <li
                    key={pet.id}
                    onPointerDown={(event) => startDrag(event, pet.id, "pen")}
                    style={{ touchAction: "none" }}
                    className={`home-player-row flex cursor-grab items-center gap-2 px-2.5 py-2 ${dragId === pet.id ? "opacity-40" : ""}`}
                  >
                    <span aria-hidden="true">{animal.emoji}</span>
                    <span className="min-w-0 flex-1 truncate text-sm">{animal.name} {stars(pet.stars)}</span>
                    <button onClick={() => releaseToField(pet.id)} className="home-dashboard-icon" aria-label={`ปล่อย ${animal.name} ลงลาน`} title="ปล่อยลงลาน">↗</button>
                  </li>
                );
              })}
              {storedPets.length === 0 && <li className="p-3 text-center text-sm text-muted-foreground">สัตว์ทุกตัวอยู่ในลานแล้ว</li>}
            </ul>
          </section>

          <section className="home-dashboard-panel flex min-h-0 flex-col overflow-hidden">
            <div className="border-b p-3">
              <h2 className="font-display text-xl">👥 เพื่อนของฉัน</h2>
              <p className="text-xs text-muted-foreground">{social.friends.length} คน</p>
            </div>
            <ul className="farm-scroll min-h-0 flex-1 space-y-2 overflow-y-auto p-2.5">
              {social.friends.map((friend) => {
                const online = players.find((player) => player.id === friend.userId)?.online ?? false;
                return (
                  <li key={friend.id}>
                    <div className="home-friend-button grid w-full grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-2 p-2.5 text-left">
                      <span className="home-cube-avatar" aria-hidden="true">🐱</span>
                      <span className="min-w-0"><strong className="block truncate font-display">{friend.username}</strong><small className="text-muted-foreground">{online ? "ออนไลน์" : "ออฟไลน์"}</small></span>
                      <button type="button" onClick={() => void openFriendFarm(friend.userId, friend.username)} className="home-farm-peek" title="ดูฟาร์ม" aria-label={`ดูฟาร์มของ ${friend.username}`}>🌱 ฟาร์ม</button>
                    </div>
                  </li>
                );
              })}
              {!social.loading && social.friends.length === 0 && <li className="p-4 text-center text-sm text-muted-foreground">ยังไม่มีเพื่อน</li>}
            </ul>
          </section>
        </aside>

        <section
          ref={stageRef as React.RefObject<HTMLElement>}
          className="home-center-stage relative order-1 flex min-h-[52vh] min-w-0 flex-col items-center justify-end overflow-hidden lg:absolute lg:inset-0 lg:min-h-0 lg:rounded-none"
          style={{ backgroundImage: `url(${homeWorldBg})` }}
        >
          <div className="home-stage-shade" aria-hidden="true" />
          <HomePetField3D
            pets={fieldPets}
            capacity={capacity}
            moods={moods}
            onSelectPet={(pet) => tapPet(pet, { clientX: window.innerWidth / 2, clientY: window.innerHeight / 2 })}
            onPetHover={(pet, point) => {
              window.clearTimeout(hoverTimer.current);
              if (pet && point) setHover({ pet, x: point.clientX, y: point.clientY });
              else setHover(null);
            }}
            onPetPointerDown={(pet, point) => {
              setHover({ pet, x: point.clientX, y: point.clientY });
              window.clearTimeout(hoverTimer.current);
              hoverTimer.current = window.setTimeout(() => setHover(null), 2500);
              beginDrag(point, pet.id, "field", () => tapPet(pet, point));
            }}
          />

          <div className="farm-scroll relative z-10 mb-2 flex w-full max-w-full gap-1.5 overflow-x-auto px-3 lg:mb-20 lg:max-w-[calc(100%-36rem)]">
            {fieldPets.map((pet) => {
              const animal = getAnimal(pet.animal);
              return (
                <div
                  key={pet.id}
                  onPointerDown={(event) => startDrag(event, pet.id, "field")}
                  style={{ touchAction: "none" }}
                  className={`home-dashboard-pill shrink-0 cursor-grab ${dragId === pet.id ? "opacity-40" : ""}`}
                  title="ลากไปคอกสัตว์เพื่อเก็บ"
                >
                  <span>{animal.emoji}</span>
                  <button onClick={() => keepInPen(pet.id)} className="ml-1" aria-label={`เก็บ ${animal.name} เข้าคอก`}>✕</button>
                </div>
              );
            })}
          </div>
          <p className="pointer-events-none relative z-10 mb-4 rounded-full bg-background/60 px-4 py-1.5 text-xs text-muted-foreground backdrop-blur-sm sm:text-sm lg:absolute lg:bottom-3 lg:mb-0">
            แตะสัตว์เพื่อดูแล · ลากสัตว์จากคอกมาปล่อยในลานได้
          </p>
        </section>

        <aside className="home-overlay-rail order-3 grid min-h-0 gap-3 lg:absolute lg:inset-y-4 lg:right-4 lg:z-20 lg:w-[17rem] lg:grid-rows-[auto_minmax(12rem,1fr)]">
          <section className="home-dashboard-panel flex min-h-0 flex-col overflow-hidden">
            <div className="border-b p-3">
              <h2 className="font-display text-xl">🏆 อันดับเครดิต</h2>
              <p className="text-xs text-muted-foreground">ผู้เล่นที่มีเครดิตสูงสุด</p>
            </div>
            <ol className="farm-scroll min-h-0 space-y-1.5 overflow-y-auto p-2.5">
              {ranking.map((player, index) => (
                <li key={player.id} className="home-ranking-row grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-2 px-2.5 py-2">
                  <span className="font-display text-lg">{index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : `${index + 1}.`}</span>
                  <span className="truncate font-display">{player.username}</span>
                  <span className="text-xs text-primary">💠 {formatCompact(player.credits)}</span>
                </li>
              ))}
              {ranking.length === 0 && <li className="p-3 text-sm text-muted-foreground">กำลังโหลดอันดับ...</li>}
            </ol>
            {players.length > 5 && (
              <button onClick={() => setShowAllRanking((value) => !value)} className="home-more-button m-2.5 mt-0">
                {showAllRanking ? "แสดง 5 อันดับ" : "ดูเพิ่มเติม"}
              </button>
            )}
          </section>

          <section className="home-dashboard-panel flex min-h-0 flex-col overflow-hidden">
            <div className="border-b p-3">
              <h2 className="font-display text-lg">🟢 ผู้เล่นออนไลน์</h2>
              <p className="text-xs text-muted-foreground">เลื่อนลงเพื่อดูผู้เล่นออฟไลน์</p>
            </div>
            <ul className="farm-scroll min-h-0 flex-1 space-y-1.5 overflow-y-auto p-2.5">
              {statusPlayers.map((player) => (
                <li key={player.id} className="home-player-row flex items-center gap-2 px-2.5 py-2">
                  <span className={`home-status-dot ${player.online ? "is-online" : ""}`} aria-label={player.online ? "ออนไลน์" : "ออฟไลน์"} />
                  <span className="min-w-0 flex-1 truncate text-sm">{player.username}{player.id === social.meId ? " (คุณ)" : ""}</span>
                  <small>{player.online ? "ออนไลน์" : "ออฟไลน์"}</small>
                  {player.id !== social.meId && <button type="button" onClick={() => void openFriendFarm(player.id, player.username)} className="home-farm-peek" title="ดูฟาร์ม" aria-label={`ดูฟาร์มของ ${player.username}`}>🌱 ฟาร์ม</button>}
                </li>
              ))}
            </ul>
          </section>
        </aside>

      </main>

      {dragPos && dragPet && (
        <div
          className="pointer-events-none fixed z-[60] -translate-x-1/2 -translate-y-1/2 rounded-full bg-background/90 px-3 py-1.5 text-lg shadow-lg backdrop-blur-md"
          style={{ left: dragPos.x, top: dragPos.y }}
        >
          {getAnimal(dragPet.animal).emoji}
        </div>
      )}

      {notice && (
        <div className="fixed inset-x-0 top-24 z-50 mx-auto w-fit max-w-[90vw] rounded-full bg-background/90 px-5 py-2 text-sm shadow-lg backdrop-blur-md">
          {notice}
        </div>
      )}

      {armed && (
        <div className="fixed inset-x-0 top-36 z-50 mx-auto w-fit rounded-full bg-primary px-4 py-1.5 text-sm text-primary-foreground shadow-lg">
          {armed === "food" ? "🍎" : armed === "milk" ? "🥛" : "💊"} แตะสัตว์เพื่อใช้ไอเทม ·{" "}
          <button className="underline" onClick={() => setArmed(null)}>ยกเลิก</button>
        </div>
      )}

      {hover && carePet && careAnimal && careInfo && (
        <div
          className="home-dashboard-panel pointer-events-none fixed z-50 w-52 p-2.5 text-xs"
          style={{ left: Math.min(hover.x + 14, window.innerWidth - 220), top: Math.max(8, hover.y - 130) }}
        >
          <p className="font-display text-sm font-bold">{careAnimal.emoji} {careAnimal.name} {stars(carePet.stars)}</p>
          {(careInfo.sick || careInfo.poisoned) && <p className="text-destructive">{careInfo.poisoned ? "🤮 ติดพิษ" : "🤒 ป่วย"}</p>}
          <div className="mt-1 flex justify-between"><span>🍎 ความอิ่ม</span><span>{Math.round(careInfo.food)}%</span></div>
          <div className="h-1.5 overflow-hidden rounded-full bg-secondary"><div className="h-full bg-primary" style={{ width: `${careInfo.food}%` }} /></div>
          <div className="mt-1 flex justify-between"><span>🥛 น้ำ</span><span>{Math.round(careInfo.water)}%</span></div>
          <div className="h-1.5 overflow-hidden rounded-full bg-secondary"><div className="h-full bg-primary" style={{ width: `${careInfo.water}%` }} /></div>
          <p className="mt-1.5">
            💠 {formatCompact(Number(carePet.credit_rate ?? 0) * creditRateMultiplier(careInfo))}/วินาที
            {(careInfo.sick || careInfo.poisoned) ? " (25%)" : (careInfo.food < 30 || careInfo.water < 30) ? " (50%)" : ""}
          </p>
          <p className="text-muted-foreground">สะสม {formatCompact(pendingNow(carePet))} · แตะเพื่อรับ</p>
        </div>
      )}

      {itemDrag && (
        <div className="pointer-events-none fixed z-50 -translate-x-1/2 -translate-y-1/2 text-4xl drop-shadow-lg" style={{ left: itemDrag.x, top: itemDrag.y }}>
          {itemDrag.kind === "food" ? "🍎" : itemDrag.kind === "milk" ? "🥛" : "💊"}
        </div>
      )}

      {friendFarm && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-background/60 p-3 backdrop-blur-sm" onClick={() => setFriendFarm(null)}>
          <div className="home-dashboard-panel flex h-[80vh] w-full max-w-4xl flex-col overflow-hidden p-0" onClick={(e) => e.stopPropagation()} role="dialog" aria-label={`ฟาร์มของ ${friendFarm.name}`}>
            <div className="flex items-center justify-between gap-2 px-4 py-3">
              <h3 className="font-display text-xl">🌱 ฟาร์มของ {friendFarm.name}</h3>
              <button onClick={() => setFriendFarm(null)} className="home-dashboard-icon" aria-label="ปิด">✕</button>
            </div>
            <div className="home-center-stage relative min-h-0 flex-1" style={{ backgroundImage: `url(${homeWorldBg})` }}>
              <div className="home-stage-shade" aria-hidden="true" />
              {friendFarm.pets === null ? (
                <p className="absolute inset-0 flex items-center justify-center text-sm">กำลังโหลดฟาร์ม...</p>
              ) : friendFarm.pets.length === 0 ? (
                <p className="absolute inset-0 flex items-center justify-center text-sm">ยังไม่มีสัตว์ในฟาร์ม</p>
              ) : (
                <HomePetField3D
                  pets={friendFarm.pets}
                  capacity={friendFarm.pets.length}
                  moods={Object.fromEntries(friendFarm.pets.map((p) => [p.id, { speed: p.sick || p.poisoned ? 0.3 : 1, badge: p.sick || p.poisoned ? (p.poisoned ? "🤮" : "🤒") : undefined }]))}
                />
              )}
            </div>
          </div>
        </div>
      )}

      {pops.map((p) => (
        <div key={p.id} className="credit-pop pointer-events-none fixed z-50 font-display text-2xl font-bold text-primary" style={{ left: p.x, top: p.y }}>
          {p.text} 💠
        </div>
      ))}

      <nav className="home-quick-bar fixed inset-x-0 bottom-0 z-30 mx-auto grid w-full max-w-xl grid-cols-4 gap-2 p-2">
        <button onClick={() => onOpen("chars")} className="home-quick-button"><span>🐱</span><small>สัตว์เลี้ยง</small></button>
        <button onClick={() => onOpen("gift")} className="home-quick-button"><span>🎒</span><small>ส่งสัตว์</small></button>
        <button onClick={() => onOpen("shop")} className="home-quick-button"><span>🛍️</span><small>ร้านค้า</small></button>
        <button onClick={() => onOpen("play")} className="home-quick-button"><span>🏀</span><small>เล่นเกม</small></button>
      </nav>
    </div>
  );
}

let audioCtx: AudioContext | null = null;
function playCoin() {
  try {
    audioCtx ??= new AudioContext();
    const ctx = audioCtx;
    [988, 1319].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const t = ctx.currentTime + i * 0.08;
      osc.type = "square";
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.08, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
      osc.connect(gain).connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.26);
    });
  } catch {
    /* ไม่มีเสียงก็ไม่เป็นไร */
  }
}
