import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { FriendsState } from "@/hooks/useFriends";

type Player = { userId: string; username: string; online: boolean };

export function OnlinePanel({
  social,
  leaderboardOpen,
}: {
  social: FriendsState;
  leaderboardOpen: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [players, setPlayers] = useState<Player[]>([]);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    const meId = social.meId;
    if (!meId) return;
    let channel: ReturnType<typeof supabase.channel> | null = null;
    let cancelled = false;
    let onlineSet = new Set<string>();

    void (async () => {
      const [{ data: profs }, { data: farmRows }] = await Promise.all([
        supabase.rpc("public_profiles"),
        supabase.rpc("active_users"),
      ]);
      if (cancelled) return;
      const hasData = new Set<string>(((farmRows ?? []) as any[]).map((f: any) => f.user_id as string));
      const all: Player[] = ((profs ?? []) as any[])
        .map((r: any) => ({
          userId: r.id as string,
          username: (r.username as string) ?? "ผู้เล่น",
          online: onlineSet.has(r.id),
        }))
        .sort((a, b) => a.username.localeCompare(b.username))
        // แสดงผู้เล่นออนไลน์ทุกคน + ผู้เล่นออฟไลน์เฉพาะที่มีข้อมูลจริง (มีสัตว์ในฟาร์ม)
        .filter((p) => p.online || p.userId === meId || hasData.has(p.userId));

      const { data: prof } = await supabase
        .from("profiles")
        .select("username")
        .eq("id", meId)
        .maybeSingle();
      if (cancelled) return;
      const username = (prof?.username as string | undefined) ?? "ผู้เล่น";


      const apply = () => {
        setPlayers(
          all
            .map((p) => ({ ...p, online: onlineSet.has(p.userId) || p.userId === meId }))
            .sort((a, b) => {
              if (a.online !== b.online) return a.online ? -1 : 1;
              return a.username.localeCompare(b.username);
            }),
        );
      };
      apply();

      channel = supabase.channel("online-players", { config: { presence: { key: meId } } });
      channel
        .on("presence", { event: "sync" }, () => {
          const state = channel!.presenceState<{ userId: string; username: string }>();
          const next = new Set<string>();
          for (const pres of Object.values(state)) {
            for (const p of pres) if (p.userId) next.add(p.userId);
          }
          next.add(meId);
          onlineSet = next;
          apply();
        })
        .subscribe((status) => {
          if (status === "SUBSCRIBED") void channel!.track({ userId: meId, username });
        });
    })();
    return () => {
      cancelled = true;
      if (channel) supabase.removeChannel(channel);
    };
  }, [social.meId]);

  async function add(username: string) {
    setMsg(await social.addFriend(username));
  }

  const onlineCount = players.filter((p) => p.online).length;

  return (
    <>
      <button
        onClick={() => setOpen((v) => !v)}
        className="panel fixed left-0 z-30 -translate-y-1/2 px-2 py-4 font-display text-lg"
        style={{ left: open || leaderboardOpen ? "18rem" : 0, top: "calc(50% + 4.5rem)" }}
        aria-label="ผู้เล่นออนไลน์"
      >
        {open ? "‹" : "🟢"}
        {!open && onlineCount > 0 && (
          <span className="ml-1 rounded-full bg-primary px-1.5 text-sm text-primary-foreground">{onlineCount}</span>
        )}
      </button>

      <aside
        className="fixed top-0 left-0 z-20 h-full w-72 overflow-y-auto border-r border-border bg-card/95 p-3 transition-transform"
        style={{ transform: open ? "none" : "translateX(-100%)" }}
      >
        <h2 className="font-display text-xl">🟢 ออนไลน์ตอนนี้ ({onlineCount})</h2>
        {msg && <p className="mt-2 text-xs text-primary">{msg}</p>}
        {players.length === 0 ? (
          <p className="mt-4 text-sm text-muted-foreground">กำลังโหลดรายชื่อผู้เล่น…</p>
        ) : (
          <ul className="mt-3 space-y-2">
            {players.map((p) => (
              <li
                key={p.userId}
                className={
                  "rounded-lg px-3 py-2 transition-opacity " +
                  (p.online ? "bg-secondary opacity-100" : "bg-secondary/40 opacity-60")
                }
              >
                <div className="flex items-center gap-2">
                  <span
                    className={
                      "h-2.5 w-2.5 shrink-0 rounded-full " +
                      (p.online ? "bg-emerald-400" : "bg-gray-400")
                    }
                  />
                  <span
                    className={
                      "min-w-0 flex-1 truncate font-display text-lg " +
                      (p.online ? "" : "text-gray-400")
                    }
                  >
                    {p.username}
                    {p.userId === social.meId && <span className="text-xs text-muted-foreground"> (คุณ)</span>}
                  </span>
                </div>
                {p.userId !== social.meId && (
                  <div className="mt-2 flex gap-2">
                    <button
                      onClick={() => void add(p.username)}
                      aria-label={`เพิ่มเพื่อน ${p.username}`}
                      className="btn-base btn-ghost px-3 py-1 text-base"
                    >
                      +
                    </button>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </aside>
    </>
  );
}
