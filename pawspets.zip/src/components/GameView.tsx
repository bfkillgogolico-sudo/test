import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { RealtimeChannel } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

import {
  GameEngine,
  SKILL_COST,
  TICK_MS,
  checksumOf,
  placementOf,
  type GameState,
  type PlayerInput,
  type PlayerMeta,
} from "@/lib/game/engine";
import { getCharacter } from "@/lib/game/characters";
import { initSfx, isMuted, sfx, toggleMute } from "@/lib/game/sfx";
import { Arena3D } from "@/components/Arena3D";
import { QUALITY_LABELS, useQuality, type Quality } from "@/lib/game/graphics";
import { PLACEMENT_REWARDS } from "@/lib/game.functions";

/** commands are scheduled this many ticks ahead so every device has them in time */
const DELAY_TICKS = 6;
/** each broadcast covers this many ticks, keeping the message rate at ~20/s */
const INPUT_SPAN = 3;
/** how long a device waits for a missing command before carrying the old one forward */
const MAX_WAIT_MS = 250;
/** drift check + repair interval, in ticks */
const SYNC_TICKS = 60;

type Props = {
  selfId: string;
  metas: PlayerMeta[];
  /** shared wall-clock start time (ms) so every device counts the same ticks */
  startAt: number;
  /** shared match seed so every device rolls the same random numbers */
  seed: number;
  channel: RealtimeChannel | null;
  onExit: () => void;
  /** Called once with the player's final standing (1st, 2nd, 3rd, ...) when the match ends. */
  onFinish: (placement: number) => void;
};

type Joy = { active: boolean; x: number; y: number; id: number | null };

const emptyInput = (): PlayerInput => ({ ax: 0, ay: 0, aim: 0, shoot: false, skill: false });

export function GameView({ selfId, metas, startAt, seed, channel, onExit, onFinish }: Props) {
  const engineRef = useRef<GameEngine | null>(null);
  const netRef = useRef<RealtimeChannel | null>(null);

  const stateRef = useRef<GameState | null>(null);
  const keysRef = useRef<Record<string, boolean>>({});
  /** commands per tick per player */
  const bufRef = useRef<Map<number, Map<string, PlayerInput>>>(new Map());
  /** most recent known command per player, reused when a message is late */
  const lastInputRef = useRef<Record<string, PlayerInput>>({});
  const sentUpToRef = useRef(-1);
  const nextSyncRef = useRef(SYNC_TICKS);
  const playerIds = useMemo(() => metas.map((m) => m.id).sort(), [metas]);
  /** lowest id present acts only as the drift-repair reference, not as a host */
  const isSyncRef = playerIds[0] === selfId;

  const aimRef = useRef<number | null>(null);
  const moveJoy = useRef<Joy>({ active: false, x: 0, y: 0, id: null });
  const aimJoy = useRef<Joy>({ active: false, x: 0, y: 0, id: null });
  const [isTouch, setIsTouch] = useState(false);
  const [quality, setQuality] = useQuality();
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [hud, setHud] = useState({
    alive: metas.length,
    charges: 0,
    time: 0,
    rage: 0,
    countdown: 3,
  });
  const [result, setResult] = useState<null | {
    won: boolean;
    winner: string;
    placement: number;
    reward: number;
  }>(null);
  const [spectating, setSpectating] = useState(false);

  const wonRef = useRef(false);
  const seenEvents = useRef<Set<string>>(new Set());
  const prevCountdown = useRef(99);
  const [audioOff, setAudioOff] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [clawFlash, setClawFlash] = useState(false);
  const clawHit = useRef(false);

  useEffect(() => {
    setMounted(true);
    initSfx();
    setAudioOff(isMuted());
  }, []);

  useEffect(() => {
    setIsTouch(
      typeof window !== "undefined" && ("ontouchstart" in window || navigator.maxTouchPoints > 0),
    );
  }, []);

  // ---- lockstep networking ----
  // Nobody owns the match: every device runs the same fixed-step simulation and
  // Realtime only relays each player's own commands (plus a periodic drift check).
  const putInput = useCallback((id: string, tick: number, input: PlayerInput) => {
    for (let i = 0; i < INPUT_SPAN; i++) {
      const t = tick + i;
      let slot = bufRef.current.get(t);
      if (!slot) {
        slot = new Map();
        bufRef.current.set(t, slot);
      }
      // one-shot actions only land on the first tick they were meant for
      slot.set(id, i === 0 ? input : { ...input, shoot: false, skill: false });
    }
  }, []);

  const pendingShoot = useRef(false);
  const pendingSkill = useRef(false);

  useEffect(() => {
    engineRef.current = new GameEngine(metas, seed);
    stateRef.current = engineRef.current.state;
    bufRef.current = new Map();
    lastInputRef.current = {};
    sentUpToRef.current = -1;
    nextSyncRef.current = SYNC_TICKS;

    const room = channel?.topic?.replace(/^realtime:/, "");
    if (!room) return;

    const net = supabase.channel(`${room}-game`, { config: { broadcast: { self: false } } });
    net.on("broadcast", { event: "cmd" }, ({ payload }) => {
      const p = payload as { id?: string; tick?: number; input?: PlayerInput };
      if (!p.id || typeof p.tick !== "number" || !p.input) return;
      putInput(p.id, p.tick, { ...emptyInput(), ...p.input });
    });
    net.on("broadcast", { event: "sync" }, ({ payload }) => {
      const p = payload as { state?: GameState };
      const engine = engineRef.current;
      if (!p.state || !engine) return;
      // adopt the reference simulation only when our own drifted apart
      if (p.state.tick + 1 < engine.state.tick) return;
      if (checksumOf(p.state) === checksumOf(engine.state) && p.state.tick === engine.state.tick)
        return;
      engine.loadState(p.state);
      stateRef.current = engine.state;
    });
    void net.subscribe();
    netRef.current = net;

    return () => {
      netRef.current = null;
      supabase.removeChannel(net);
    };
  }, [channel, metas, seed, putInput]);

  // ---- keyboard ----
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      keysRef.current[e.key.toLowerCase()] = true;
      if (e.code === "Space") {
        e.preventDefault();
        pendingSkill.current = true;
      }
    };
    const up = (e: KeyboardEvent) => {
      keysRef.current[e.key.toLowerCase()] = false;
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, []);

  // ---- main loop ----
  useEffect(() => {
    let raf = 0;
    /** wall-clock time at which each tick became overdue */
    const dueAt = (t: number) => startAt + (t + 1) * TICK_MS;

    const tick = () => {
      const engine = engineRef.current;
      if (!engine) return;
      const nowMs = Date.now();
      const targetTick = Math.floor((nowMs - startAt) / TICK_MS);

      // gather and publish our own commands, scheduled a few ticks ahead
      const k = keysRef.current;
      let ax = (k["d"] || k["arrowright"] ? 1 : 0) - (k["a"] || k["arrowleft"] ? 1 : 0);
      let ay = (k["s"] || k["arrowdown"] ? 1 : 0) - (k["w"] || k["arrowup"] ? 1 : 0);
      if (moveJoy.current.active) {
        ax = moveJoy.current.x;
        ay = moveJoy.current.y;
      }
      const planTick = Math.max(0, targetTick + DELAY_TICKS);
      if (planTick > sentUpToRef.current) {
        sentUpToRef.current = planTick + INPUT_SPAN - 1;
        const input: PlayerInput = {
          ax,
          ay,
          aim: aimRef.current ?? 0,
          shoot: pendingShoot.current,
          skill: pendingSkill.current,
        };
        pendingShoot.current = false;
        pendingSkill.current = false;
        putInput(selfId, planTick, input);
        if (netRef.current) {
          void netRef.current.send({
            type: "broadcast",
            event: "cmd",
            payload: { id: selfId, tick: planTick, input },
          });
        }
      }

      // step the simulation only with commands everyone agreed on (or gave up waiting for)
      let steps = 0;
      while (engine.state.tick < targetTick && steps < 12) {
        const t = engine.state.tick;
        const slot = bufRef.current.get(t);
        const alive = engine.state.players.filter((p) => p.alive).map((p) => p.id);
        const missing = alive.some((id) => !slot?.has(id));
        if (missing && nowMs - dueAt(t) < MAX_WAIT_MS) break;
        for (const p of engine.state.players) {
          const cmd = slot?.get(p.id) ?? {
            ...(lastInputRef.current[p.id] ?? emptyInput()),
            shoot: false,
            skill: false,
          };
          lastInputRef.current[p.id] = cmd;
          engine.inputs[p.id] = { ...cmd };
        }
        engine.stepTick();
        bufRef.current.delete(t - 120);
        steps += 1;
      }
      stateRef.current = engine.state;

      // drift repair: the lowest id publishes a reference state once a second
      if (isSyncRef && netRef.current && engine.state.tick >= nextSyncRef.current) {
        nextSyncRef.current = engine.state.tick + SYNC_TICKS;
        void netRef.current.send({
          type: "broadcast",
          event: "sync",
          payload: { state: engine.state },
        });
      }

      const s = stateRef.current;

      if (s) {
        const me = s.players.find((p) => p.id === selfId);
        setHud({
          alive: s.players.filter((p) => p.alive).length,
          charges: me?.charges ?? 0,
          time: s.t,
          rage: s.wolf.rageTier,
          countdown: Math.max(0, Math.ceil(s.countdown)),
        });

        // sound for new game events
        for (const ev of s.events) {
          const key = `${ev.kind}:${ev.t.toFixed(3)}:${ev.text}`;
          if (seenEvents.current.has(key)) continue;
          seenEvents.current.add(key);
          if (seenEvents.current.size > 64) seenEvents.current = new Set([key]);
          if (ev.t < 0.05) continue;
          if (ev.kind === "pass") sfx.catch();
          else if (ev.kind === "bounce") sfx.bounce();
          else if (ev.kind === "skill") sfx.skill();
          else if (ev.kind === "death") sfx.death();
          else if (ev.kind === "rage") sfx.rage();
        }

        // countdown beeps
        const cd = Math.max(0, Math.ceil(s.countdown));
        if (cd !== prevCountdown.current) {
          if (s.phase === "countdown" && cd > 0) sfx.countdown();
          else if (cd === 0 && prevCountdown.current > 0) sfx.start();
          prevCountdown.current = cd;
        }
        if (me && !me.alive && !clawHit.current) {
          clawHit.current = true;
          setClawFlash(true);
          window.setTimeout(() => setClawFlash(false), 900);
        }
        if (me && !me.alive && !spectating && !result) {
          setResult({ won: false, winner: "", placement: 0, reward: 0 });
        }
        if (s.phase === "over" && !wonRef.current) {
          wonRef.current = true;
          const winner = s.players.find((p) => p.id === s.winner);
          const won = s.winner === selfId;
          const placement = placementOf(s, selfId);
          // solo practice has no opponents, so it pays nothing
          const reward = s.players.length > 1 ? (PLACEMENT_REWARDS[placement - 1] ?? 0) : 0;
          if (reward > 0) onFinish(placement);
          if (won) sfx.win();
          else sfx.lose();
          setResult({ won, winner: winner?.name ?? "-", placement, reward });
        }
      }
    };

    const loop = () => {
      tick();
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    // keeps this device's simulation on the shared clock while the tab is hidden
    // (requestAnimationFrame is paused there)
    const keepAlive = window.setInterval(() => {
      if (document.hidden) tick();
    }, 50);

    return () => {
      cancelAnimationFrame(raf);
      window.clearInterval(keepAlive);
    };
  }, [selfId, spectating, result, onFinish, startAt, isSyncRef, putInput]);

  const joyHandlers = (ref: React.MutableRefObject<Joy>, onRelease?: () => void) => ({
    onPointerDown: (e: React.PointerEvent) => {
      (e.target as HTMLElement).setPointerCapture(e.pointerId);
      ref.current = { active: true, x: 0, y: 0, id: e.pointerId };
    },
    onPointerMove: (e: React.PointerEvent) => {
      if (!ref.current.active) return;
      const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const dx = e.clientX - cx;
      const dy = e.clientY - cy;
      const max = rect.width / 2;
      const len = Math.hypot(dx, dy) || 1;
      const cl = Math.min(1, len / max);
      ref.current.x = (dx / len) * cl;
      ref.current.y = (dy / len) * cl;
      if (ref === aimJoy && cl > 0.15) aimRef.current = Math.atan2(dy, dx);
    },
    onPointerUp: () => {
      ref.current = { active: false, x: 0, y: 0, id: null };
      onRelease?.();
    },
    onPointerCancel: () => {
      ref.current = { active: false, x: 0, y: 0, id: null };
    },
  });

  const doShoot = () => {
    if (stateRef.current?.ball.holder === selfId) sfx.shoot();
    pendingShoot.current = true;
  };

  const canSkill = hud.charges >= SKILL_COST;
  const meMeta = metas.find((m) => m.id === selfId);
  const skillName = meMeta ? getCharacter(meMeta.charId).skillName : "Skill";

  return (
    <div className="fixed inset-0 overflow-hidden bg-background">
      <div className="absolute inset-0">
        {mounted && (
          <Arena3D
            stateRef={stateRef}
            players={metas.map((m) => ({ id: m.id, charId: m.charId, name: m.name }))}
            selfId={selfId}
            onAim={(a) => {
              aimRef.current = a;
            }}
            onShoot={doShoot}
            shootOnClick={!isTouch}
            quality={quality}
          />
        )}
      </div>

      {/* top HUD */}
      <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between p-3 sm:p-4">
        <div className="flex items-start gap-2">
          <button
            onClick={() => setSettingsOpen((v) => !v)}
            aria-label="ตั้งค่า"
            className="panel pointer-events-auto px-3 py-2 text-base"
          >
            ⚙️
          </button>
          <div className="panel px-3 py-2 text-sm">
            <div className="font-display text-xl leading-none">👥 {hud.alive} รอด</div>
            <div className="text-muted-foreground">⏱ {Math.floor(hud.time)}s</div>
          </div>
        </div>
        <div className="pointer-events-auto space-y-1 text-right text-xs sm:text-sm">
          <button
            onClick={() => setAudioOff(toggleMute())}
            aria-label={audioOff ? "เปิดเสียง" : "ปิดเสียง"}
            className="panel px-3 py-1 text-base"
          >
            {audioOff ? "🔇" : "🔊"}
          </button>
        </div>
      </div>

      {settingsOpen && (
        <div className="panel absolute top-16 left-3 z-30 w-56 p-3 sm:left-4">
          <div className="font-display text-lg leading-none">⚙️ ตั้งค่าภาพ</div>
          <div className="mt-2 space-y-1">
            {(Object.keys(QUALITY_LABELS) as Quality[]).map((q) => (
              <button
                key={q}
                onClick={() => setQuality(q)}
                className={`w-full rounded-md px-3 py-2 text-left text-sm ${
                  quality === q ? "btn-primary" : "bg-secondary text-foreground"
                }`}
              >
                {QUALITY_LABELS[q]}
              </button>
            ))}
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            ถ้าเกมกระตุก เลือก “ต่ำ” จะลื่นขึ้นมาก
          </p>
          <button
            onClick={() => setSettingsOpen(false)}
            className="btn-base btn-ghost mt-2 w-full text-sm"
          >
            ปิด
          </button>
        </div>
      )}

      {hud.countdown > 0 && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="font-display text-[18vw] text-primary drop-shadow-[0_0_40px_rgba(255,180,60,0.6)]">
            {hud.countdown}
          </div>
        </div>
      )}

      {/* charges + skill */}
      <div className="absolute right-4 bottom-6 flex flex-col items-end gap-3">
        <div className="panel flex items-center gap-1 px-3 py-2">
          {Array.from({ length: SKILL_COST }).map((_, i) => (
            <span
              key={i}
              className={`h-4 w-3 rounded-sm ${i < Math.min(hud.charges, SKILL_COST) ? "bg-primary" : "bg-muted"}`}
            />
          ))}
          <span className="ml-2 font-display text-lg">
            {hud.charges}/{SKILL_COST}
          </span>
        </div>
        <button
          onPointerDown={() => {
            pendingSkill.current = true;
          }}

          className={`h-24 w-24 rounded-full font-display text-base leading-tight ${
            canSkill ? "btn-primary shadow-glow" : "bg-muted text-muted-foreground"
          }`}
        >
          {skillName}
          <div className="text-[10px] tracking-normal opacity-80">SPACE</div>
        </button>
        {isTouch && (
          <div
            {...joyHandlers(aimJoy, doShoot)}
            className="relative h-28 w-28 touch-none rounded-full border-2 border-primary/50 bg-card/70"
          >
            <span className="absolute inset-0 flex items-center justify-center font-display text-sm text-primary">
              ลาก
              <br />
              เพื่อยิง
            </span>
          </div>
        )}
      </div>

      {/* move joystick (mobile) */}
      {isTouch && (
        <div
          {...joyHandlers(moveJoy)}
          className="absolute bottom-6 left-4 h-32 w-32 touch-none rounded-full border-2 border-border bg-card/70"
        >
          <span className="absolute inset-0 flex items-center justify-center text-2xl opacity-60">
            🕹️
          </span>
        </div>
      )}

      {!isTouch && (
        <div className="panel pointer-events-none absolute bottom-4 left-4 px-3 py-2 text-xs text-muted-foreground">
          WASD เดิน · เมาส์เล็ง · คลิกยิง · SPACE ใช้สกิล
        </div>
      )}

      {result && (
        <div className="absolute inset-0 flex items-center justify-center bg-background/80 px-4">
          <div className="panel w-full max-w-sm p-6 text-center">
            {result.winner ? (
              <>
                <div className="text-5xl">{result.won ? "👑" : "🏁"}</div>
                <h2 className="mt-2 text-3xl">{result.won ? "คุณชนะ!" : `${result.winner} ชนะ`}</h2>
                {result.reward > 0 ? (
                  <p className="mt-1 text-primary">
                    อันดับ {result.placement} · ได้รับ {result.reward} coin 🪙
                  </p>
                ) : (
                  <p className="mt-1 text-sm text-muted-foreground">อันดับ {result.placement}</p>
                )}
                <button onClick={onExit} className="btn-base btn-primary mt-5 w-full">
                  กลับเมนูหลัก
                </button>
              </>
            ) : (
              <>
                <div className="text-5xl">💀</div>
                <h2 className="mt-2 text-3xl">คุณโดนหมาป่ากัด</h2>
                <p className="mt-1 text-sm text-muted-foreground">จะดูเกมต่อ หรือกลับเมนูหลัก?</p>
                <div className="mt-5 flex gap-2">
                  <button
                    onClick={() => {
                      setSpectating(true);
                      setResult(null);
                    }}
                    className="btn-base btn-ghost flex-1"
                  >
                    ดูต่อ
                  </button>
                  <button onClick={onExit} className="btn-base btn-primary flex-1">
                    เมนูหลัก
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {clawFlash && (
        <div className="claw-hit pointer-events-none absolute inset-0 z-30">
          <div className="absolute inset-0 bg-destructive/35" />
          <svg
            className="absolute inset-0 h-full w-full"
            viewBox="0 0 100 100"
            preserveAspectRatio="none"
          >
            {[18, 38, 58, 78].map((x, i) => (
              <path
                key={x}
                d={`M ${x} -5 Q ${x + 14} 50 ${x - 6} 105`}
                stroke="rgba(255,45,45,0.85)"
                strokeWidth={i % 2 ? 2.2 : 3.4}
                fill="none"
                strokeLinecap="round"
              />
            ))}
          </svg>
        </div>
      )}
    </div>
  );
}
