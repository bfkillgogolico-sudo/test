import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { CharacterModel3D } from "@/components/CharacterModel3D";
import { EggReveal } from "@/components/EggReveal";
import { Spinner } from "@/components/Spinner";
import { StarFilter, effectiveStar } from "@/components/StarFilter";

import { BREED_COST, breedPets, type BreedResult } from "@/lib/game.functions";
import { getAnimal, getColor, getPattern, getSkill, genderSymbol, stars, type Pet } from "@/lib/game/pets";

type Props = { pets: Pet[]; credits: number; onRefresh: () => void };

function Mini({ pet }: { pet: Pet }) {
  const a = getAnimal(pet.animal);
  const c = getColor(pet.color);
  const patC = getColor(pet.pattern_color);
  return (
    <div className="text-center">
      <CharacterModel3D
        model={a.model}
        tint={c.hex}
        pattern={pet.pattern}
        patternTint={patC.hex}
        className="mx-auto h-20 w-20"
        emoji={a.emoji}
      />
      <div className="font-display text-base leading-none">
        {a.name}{" "}
        <span className={pet.gender === "female" ? "text-pink-400" : "text-sky-400"}>{genderSymbol(pet.gender)}</span>
      </div>
      <div className="font-display text-sm text-yellow-300">{stars(pet.stars)}</div>
    </div>
  );
}

export function BreedPanel({ pets, credits, onRefresh }: Props) {
  const [slots, setSlots] = useState<[Pet | null, Pet | null]>([null, null]);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [result, setResult] = useState<(BreedResult & { ok: true }) | null>(null);
  const [dragOver, setDragOver] = useState<number | null>(null);
  const [showInfo, setShowInfo] = useState(false);
  const [starFilter, setStarFilter] = useState<number | null>(null);
  const breed = useServerFn(breedPets);

  const [a, b] = slots;
  const usedIds = [a?.id, b?.id].filter(Boolean) as string[];
  const available = pets.filter((p) => !usedIds.includes(p.id));
  const effStars = effectiveStar(available, starFilter);
  const list = available.filter((p) => p.stars === effStars);

  function place(pet: Pet, i: 0 | 1) {
    setResult(null);
    setMsg(null);
    setSlots((s) => {
      const next: [Pet | null, Pet | null] = [s[0], s[1]];
      if (next[0]?.id === pet.id) next[0] = null;
      if (next[1]?.id === pet.id) next[1] = null;
      next[i] = pet;
      return next;
    });
  }

  function autoPlace(pet: Pet) {
    place(pet, slots[0] ? 1 : 0);
  }

  async function doBreed() {
    if (!a || !b || busy) return;
    setBusy(true);
    setMsg(null);
    setResult(null);
    try {
      const res = (await breed({ data: { aId: a.id, bId: b.id } })) as BreedResult;
      if (!res.ok) {
        setMsg(
          res.reason === "no_credits"
            ? `💠 เครดิตไม่พอ (ต้องมี ${BREED_COST})`
            : "ผสมพันธุ์ไม่สำเร็จ ลองอีกครั้ง",
        );
      } else {
        setResult(res);
        setSlots([null, null]);
        onRefresh();
      }
    } finally {
      setBusy(false);
    }
  }

  const deadNames = (ids: string[]) =>
    ids
      .map((id) => {
        const p = [a, b].find((x) => x?.id === id);
        return p ? `${getAnimal(p.animal).emoji} ${getAnimal(p.animal).name} ${genderSymbol(p.gender)}` : "สัตว์";
      })
      .join(" และ ");

  return (
    <section className="mt-5 space-y-4">
      <div className="panel p-5">
        <div className="flex items-center justify-between gap-2">
          <h2 className="text-2xl">💞 ผสมพันธุ์</h2>
          <div className="relative">
            {showInfo && (
              <div className="panel absolute right-0 top-11 z-40 w-[20rem] max-w-[88vw] space-y-2 p-3 text-xs leading-relaxed">
                <p className="font-display text-base text-primary">กฎการผสมพันธุ์</p>
                <div className="space-y-2">
                  <div className="rounded-lg bg-secondary p-2">
                    <p className="font-display text-sm text-emerald-300">
                      🍼 ชนิดเดียวกัน · ♂ + ♀ → 100% ได้ลูก
                    </p>
                    <p className="mt-1 text-muted-foreground">
                      พ่อแม่รอดทั้งคู่ ลูกสุ่มคุณสมบัติใหม่ทั้งหมด (สี · ตำหนิ · ดาว ·
                      เรตเครดิต) สกิลสุ่มจากพ่อหรือแม่
                    </p>
                  </div>
                  <div className="rounded-lg bg-secondary p-2">
                    <p className="font-display text-sm text-yellow-300">
                      🌟 คนละชนิด · ♂ + ♀ → 1% ได้ลูกผสมแรร์
                    </p>
                    <p className="mt-1 text-muted-foreground">
                      โอกาสสำเร็จเพียง 1% ได้ลูกผสม 6 ดาวหายาก เรตเครดิต =
                      ผลรวมของพ่อแม่ แต่ถ้าสำเร็จพ่อแม่ตายทั้งคู่
                    </p>
                    <p className="mt-1 text-red-400">
                      หากไม่สำเร็จ (99%) เกิดการสู้กัน ตัวหนึ่งตาย
                    </p>
                  </div>
                  <div className="rounded-lg bg-secondary p-2">
                    <p className="font-display text-sm text-red-400">
                      ⚔️ เพศเดียวกัน → สู้กันเสมอ
                    </p>
                    <p className="mt-1 text-muted-foreground">
                      ไม่มีลูก ตัวหนึ่งตาย (ชนิดเดียวกันมีโอกาส 35% ตายทั้งคู่)
                    </p>
                  </div>
                </div>
              </div>
            )}
            <button
              onMouseEnter={() => setShowInfo(true)}
              onMouseLeave={() => setShowInfo(false)}
              onClick={() => setShowInfo((v) => !v)}
              aria-label="รายละเอียดการผสมพันธุ์"
              className="h-9 w-9 rounded-full bg-secondary font-display text-lg text-primary shadow-lg"
            >
              ?
            </button>
          </div>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">
          ค่าใช้จ่าย 💠 {BREED_COST} เครดิต · ลากสัตว์จากด้านล่างมาใส่ 2 ช่อง (หรือกดที่ตัวสัตว์)
        </p>

        <div className="mt-4 flex items-center justify-center gap-4">
          {([0, 1] as const).map((i) => {
            const pet = slots[i];
            return (
              <div
                key={i}
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragOver(i);
                }}
                onDragLeave={() => setDragOver(null)}
                onDrop={(e) => {
                  e.preventDefault();
                  setDragOver(null);
                  const id = e.dataTransfer.getData("text/plain");
                  const p = pets.find((x) => x.id === id);
                  if (p) place(p, i);
                }}
                onClick={() => pet && setSlots((s) => (i === 0 ? [null, s[1]] : [s[0], null]))}
                className={`flex h-40 w-36 items-center justify-center rounded-xl border-2 border-dashed bg-secondary p-2 ${
                  dragOver === i ? "border-primary" : "border-muted"
                }`}
              >
                {pet ? (
                  <div
                    draggable
                    onDragStart={(e) => {
                      e.dataTransfer.setData("text/plain", pet.id);
                      e.dataTransfer.effectAllowed = "move";
                    }}
                  >
                    <Mini pet={pet} />
                  </div>
                ) : (
                  <span className="text-sm text-muted-foreground">ลากมาวางที่นี่</span>
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-4 text-center">
          <button
            onClick={() => void doBreed()}
            disabled={!a || !b || busy || credits < BREED_COST}
            className="btn-base btn-primary disabled:opacity-50"
          >
            {busy ? (
              <span className="inline-flex items-center gap-2">
                <Spinner /> กำลังผสม...
              </span>
            ) : `ตกลง — จ่าย 💠 ${BREED_COST}`}
          </button>
          {msg && <p className="mt-3 font-display text-xl text-primary">{msg}</p>}
        </div>

      </div>

      {result && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
          <div className="panel w-full max-w-sm p-5 text-center">
            {result.kind === "fight" ? (
              <>
                <div className="text-5xl">⚔️</div>
                <h3 className="mt-2 text-2xl text-red-400">เกิดการสู้กัน!</h3>
                <p className="mt-2 text-sm">
                  {result.bothDied
                    ? `ตายทั้งคู่: ${deadNames(result.dead)}`
                    : `ตัวที่ตาย: ${deadNames(result.dead)}`}
                </p>
              </>
            ) : (
              <EggReveal key={result.pet?.id ?? "egg"} stars={result.pet?.stars ?? 1} onClaim={() => setResult(null)}>
                <div>
                  <div className="text-5xl">{result.kind === "hybrid" ? "🌟" : "🍼"}</div>
                  <h3 className="mt-2 text-2xl text-primary">
                    {result.kind === "hybrid" ? "เกิดลูกผสมหาดยาก 6 ดาว!" : "ได้ลูกใหม่!"}
                  </h3>
                  {result.pet && (
                    <div className="mt-3">
                      <Mini pet={result.pet} />
                      <p className="mt-1 text-sm text-primary">{getSkill(result.pet.skill).name}</p>
                      <p className="text-xs text-muted-foreground">
                        สี {getColor(result.pet.color).name} · {getPattern(result.pet.pattern).name}
                      </p>
                      <p className="text-xs text-emerald-300">💠 {result.pet.credit_rate} เครดิต/วิ</p>
                    </div>
                  )}
                  {result.kind === "hybrid" && <p className="mt-2 text-sm text-red-400">พ่อแม่ตายทั้งคู่</p>}
                </div>
              </EggReveal>
            )}

            {result.kind === "fight" && (
              <button onClick={() => setResult(null)} className="btn-base btn-primary mt-4">
                ตกลง
              </button>
            )}
          </div>
        </div>
      )}

      <div
        className="panel p-5"
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          const id = e.dataTransfer.getData("text/plain");
          if (id) {
            setSlots((s) => [s[0]?.id === id ? null : s[0], s[1]?.id === id ? null : s[1]]);
          }
        }}
      >
        <h3 className="text-xl">สัตว์ของคุณ ({list.length})</h3>
        <div className="mt-2">
          <StarFilter pets={available} value={effStars} onChange={setStarFilter} />
        </div>
        {list.length === 0 ? (
          <p className="mt-2 text-sm text-muted-foreground">ยังไม่มีสัตว์ให้ผสม ลากจากช่องด้านบนมาที่นี่เพื่อนำออก</p>
        ) : (
          <div className="mt-3 grid grid-cols-3 gap-3 sm:grid-cols-4">
            {list.map((p) => (
              <button
                key={p.id}
                draggable
                onDragStart={(e) => {
                  e.dataTransfer.setData("text/plain", p.id);
                  e.dataTransfer.effectAllowed = "move";
                }}
                onClick={() => autoPlace(p)}
                className="rounded-lg bg-secondary p-2"
              >
                <Mini pet={p} />
              </button>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
