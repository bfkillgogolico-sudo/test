import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type FriendRow = {
  id: string;
  userId: string;
  username: string;
  credits: number;
};

export type FriendsState = {
  meId: string | null;
  friends: FriendRow[];
  incoming: FriendRow[];
  outgoing: FriendRow[];
  loading: boolean;
  reload: () => Promise<void>;
  addFriend: (username: string) => Promise<string>;
  accept: (id: string) => Promise<void>;
  reject: (id: string) => Promise<void>;
  remove: (id: string) => Promise<void>;
};

type Link = { id: string; requester_id: string; addressee_id: string; status: string };

export function useFriends(): FriendsState {
  const [meId, setMeId] = useState<string | null>(null);
  const [friends, setFriends] = useState<FriendRow[]>([]);
  const [incoming, setIncoming] = useState<FriendRow[]>([]);
  const [outgoing, setOutgoing] = useState<FriendRow[]>([]);
  const [loading, setLoading] = useState(true);

  const reload = useCallback(async () => {
    const uid = (await supabase.auth.getUser()).data.user?.id ?? null;
    setMeId(uid);
    if (!uid) {
      setFriends([]);
      setIncoming([]);
      setOutgoing([]);
      setLoading(false);
      return;
    }
    const { data } = await supabase
      .from("friendships")
      .select("id, requester_id, addressee_id, status")
      .or(`requester_id.eq.${uid},addressee_id.eq.${uid}`);
    const links = (data ?? []) as Link[];
    const otherIds = Array.from(
      new Set(links.map((l) => (l.requester_id === uid ? l.addressee_id : l.requester_id))),
    );
    let names = new Map<string, { username: string; credits: number }>();
    if (otherIds.length) {
      const { data: profs } = await supabase.rpc("public_profiles");
      names = new Map(
        ((profs ?? []) as any[])
          .filter((p: any) => otherIds.includes(p.id as string))
          .map((p: any) => [
            p.id as string,
            { username: p.username as string, credits: Number(p.credits ?? 0) },
          ]),
      );
    }

    const map = (l: Link): FriendRow => {
      const other = l.requester_id === uid ? l.addressee_id : l.requester_id;
      const info = names.get(other);
      return {
        id: l.id,
        userId: other,
        username: info?.username ?? "ผู้เล่น",
        credits: info?.credits ?? 0,
      };
    };
    setFriends(links.filter((l) => l.status === "accepted").map(map));
    setIncoming(links.filter((l) => l.status === "pending" && l.addressee_id === uid).map(map));
    setOutgoing(links.filter((l) => l.status === "pending" && l.requester_id === uid).map(map));
    setLoading(false);
  }, []);

  useEffect(() => {
    void reload();
    const t = setInterval(() => void reload(), 15000);
    return () => clearInterval(t);
  }, [reload]);

  const addFriend = useCallback(
    async (username: string): Promise<string> => {
      const name = username.trim();
      if (!name) return "กรอกชื่อผู้เล่นก่อนนะ";
      const uid = (await supabase.auth.getUser()).data.user?.id;
      if (!uid) return "ยังไม่ได้เข้าสู่ระบบ";
      const { data: allProfs } = await supabase.rpc("public_profiles");
      const prof = ((allProfs ?? []) as any[]).find(
        (p: any) => (p.username as string).toLowerCase() === name.toLowerCase(),
      ) as { id: string; username: string } | undefined;
      if (!prof) return "ไม่พบผู้เล่นชื่อนี้";
      if (prof.id === uid) return "เพิ่มตัวเองไม่ได้นะ";
      const { error } = await supabase

        .from("friendships")
        .insert({ requester_id: uid, addressee_id: prof.id as string, status: "pending" });
      if (error) return "ส่งคำขอไม่สำเร็จ (อาจส่งไปแล้วหรือเป็นเพื่อนกันอยู่)";
      await reload();
      return `ส่งคำขอเป็นเพื่อนไปที่ ${prof.username} แล้ว`;
    },
    [reload],
  );

  const accept = useCallback(
    async (id: string) => {
      await supabase.from("friendships").update({ status: "accepted" }).eq("id", id);
      await reload();
    },
    [reload],
  );

  const reject = useCallback(
    async (id: string) => {
      await supabase.from("friendships").delete().eq("id", id);
      await reload();
    },
    [reload],
  );

  return { meId, friends, incoming, outgoing, loading, reload, addFriend, accept, reject, remove: reject };
}
