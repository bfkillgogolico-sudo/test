import { useCallback, useEffect, useState } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { registerPets } from "@/lib/game/characters";
import type { Pet } from "@/lib/game/pets";

export type Profile = {
  id: string;
  username: string;
  coins: number;
  credits: number;
  gems: number;
  selected_pet_id: string | null;
  food_items: number;
  milk_items: number;
  med_items: number;
  poison_items: number;
  catch_items: number;
  guard_items: number;
  farm_expansions: number;
};

const DOMAIN = "wolforb.local";
export const userToEmail = (username: string) => `${username.trim().toLowerCase()}@${DOMAIN}`;

export function useAuth() {
  const [session, setSession] = useState<Session | null>(null);
  const [ready, setReady] = useState(false);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [pets, setPets] = useState<Pet[]>([]);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s);
      setReady(true);
    });
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setReady(true);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const refresh = useCallback(async () => {
    const { data: sess } = await supabase.auth.getSession();
    const uid = sess.session?.user.id;
    if (!uid) {
      setProfile(null);
      setPets([]);
      return;
    }
    const [{ data: p }, { data: rows }] = await Promise.all([
      supabase
        .from("profiles")
        .select(
          "id, username, coins, credits, gems, selected_pet_id, food_items, milk_items, med_items, poison_items, catch_items, guard_items, farm_expansions",
        )
        .eq("id", uid)
        .maybeSingle(),
      supabase
        .from("user_pets")
        .select(
          "id, animal, color, pattern, pattern_color, stars, skill, credit_rate, gender, food, water, sick, stress, stress_at",
        )
        .eq("user_id", uid)
        .order("created_at", { ascending: false }),
    ]);
    if (p) setProfile({ ...(p as Profile), credits: Number((p as Profile).credits ?? 0) });
    const list = (rows ?? []).map((r) => ({ ...r, credit_rate: Number(r.credit_rate) })) as Pet[];
    registerPets(list);
    setPets(list);
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh, session?.user.id]);

  // profile row can be created moments after signup — poll briefly until it lands
  useEffect(() => {
    if (!session || profile) return;
    const t = setInterval(() => void refresh(), 1200);
    return () => clearInterval(t);
  }, [session, profile, refresh]);

  const selectPet = useCallback(async (petId: string) => {
    setProfile((cur) => (cur ? { ...cur, selected_pet_id: petId } : cur));
    const { data: sess } = await supabase.auth.getSession();
    const uid = sess.session?.user.id;
    if (uid) await supabase.from("profiles").update({ selected_pet_id: petId }).eq("id", uid);
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setProfile(null);
    setPets([]);
  }, []);

  return { session, ready, profile, pets, refresh, selectPet, signOut, setProfile };
}
