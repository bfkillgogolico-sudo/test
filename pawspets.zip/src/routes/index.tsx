import { useCallback, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import type { RealtimeChannel } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AuthScreen } from "@/components/AuthScreen";
import { MainMenu } from "@/components/MainMenu";
import { RoomLobby } from "@/components/RoomLobby";
import { GameView } from "@/components/GameView";
import { GameLoadingScreen } from "@/components/GameLoadingScreen";
import { Spinner } from "@/components/Spinner";
import { seedFrom, type PlayerMeta } from "@/lib/game/engine";
import { awardWin } from "@/lib/game.functions";

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "PawPets — เกมส่งลูกแก้วหนีหมาป่า 6 คน" },
      {
        name: "description",
        content:
          "ยิงลูกแก้วพลังเด้งกำแพงส่งต่อให้เพื่อน ก่อนหมาป่าจะไล่กัดคุณ เล่นออนไลน์ 6 คน มีบอท สกิลตัวละคร และร้านค้าสุ่มตัวละคร",
      },
      { property: "og:title", content: "PawPets — เกมส่งลูกแก้วหนีหมาป่า" },
      {
        property: "og:description",
        content:
          "ลูกแก้วอยู่กับใคร หมาป่าไล่คนนั้น! ยิงเด้งกำแพงส่งต่อให้เพื่อน คนสุดท้ายที่รอดคือผู้ชนะ",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: App,
});

const randCode = () => {
  const c = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  return Array.from({ length: 4 }, () => c[Math.floor(Math.random() * c.length)]).join("");
};

function App() {
  const { session, ready, profile, pets, refresh, selectPet, signOut } = useAuth();
  const [screen, setScreen] = useState<"menu" | "lobby" | "loading" | "game">("menu");
  const [menuTab, setMenuTab] = useState<"home" | "play" | "chars" | "shop" | "breed" | "gift">("home");
  const [room, setRoom] = useState<{ code: string; isHost: boolean } | null>(null);
  const [game, setGame] = useState<{
    metas: PlayerMeta[];
    channel: RealtimeChannel | null;
    isHost: boolean;
    seed: number;
    startAt: number;
  } | null>(null);

  const award = useServerFn(awardWin);

  // testing phase: every character is playable, no ownership gate

  const leaveRoom = useCallback(async () => {
    if (game?.channel) supabase.removeChannel(game.channel);
    if (room?.isHost) await supabase.from("rooms").delete().eq("code", room.code);
    setRoom(null);
    setGame(null);
    setScreen("menu");
    void refresh();
  }, [game?.channel, room, refresh]);

  if (!ready) {
    return (
      <div className="flex min-h-screen items-center justify-center gap-3 text-2xl">
        <Spinner className="h-6 w-6" /> กำลังโหลด...
      </div>
    );
  }
  if (!session) return <AuthScreen onDone={() => void refresh()} />;
  if (!profile) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-3 px-4 text-center">
        <p className="inline-flex items-center gap-2">
          <Spinner /> กำลังเตรียมโปรไฟล์ผู้เล่น...
        </p>
        <button onClick={() => void refresh()} className="btn-base btn-ghost">
          ลองอีกครั้ง
        </button>
        <button onClick={() => void signOut()} className="text-sm underline">
          ออกจากระบบ
        </button>
      </div>
    );
  }

  const charId = profile.selected_pet_id ?? "";
  const myPet = pets.find((p) => p.id === charId);
  const self = {
    id: session.user.id,
    name: profile.username,
    charId,
    ...(myPet ? { pet: myPet } : {}),
  };

  if (screen === "loading" && game) {
    return (
      <GameLoadingScreen
        selfId={self.id}
        metas={game.metas}
        isHost={game.isHost}
        channel={game.channel}
        onReady={(startAt) => {
          setGame((g) => (g ? { ...g, startAt } : g));
          setScreen("game");
        }}
      />
    );
  }

  if (screen === "game" && game) {
    return (
      <GameView
        key={game.metas.map((m) => m.id).join("|")}
        selfId={self.id}
        metas={game.metas}
        startAt={game.startAt}
        seed={game.seed}
        channel={game.channel}
        onFinish={(placement) => {
          void award({ data: { placement } }).then(() => refresh());
        }}
        onExit={() => void leaveRoom()}
      />
    );
  }

  if (screen === "lobby" && room) {
    return (
      <RoomLobby
        code={room.code}
        self={self}
        isHost={room.isHost}
        onStart={(metas, channel, isHost) => {
          // seed comes from the room code, so every device rolls identical randomness
          setGame({ metas, channel, isHost, seed: seedFrom(room.code), startAt: Date.now() });
          setScreen("loading");
        }}

        onLeave={() => void leaveRoom()}
      />
    );
  }

  return (
    <MainMenu
      key={menuTab}
      profile={profile}
      pets={pets}
      selectedPetId={profile.selected_pet_id}
      initialTab={menuTab}
      onSelectPet={(id) => void selectPet(id)}
      onRefresh={() => void refresh()}
      onSignOut={() => void signOut()}
      onCreateRoom={async () => {
        const code = randCode();
        await supabase
          .from("rooms")
          .insert({ code, host_id: self.id, host_name: profile.username, status: "open" });
        setRoom({ code, isHost: true });
        setScreen("lobby");
      }}
      onJoinRoom={(code) => {
        setRoom({ code: code.toUpperCase(), isHost: false });
        setScreen("lobby");
      }}
    />
  );
}
